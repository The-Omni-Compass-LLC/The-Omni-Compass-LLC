# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.7 | 62.42 | 62.53 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.287e+04 | 9.284e+04 | 9.271e+04 |
| energy per served request (J) | 15.95 | 16.02 | 15.99 |
| power, GPU mean (W) | 274.3 | 274.7 | 274.9 |
| requests served | 5823 | 5796 | 5797 |
| requests not served | 1174 | 1202 | 1200 |
| response time, mean (ms) | 4.014e+04 | 4.032e+04 | 4.034e+04 |
| response time, 95th percentile (ms) | 7.582e+04 | 7.678e+04 | 7.676e+04 |
| response time, 99th percentile (ms) | 7.795e+04 | 7.92e+04 | 7.915e+04 |
| temperature, peak (C) | 62 | 62 | 62 |
| temperature, mean (C) | 60.13 | 60.21 | 59.79 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.287e+04 | 9.284e+04 | 9.279e+04 |
| power-capped share of samples | 0.9767 | 0.9788 | 0.9307 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.7 | 62.53 | -0.3% | -2.462 to +2.121 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.287e+04 | 9.271e+04 | -0.2% | -1226 to +901.6 | STEADY, under the floor |
| energy per served request (J) | 15.95 | 15.99 | +0.3% | -0.5383 to +0.6248 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.9 | +0.2% | -9.215 to +10.53 | STEADY, under the floor |
| requests served | 5823 | 5797 | -0.4% | -305.5 to +253.5 | STEADY, under the floor |
| requests not served | 1174 | 1200 | +2.2% | -253.5 to +305.5 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.014e+04 | 4.034e+04 | +0.5% | -612.6 to +1009 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.582e+04 | 7.676e+04 | +1.2% | -1.009e+04 to +1.198e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.795e+04 | 7.915e+04 | +1.5% | -1.233e+04 to +1.473e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.13 | 59.79 | -0.6% | -4.401 to +3.716 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.279e+04 | -0.1% | -82.81 to -69.22 | STEADY, under the floor |
| power-capped share of samples | 0.9767 | 0.9307 | -4.7% | -0.3766 to +0.2847 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.7 | 62.42 | -0.4% | -3.322 to +2.768 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.287e+04 | 9.284e+04 | -0.0% | -484.2 to +427.4 | STEADY, under the floor |
| energy per served request (J) | 15.95 | 16.02 | +0.4% | -0.7036 to +0.8446 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.7 | +0.1% | -10.65 to +11.47 | STEADY, under the floor |
| requests served | 5823 | 5796 | -0.5% | -338.8 to +283.8 | STEADY, under the floor |
| requests not served | 1174 | 1202 | +2.3% | -283.8 to +338.8 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.014e+04 | 4.032e+04 | +0.4% | -1073 to +1428 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.582e+04 | 7.678e+04 | +1.3% | -1.117e+04 to +1.31e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.795e+04 | 7.92e+04 | +1.6% | -1.396e+04 to +1.647e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.13 | 60.21 | +0.1% | -0.5442 to +0.7156 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.284e+04 | -0.0% | -1047 to +985.7 | STEADY, under the floor |
| power-capped share of samples | 0.9767 | 0.9788 | +0.2% | -0.03168 to +0.03584 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.42 | 62.53 | +0.2% | -0.6469 to +0.8598 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.284e+04 | 9.271e+04 | -0.1% | -742.2 to +474.2 | STEADY, under the floor |
| energy per served request (J) | 16.02 | 15.99 | -0.2% | -0.2198 to +0.1653 | STEADY, under the floor |
| power, GPU mean (W) | 274.7 | 274.9 | +0.1% | -20.68 to +21.18 | STEADY, under the floor |
| requests served | 5796 | 5797 | +0.0% | -30.26 to +33.27 | STEADY, under the floor |
| requests not served | 1202 | 1200 | -0.1% | -33.27 to +30.26 | STEADY, under the floor |
| response time, mean (ms) | 4.032e+04 | 4.034e+04 | +0.1% | -419.9 to +460.4 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.678e+04 | 7.676e+04 | -0.0% | -1117 to +1084 | STEADY, under the floor |
| response time, 99th percentile (ms) | 7.92e+04 | 7.915e+04 | -0.1% | -1736 to +1624 | STEADY, under the floor |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.21 | 59.79 | -0.7% | -3.857 to +3.001 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.284e+04 | 9.279e+04 | -0.0% | -1069 to +977.9 | STEADY, under the floor |
| power-capped share of samples | 0.9788 | 0.9307 | -4.9% | -0.3449 to +0.2488 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.7 -> 62.53 served requests per kJ, difference -0.1705 (95% interval -2.462 to +2.121).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 6.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*