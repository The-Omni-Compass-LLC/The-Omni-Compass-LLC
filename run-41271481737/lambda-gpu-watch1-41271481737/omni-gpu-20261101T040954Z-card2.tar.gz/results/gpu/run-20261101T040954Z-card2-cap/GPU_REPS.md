# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.23 | 42.89 | 42.68 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.049e+04 | 6.097e+04 | 6.127e+04 |
| energy per served request (J) | 23.13 | 23.32 | 23.43 |
| power, GPU mean (W) | 178.9 | 180.3 | 181.9 |
| requests served | 2615 | 2615 | 2615 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 108.6 | 110.9 | 107.7 |
| response time, 95th percentile (ms) | 335.9 | 344.4 | 326.3 |
| response time, 99th percentile (ms) | 605.5 | 638.3 | 572.3 |
| temperature, peak (C) | 58 | 58.5 | 58 |
| temperature, mean (C) | 49.11 | 49.16 | 49.07 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.077e+04 | 6.09e+04 | 6.055e+04 |
| power-capped share of samples | 0.6677 | 0.6717 | 0.6528 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.23 | 42.68 | -1.3% | -4.341 to +3.244 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.049e+04 | 6.127e+04 | +1.3% | -4480 to +6024 | power given, not beyond the noise |
| energy per served request (J) | 23.13 | 23.43 | +1.3% | -1.713 to +2.304 | power given, not beyond the noise |
| power, GPU mean (W) | 178.9 | 181.9 | +1.7% | -2.652 to +8.557 | power given, not beyond the noise |
| requests served | 2615 | 2615 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 108.6 | 107.7 | -0.8% | -11.11 to +9.411 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 335.9 | 326.3 | -2.9% | -99.7 to +80.41 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 605.5 | 572.3 | -5.5% | -434.4 to +367.9 | GAIN, not beyond the noise |
| temperature, peak (C) | 58 | 58 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.11 | 49.07 | -0.1% | -0.834 to +0.7381 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.077e+04 | 6.055e+04 | -0.4% | -1356 to +911.3 | STEADY, under the floor |
| power-capped share of samples | 0.6677 | 0.6528 | -2.2% | -0.04239 to +0.01269 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.23 | 42.89 | -0.8% | -2.724 to +2.039 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.049e+04 | 6.097e+04 | +0.8% | -2788 to +3746 | power given, not beyond the noise |
| energy per served request (J) | 23.13 | 23.32 | +0.8% | -1.066 to +1.432 | power given, not beyond the noise |
| power, GPU mean (W) | 178.9 | 180.3 | +0.8% | -9.22 to +11.93 | power given, not beyond the noise |
| requests served | 2615 | 2615 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 108.6 | 110.9 | +2.1% | -10.23 to +14.83 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 335.9 | 344.4 | +2.5% | -56.59 to +73.69 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 605.5 | 638.3 | +5.4% | -337 to +402.5 | LOSS, not beyond the noise |
| temperature, peak (C) | 58 | 58.5 | +0.9% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 49.11 | 49.16 | +0.1% | -0.1679 to +0.2645 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.077e+04 | 6.09e+04 | +0.2% | -938.7 to +1189 | STEADY, under the floor |
| power-capped share of samples | 0.6677 | 0.6717 | +0.6% | -0.02165 to +0.02977 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.89 | 42.68 | -0.5% | -1.617 to +1.205 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.097e+04 | 6.127e+04 | +0.5% | -1693 to +2279 | STEADY, under the floor |
| energy per served request (J) | 23.32 | 23.43 | +0.5% | -0.6473 to +0.8714 | STEADY, under the floor |
| power, GPU mean (W) | 180.3 | 181.9 | +0.9% | -3.372 to +6.568 | power given, not beyond the noise |
| requests served | 2615 | 2615 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 110.9 | 107.7 | -2.8% | -5.424 to -0.8825 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 344.4 | 326.3 | -5.3% | -43.1 to +6.724 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 638.3 | 572.3 | -10.3% | -97.43 to -34.59 | GAIN, clear of the noise |
| temperature, peak (C) | 58.5 | 58 | -0.9% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 49.16 | 49.07 | -0.2% | -0.6661 to +0.4736 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.09e+04 | 6.055e+04 | -0.6% | -417.2 to -278.2 | GAIN, clear of the noise |
| power-capped share of samples | 0.6717 | 0.6528 | -2.8% | -0.02074 to -0.01708 | GAIN, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.23 -> 42.68 served requests per kJ, difference -0.5484 (95% interval -4.341 to +3.244).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*