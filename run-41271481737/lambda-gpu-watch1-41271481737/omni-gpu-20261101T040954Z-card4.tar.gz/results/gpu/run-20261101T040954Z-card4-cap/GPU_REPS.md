# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.43 | 42.06 | 42.41 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.227e+04 | 6.283e+04 | 6.229e+04 |
| energy per served request (J) | 23.57 | 23.78 | 23.58 |
| power, GPU mean (W) | 185.6 | 187.3 | 185.7 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 114 | 114.2 | 116 |
| response time, 95th percentile (ms) | 372.2 | 373 | 393.1 |
| response time, 99th percentile (ms) | 647 | 655.7 | 668.5 |
| temperature, peak (C) | 65 | 65 | 65 |
| temperature, mean (C) | 54.88 | 54.83 | 54.83 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.279e+04 | 6.27e+04 | 6.228e+04 |
| power-capped share of samples | 0.6812 | 0.6908 | 0.6475 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.43 | 42.41 | -0.0% | -3.013 to +2.985 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.227e+04 | 6.229e+04 | +0.0% | -4383 to +4419 | STEADY, under the floor |
| energy per served request (J) | 23.57 | 23.58 | +0.0% | -1.659 to +1.673 | STEADY, under the floor |
| power, GPU mean (W) | 185.6 | 185.7 | +0.1% | -16.93 to +17.19 | STEADY, under the floor |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114 | 116 | +1.7% | -21.9 to +25.86 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 372.2 | 393.1 | +5.6% | -212 to +253.7 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 647 | 668.5 | +3.3% | -270.3 to +313.2 | LOSS, not beyond the noise |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.88 | 54.83 | -0.1% | -1.481 to +1.378 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.279e+04 | 6.228e+04 | -0.8% | -925.2 to -86.12 | GAIN, clear of the noise |
| power-capped share of samples | 0.6812 | 0.6475 | -4.9% | -0.1078 to +0.04042 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.43 | 42.06 | -0.9% | -2.688 to +1.944 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.227e+04 | 6.283e+04 | +0.9% | -2991 to +4102 | power given, not beyond the noise |
| energy per served request (J) | 23.57 | 23.78 | +0.9% | -1.132 to +1.553 | power given, not beyond the noise |
| power, GPU mean (W) | 185.6 | 187.3 | +0.9% | -10.31 to +13.83 | power given, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114 | 114.2 | +0.1% | -34.07 to +34.37 | STEADY, under the floor |
| response time, 95th percentile (ms) | 372.2 | 373 | +0.2% | -428.5 to +429.9 | STEADY, under the floor |
| response time, 99th percentile (ms) | 647 | 655.7 | +1.3% | -422.8 to +440.3 | LOSS, not beyond the noise |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.88 | 54.83 | -0.1% | -0.9074 to +0.8122 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.279e+04 | 6.27e+04 | -0.1% | -304.7 to +125.3 | STEADY, under the floor |
| power-capped share of samples | 0.6812 | 0.6908 | +1.4% | -0.1016 to +0.1208 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.06 | 42.41 | +0.9% | -4.957 to +5.674 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.283e+04 | 6.229e+04 | -0.9% | -8486 to +7411 | GAIN, not beyond the noise |
| energy per served request (J) | 23.78 | 23.58 | -0.9% | -3.212 to +2.805 | GAIN, not beyond the noise |
| power, GPU mean (W) | 187.3 | 185.7 | -0.9% | -30.76 to +27.49 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.2 | 116 | +1.6% | -8.512 to +12.17 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 373 | 393.1 | +5.4% | -176.3 to +216.5 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 655.7 | 668.5 | +1.9% | -127 to +152.6 | LOSS, not beyond the noise |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.83 | 54.83 | -0.0% | -0.5731 to +0.566 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.27e+04 | 6.228e+04 | -0.7% | -1050 to +218.6 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6908 | 0.6475 | -6.3% | -0.2286 to +0.142 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.43 -> 42.41 served requests per kJ, difference -0.01374 (95% interval -3.013 to +2.985).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 22.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*