# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 61.39 | 61.19 | 61.43 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.267e+04 | 9.272e+04 | 9.265e+04 |
| energy per served request (J) | 16.29 | 16.34 | 16.28 |
| power, GPU mean (W) | 276.3 | 275.3 | 276.8 |
| requests served | 5689 | 5674 | 5692 |
| requests not served | 1330 | 1345 | 1327 |
| response time, mean (ms) | 4.312e+04 | 4.285e+04 | 4.302e+04 |
| response time, 95th percentile (ms) | 8.212e+04 | 8.269e+04 | 8.197e+04 |
| response time, 99th percentile (ms) | 8.527e+04 | 8.601e+04 | 8.518e+04 |
| temperature, peak (C) | 71 | 71 | 71 |
| temperature, mean (C) | 68.56 | 67.75 | 68.53 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.288e+04 | 9.283e+04 | 9.264e+04 |
| power-capped share of samples | 0.9869 | 0.9815 | 0.9233 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.39 | 61.43 | +0.1% | -0.8667 to +0.9574 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.267e+04 | 9.265e+04 | -0.0% | -152.7 to +113.7 | STEADY, under the floor |
| energy per served request (J) | 16.29 | 16.28 | -0.1% | -0.2515 to +0.228 | STEADY, under the floor |
| power, GPU mean (W) | 276.3 | 276.8 | +0.2% | -1.342 to +2.359 | STEADY, under the floor |
| requests served | 5689 | 5692 | +0.1% | -73.24 to +79.24 | STEADY, under the floor |
| requests not served | 1330 | 1327 | -0.2% | -79.24 to +73.24 | STEADY, under the floor |
| response time, mean (ms) | 4.312e+04 | 4.302e+04 | -0.2% | -2093 to +1884 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.212e+04 | 8.197e+04 | -0.2% | -3618 to +3302 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.527e+04 | 8.518e+04 | -0.1% | -2900 to +2724 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.56 | 68.53 | -0.0% | -0.325 to +0.2723 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.288e+04 | 9.264e+04 | -0.3% | -381.5 to -108.7 | STEADY, under the floor |
| power-capped share of samples | 0.9869 | 0.9233 | -6.4% | -0.4604 to +0.3333 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.39 | 61.19 | -0.3% | -8.367 to +7.976 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.267e+04 | 9.272e+04 | +0.1% | -907 to +1010 | STEADY, under the floor |
| energy per served request (J) | 16.29 | 16.34 | +0.3% | -2.122 to +2.226 | STEADY, under the floor |
| power, GPU mean (W) | 276.3 | 275.3 | -0.4% | -13.36 to +11.28 | STEADY, under the floor |
| requests served | 5689 | 5674 | -0.3% | -713.8 to +683.8 | STEADY, under the floor |
| requests not served | 1330 | 1345 | +1.1% | -683.8 to +713.8 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.312e+04 | 4.285e+04 | -0.6% | -1.187e+04 to +1.132e+04 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.212e+04 | 8.269e+04 | +0.7% | -2.62e+04 to +2.734e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.527e+04 | 8.601e+04 | +0.9% | -3.328e+04 to +3.476e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.56 | 67.75 | -1.2% | -8.492 to +6.863 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.288e+04 | 9.283e+04 | -0.1% | -1364 to +1258 | STEADY, under the floor |
| power-capped share of samples | 0.9869 | 0.9815 | -0.5% | -0.02023 to +0.009463 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.19 | 61.43 | +0.4% | -8.843 to +9.324 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.265e+04 | -0.1% | -1163 to +1021 | STEADY, under the floor |
| energy per served request (J) | 16.34 | 16.28 | -0.4% | -2.477 to +2.35 | STEADY, under the floor |
| power, GPU mean (W) | 275.3 | 276.8 | +0.6% | -12.62 to +15.72 | power given, not beyond the noise |
| requests served | 5674 | 5692 | +0.3% | -757.1 to +793.1 | STEADY, under the floor |
| requests not served | 1345 | 1327 | -1.3% | -793.1 to +757.1 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.285e+04 | 4.302e+04 | +0.4% | -1.342e+04 to +1.376e+04 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.269e+04 | 8.197e+04 | -0.9% | -3.096e+04 to +2.95e+04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.601e+04 | 8.518e+04 | -1.0% | -3.766e+04 to +3.6e+04 | GAIN, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 67.75 | 68.53 | +1.2% | -6.59 to +8.167 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.283e+04 | 9.264e+04 | -0.2% | -1639 to +1256 | STEADY, under the floor |
| power-capped share of samples | 0.9815 | 0.9233 | -5.9% | -0.4402 to +0.3238 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 61.39 -> 61.43 served requests per kJ, difference +0.04533 (95% interval -0.8667 to +0.9574).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*