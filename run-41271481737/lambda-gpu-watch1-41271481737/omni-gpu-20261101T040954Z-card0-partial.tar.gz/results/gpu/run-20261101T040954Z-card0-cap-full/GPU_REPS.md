# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.19 | 62.09 | 62.06 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.282e+04 | 9.279e+04 | 9.268e+04 |
| energy per served request (J) | 16.08 | 16.11 | 16.11 |
| power, GPU mean (W) | 274.3 | 275.4 | 275.4 |
| requests served | 5772 | 5761 | 5752 |
| requests not served | 1240 | 1251 | 1260 |
| response time, mean (ms) | 4.141e+04 | 4.165e+04 | 4.183e+04 |
| response time, 95th percentile (ms) | 7.847e+04 | 7.889e+04 | 7.928e+04 |
| response time, 99th percentile (ms) | 8.119e+04 | 8.171e+04 | 8.224e+04 |
| temperature, peak (C) | 72 | 72 | 72 |
| temperature, mean (C) | 68.26 | 69.14 | 69.27 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.29e+04 | 9.287e+04 | 9.274e+04 |
| power-capped share of samples | 0.9782 | 0.9818 | 0.9715 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.19 | 62.06 | -0.2% | -3.742 to +3.474 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.282e+04 | 9.268e+04 | -0.1% | -1846 to +1570 | STEADY, under the floor |
| energy per served request (J) | 16.08 | 16.11 | +0.2% | -0.8993 to +0.9683 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 275.4 | +0.4% | -12.53 to +14.84 | STEADY, under the floor |
| requests served | 5772 | 5752 | -0.4% | -249.7 to +207.7 | STEADY, under the floor |
| requests not served | 1240 | 1260 | +1.7% | -207.7 to +249.7 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.141e+04 | 4.183e+04 | +1.0% | -6017 to +6862 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.847e+04 | 7.928e+04 | +1.0% | -7510 to +9121 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.119e+04 | 8.224e+04 | +1.3% | -9817 to +1.193e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.26 | 69.27 | +1.5% | -8.22 to +10.24 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.29e+04 | 9.274e+04 | -0.2% | -1596 to +1284 | STEADY, under the floor |
| power-capped share of samples | 0.9782 | 0.9715 | -0.7% | -0.1596 to +0.1461 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.19 | 62.09 | -0.2% | -3.946 to +3.735 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.282e+04 | 9.279e+04 | -0.0% | -1982 to +1926 | STEADY, under the floor |
| energy per served request (J) | 16.08 | 16.11 | +0.2% | -0.9668 to +1.021 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 275.4 | +0.4% | -10.28 to +12.67 | STEADY, under the floor |
| requests served | 5772 | 5761 | -0.2% | -246.6 to +223.6 | STEADY, under the floor |
| requests not served | 1240 | 1251 | +0.9% | -223.6 to +246.6 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.141e+04 | 4.165e+04 | +0.6% | -5508 to +6000 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.847e+04 | 7.889e+04 | +0.5% | -8281 to +9116 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.119e+04 | 8.171e+04 | +0.6% | -1.066e+04 to +1.17e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.26 | 69.14 | +1.3% | -7.754 to +9.518 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.29e+04 | 9.287e+04 | -0.0% | -396.6 to +341.4 | STEADY, under the floor |
| power-capped share of samples | 0.9782 | 0.9818 | +0.4% | -0.04161 to +0.04878 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.09 | 62.06 | -0.0% | -0.2609 to +0.204 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.279e+04 | 9.268e+04 | -0.1% | -356.6 to +135.5 | STEADY, under the floor |
| energy per served request (J) | 16.11 | 16.11 | +0.0% | -0.05273 to +0.06749 | STEADY, under the floor |
| power, GPU mean (W) | 275.4 | 275.4 | -0.0% | -2.249 to +2.169 | STEADY, under the floor |
| requests served | 5761 | 5752 | -0.2% | -15.85 to -3.147 | STEADY, under the floor |
| requests not served | 1251 | 1260 | +0.8% | +3.147 to +15.85 | LOSS, clear of the noise |
| response time, mean (ms) | 4.165e+04 | 4.183e+04 | +0.4% | -508.4 to +862.4 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.889e+04 | 7.928e+04 | +0.5% | +4.817 to +770.8 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.171e+04 | 8.224e+04 | +0.7% | +228.1 to +842.8 | LOSS, clear of the noise |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 69.14 | 69.27 | +0.2% | -0.4666 to +0.7206 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.274e+04 | -0.1% | -1199 to +942.5 | STEADY, under the floor |
| power-capped share of samples | 0.9818 | 0.9715 | -1.1% | -0.118 to +0.09732 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.19 -> 62.06 served requests per kJ, difference -0.1338 (95% interval -3.742 to +3.474).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 6.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*