# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.32 | 42.08 | 43.11 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.243e+04 | 6.278e+04 | 6.13e+04 |
| energy per served request (J) | 23.63 | 23.76 | 23.2 |
| power, GPU mean (W) | 185.6 | 186.4 | 181.6 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 113.4 | 114.6 | 113.7 |
| response time, 95th percentile (ms) | 363.7 | 371.8 | 360.2 |
| response time, 99th percentile (ms) | 647.3 | 659.4 | 642 |
| temperature, peak (C) | 65.5 | 65 | 65.5 |
| temperature, mean (C) | 55.62 | 55.65 | 55.61 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.216e+04 | 6.214e+04 | 6.202e+04 |
| power-capped share of samples | 0.6714 | 0.6796 | 0.6629 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.32 | 43.11 | +1.9% | -5.965 to +7.54 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.243e+04 | 6.13e+04 | -1.8% | -1.075e+04 to +8486 | GAIN, not beyond the noise |
| energy per served request (J) | 23.63 | 23.2 | -1.8% | -4.069 to +3.212 | GAIN, not beyond the noise |
| power, GPU mean (W) | 185.6 | 181.6 | -2.2% | -35.46 to +27.41 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 113.4 | 113.7 | +0.3% | -0.2059 to +0.815 | STEADY, under the floor |
| response time, 95th percentile (ms) | 363.7 | 360.2 | -1.0% | -17.45 to +10.46 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 647.3 | 642 | -0.8% | -120.7 to +110 | GAIN, not beyond the noise |
| temperature, peak (C) | 65.5 | 65.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.62 | 55.61 | -0.0% | -1.218 to +1.206 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.216e+04 | 6.202e+04 | -0.2% | -1402 to +1127 | STEADY, under the floor |
| power-capped share of samples | 0.6714 | 0.6629 | -1.3% | -0.06253 to +0.04546 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.32 | 42.08 | -0.6% | -2.383 to +1.905 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.243e+04 | 6.278e+04 | +0.6% | -2838 to +3548 | power given, not beyond the noise |
| energy per served request (J) | 23.63 | 23.76 | +0.6% | -1.074 to +1.343 | power given, not beyond the noise |
| power, GPU mean (W) | 185.6 | 186.4 | +0.4% | -13.07 to +14.65 | STEADY, under the floor |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 113.4 | 114.6 | +1.0% | -3.028 to +5.296 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 363.7 | 371.8 | +2.2% | -49.08 to +65.32 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 647.3 | 659.4 | +1.9% | -34.87 to +59.1 | LOSS, not beyond the noise |
| temperature, peak (C) | 65.5 | 65 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 55.62 | 55.65 | +0.1% | -1.497 to +1.562 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.216e+04 | 6.214e+04 | -0.0% | -1318 to +1270 | STEADY, under the floor |
| power-capped share of samples | 0.6714 | 0.6796 | +1.2% | -0.01017 to +0.02652 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.08 | 43.11 | +2.4% | -3.583 to +5.634 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.278e+04 | 6.13e+04 | -2.4% | -7911 to +4938 | GAIN, not beyond the noise |
| energy per served request (J) | 23.76 | 23.2 | -2.4% | -2.994 to +1.869 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.4 | 181.6 | -2.6% | -22.4 to +12.76 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.6 | 113.7 | -0.7% | -4.481 to +2.823 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 371.8 | 360.2 | -3.1% | -82.76 to +59.54 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 659.4 | 642 | -2.6% | -85.78 to +50.92 | GAIN, not beyond the noise |
| temperature, peak (C) | 65 | 65.5 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 55.65 | 55.61 | -0.1% | -0.3559 to +0.279 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.214e+04 | 6.202e+04 | -0.2% | -142.5 to -83.38 | STEADY, under the floor |
| power-capped share of samples | 0.6796 | 0.6629 | -2.5% | -0.08905 to +0.05563 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.32 -> 43.11 served requests per kJ, difference +0.7872 (95% interval -5.965 to +7.54).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 20.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*