# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.27 | 47.23 | 47.23 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.23e+05 | 1.231e+05 | 1.231e+05 |
| energy per served request (J) | 21.16 | 21.17 | 21.17 |
| power, GPU mean (W) | 192.7 | 193 | 192.7 |
| requests served | 5815 | 5815 | 5815 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.77 | 96.89 | 96.82 |
| response time, 95th percentile (ms) | 276.2 | 276.4 | 276.4 |
| response time, 99th percentile (ms) | 452.3 | 453.4 | 452.6 |
| temperature, peak (C) | 61 | 61.33 | 61.33 |
| temperature, mean (C) | 49.71 | 49.73 | 49.66 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.227e+05 | 1.228e+05 | 1.229e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.27 | 47.23 | -0.1% | -0.6954 to +0.6182 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.23e+05 | 1.231e+05 | +0.1% | -1610 to +1808 | STEADY, under the floor |
| energy per served request (J) | 21.16 | 21.17 | +0.1% | -0.2768 to +0.3109 | STEADY, under the floor |
| power, GPU mean (W) | 192.7 | 192.7 | +0.0% | -3.292 to +3.347 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.77 | 96.82 | +0.0% | -0.4723 to +0.562 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.2 | 276.4 | +0.1% | -0.6317 to +1.103 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.3 | 452.6 | +0.1% | -3.906 to +4.635 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 49.71 | 49.66 | -0.1% | -0.3657 to +0.284 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.227e+05 | 1.229e+05 | +0.2% | -42.94 to +475.5 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.27 | 47.23 | -0.1% | -0.5039 to +0.4281 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.23e+05 | 1.231e+05 | +0.1% | -1110 to +1316 | STEADY, under the floor |
| energy per served request (J) | 21.16 | 21.17 | +0.1% | -0.1909 to +0.2263 | STEADY, under the floor |
| power, GPU mean (W) | 192.7 | 193 | +0.2% | -0.7918 to +1.414 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.77 | 96.89 | +0.1% | -0.2624 to +0.5029 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.2 | 276.4 | +0.1% | -0.6808 to +1.196 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.3 | 453.4 | +0.3% | -1.814 to +4.099 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 49.71 | 49.73 | +0.1% | -0.2356 to +0.2876 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.227e+05 | 1.228e+05 | +0.1% | -256 to +552 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.23 | 47.23 | -0.0% | -1.122 to +1.12 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.231e+05 | 1.231e+05 | -0.0% | -2921 to +2913 | STEADY, under the floor |
| energy per served request (J) | 21.17 | 21.17 | -0.0% | -0.5023 to +0.501 | STEADY, under the floor |
| power, GPU mean (W) | 193 | 192.7 | -0.1% | -4.651 to +4.085 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.89 | 96.82 | -0.1% | -0.7148 to +0.564 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.4 | 276.4 | -0.0% | -0.8326 to +0.7879 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.4 | 452.6 | -0.2% | -5.851 to +4.295 | STEADY, under the floor |
| temperature, peak (C) | 61.33 | 61.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 49.73 | 49.66 | -0.1% | -0.1917 to +0.05791 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.228e+05 | 1.229e+05 | +0.1% | -543.6 to +680.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.27 -> 47.23 served requests per kJ, difference -0.0386 (95% interval -0.6954 to +0.6182).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.204 | 0.267 | 0 | 1.13e+03 | 31 | True |
| omni | 2 | 38 | 0 | 0 | 0 | 0.2 | 0.272 | 0 | 1.31e+03 | 37 | True |
| omni | 3 | 34 | 0 | 0 | 0 | 0.199 | 0.27 | 0 | 1.17e+03 | 33 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| omni | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | +97.6 | +0 |
| compass | 52 | 996 | +100.7 | -21 |
| race | 49 | 157 | -642 | +52 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 104.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*