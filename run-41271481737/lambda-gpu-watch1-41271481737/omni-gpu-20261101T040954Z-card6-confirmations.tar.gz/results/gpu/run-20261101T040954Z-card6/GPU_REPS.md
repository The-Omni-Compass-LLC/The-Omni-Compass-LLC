# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.69 | 39.45 | 39.51 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.538e+05 | 1.548e+05 | 1.545e+05 |
| energy per served request (J) | 25.19 | 25.36 | 25.32 |
| power, GPU mean (W) | 242.3 | 243.4 | 243.6 |
| requests served | 6103 | 6103 | 6103 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 91.03 | 91.06 | 90.99 |
| response time, 95th percentile (ms) | 267.9 | 268.2 | 267.6 |
| response time, 99th percentile (ms) | 453.8 | 454.7 | 453.3 |
| temperature, peak (C) | 69.67 | 69.33 | 69 |
| temperature, mean (C) | 56.87 | 56.87 | 56.88 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.545e+05 | 1.545e+05 | 1.543e+05 |
| power-capped share of samples | 0.7409 | 0.7364 | 0.7351 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.69 | 39.51 | -0.5% | -1.731 to +1.354 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.538e+05 | 1.545e+05 | +0.5% | -5315 to +6809 | STEADY, under the floor |
| energy per served request (J) | 25.19 | 25.32 | +0.5% | -0.8709 to +1.116 | STEADY, under the floor |
| power, GPU mean (W) | 242.3 | 243.6 | +0.5% | -8.757 to +11.37 | power given, not beyond the noise |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.03 | 90.99 | -0.0% | -0.5278 to +0.46 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.9 | 267.6 | -0.1% | -4.096 to +3.452 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.8 | 453.3 | -0.1% | -8.388 to +7.39 | STEADY, under the floor |
| temperature, peak (C) | 69.67 | 69 | -1.0% | -2.101 to +0.7677 | GAIN, not beyond the noise |
| temperature, mean (C) | 56.87 | 56.88 | +0.0% | -0.07819 to +0.0895 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.545e+05 | 1.543e+05 | -0.2% | -1186 to +630.5 | STEADY, under the floor |
| power-capped share of samples | 0.7409 | 0.7351 | -0.8% | -0.01619 to +0.004501 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.69 | 39.45 | -0.6% | -2.542 to +2.043 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.538e+05 | 1.548e+05 | +0.7% | -7864 to +9884 | power given, not beyond the noise |
| energy per served request (J) | 25.19 | 25.36 | +0.7% | -1.289 to +1.62 | power given, not beyond the noise |
| power, GPU mean (W) | 242.3 | 243.4 | +0.5% | -12.24 to +14.54 | STEADY, under the floor |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.03 | 91.06 | +0.0% | -0.23 to +0.2999 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.9 | 268.2 | +0.1% | -0.9867 to +1.57 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.8 | 454.7 | +0.2% | -2.202 to +3.909 | STEADY, under the floor |
| temperature, peak (C) | 69.67 | 69.33 | -0.5% | -3.202 to +2.535 | STEADY, under the floor |
| temperature, mean (C) | 56.87 | 56.87 | -0.0% | -0.05593 to +0.05231 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.545e+05 | 1.545e+05 | -0.0% | -1117 to +1003 | STEADY, under the floor |
| power-capped share of samples | 0.7409 | 0.7364 | -0.6% | -0.0245 to +0.01534 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.45 | 39.51 | +0.2% | -3.312 to +3.434 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.548e+05 | 1.545e+05 | -0.2% | -1.343e+04 to +1.29e+04 | STEADY, under the floor |
| energy per served request (J) | 25.36 | 25.32 | -0.2% | -2.2 to +2.114 | STEADY, under the floor |
| power, GPU mean (W) | 243.4 | 243.6 | +0.1% | -19.64 to +19.97 | STEADY, under the floor |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.06 | 90.99 | -0.1% | -0.3856 to +0.248 | STEADY, under the floor |
| response time, 95th percentile (ms) | 268.2 | 267.6 | -0.2% | -3.93 to +2.703 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.7 | 453.3 | -0.3% | -8.4 to +5.695 | STEADY, under the floor |
| temperature, peak (C) | 69.33 | 69 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 56.87 | 56.88 | +0.0% | -0.05162 to +0.06655 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.545e+05 | 1.543e+05 | -0.1% | -1532 to +1091 | STEADY, under the floor |
| power-capped share of samples | 0.7364 | 0.7351 | -0.2% | -0.01109 to +0.008556 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.69 -> 39.51 served requests per kJ, difference -0.1889 (95% interval -1.731 to +1.354).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*