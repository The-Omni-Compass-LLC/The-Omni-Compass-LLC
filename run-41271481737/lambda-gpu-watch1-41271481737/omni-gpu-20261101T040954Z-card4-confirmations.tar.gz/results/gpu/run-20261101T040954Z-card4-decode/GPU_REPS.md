# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.02 | 45.29 | 45.01 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.292e+05 | 1.284e+05 | 1.292e+05 |
| energy per served request (J) | 22.21 | 22.08 | 22.22 |
| power, GPU mean (W) | 202.8 | 202 | 203.4 |
| requests served | 5815 | 5815 | 5815 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.96 | 96.82 | 96.76 |
| response time, 95th percentile (ms) | 276.6 | 276.1 | 276 |
| response time, 99th percentile (ms) | 454 | 452.7 | 451.8 |
| temperature, peak (C) | 71 | 70.67 | 71 |
| temperature, mean (C) | 55.69 | 55.8 | 55.77 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.29e+05 | 1.289e+05 | 1.289e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.02 | 45.01 | -0.0% | -0.8584 to +0.8214 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.292e+05 | 1.292e+05 | +0.0% | -2355 to +2459 | STEADY, under the floor |
| energy per served request (J) | 22.21 | 22.22 | +0.0% | -0.4049 to +0.4228 | STEADY, under the floor |
| power, GPU mean (W) | 202.8 | 203.4 | +0.3% | -3.703 to +4.798 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.96 | 96.76 | -0.2% | -0.7204 to +0.3159 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.6 | 276 | -0.2% | -1.979 to +0.78 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454 | 451.8 | -0.5% | -6.699 to +2.247 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.69 | 55.77 | +0.1% | +0.01474 to +0.1484 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.29e+05 | 1.289e+05 | -0.0% | -568.3 to +449.7 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.02 | 45.29 | +0.6% | +0.075 to +0.4543 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.292e+05 | 1.284e+05 | -0.6% | -1293 to -215.4 | GAIN, clear of the noise |
| energy per served request (J) | 22.21 | 22.08 | -0.6% | -0.2224 to -0.03704 | GAIN, clear of the noise |
| power, GPU mean (W) | 202.8 | 202 | -0.4% | -1.351 to -0.1906 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.96 | 96.82 | -0.1% | -0.4342 to +0.1524 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.6 | 276.1 | -0.2% | -2.171 to +1.116 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454 | 452.7 | -0.3% | -6.014 to +3.374 | STEADY, under the floor |
| temperature, peak (C) | 71 | 70.67 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 55.69 | 55.8 | +0.2% | -0.1685 to +0.39 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.29e+05 | 1.289e+05 | -0.1% | -884.7 to +646.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.29 | 45.01 | -0.6% | -1.209 to +0.6424 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.284e+05 | 1.292e+05 | +0.6% | -1831 to +3443 | power given, not beyond the noise |
| energy per served request (J) | 22.08 | 22.22 | +0.6% | -0.3148 to +0.5922 | power given, not beyond the noise |
| power, GPU mean (W) | 202 | 203.4 | +0.7% | -2.353 to +4.99 | power given, not beyond the noise |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.82 | 96.76 | -0.1% | -0.635 to +0.5122 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.1 | 276 | -0.0% | -1.353 to +1.209 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.7 | 451.8 | -0.2% | -6.379 to +4.567 | STEADY, under the floor |
| temperature, peak (C) | 70.67 | 71 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 55.8 | 55.77 | -0.1% | -0.3752 to +0.3168 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.289e+05 | 1.289e+05 | +0.0% | -846.1 to +965.4 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.02 -> 45.01 served requests per kJ, difference -0.01851 (95% interval -0.8584 to +0.8214).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, clear of the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: NOT ATTRIBUTABLE: WATCH DIFFERS FROM NATIVE.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.205 | 0.261 | 0 | 444 | 31 | True |
| omni | 2 | 32 | 0 | 0 | 0 | 0.2 | 0.26 | 0 | 400 | 31 | True |
| omni | 3 | 34 | 0 | 0 | 0 | 0.208 | 0.356 | 0 | 390 | 33 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 63 | -9.913 | +0 |
| compass | 49 | 987 | +1491 | +15 |
| fail_up | 1 | 7 | -47.17 | +0 |
| race | 45 | 165 | -576.1 | -91 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 98.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*