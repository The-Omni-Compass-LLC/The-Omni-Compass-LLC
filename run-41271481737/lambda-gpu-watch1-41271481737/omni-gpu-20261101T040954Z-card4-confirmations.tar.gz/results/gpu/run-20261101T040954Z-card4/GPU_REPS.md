# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.49 | 38.83 | 38.86 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.601e+05 | 1.588e+05 | 1.586e+05 |
| energy per served request (J) | 25.98 | 25.76 | 25.73 |
| power, GPU mean (W) | 251.3 | 249.6 | 249 |
| requests served | 6164 | 6164 | 6164 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 89 | 88.99 | 89.04 |
| response time, 95th percentile (ms) | 252.8 | 252.6 | 252.8 |
| response time, 99th percentile (ms) | 446.2 | 446.6 | 446.1 |
| temperature, peak (C) | 78 | 77.67 | 78 |
| temperature, mean (C) | 63.78 | 63.81 | 63.78 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.59e+05 | 1.592e+05 | 1.591e+05 |
| power-capped share of samples | 0.7373 | 0.7463 | 0.739 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.49 | 38.86 | +1.0% | -0.2692 to +1.004 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.601e+05 | 1.586e+05 | -0.9% | -4120 to +1094 | GAIN, not beyond the noise |
| energy per served request (J) | 25.98 | 25.73 | -0.9% | -0.6683 to +0.1774 | GAIN, not beyond the noise |
| power, GPU mean (W) | 251.3 | 249 | -0.9% | -6.124 to +1.503 | GAIN, not beyond the noise |
| requests served | 6164 | 6164 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 89 | 89.04 | +0.1% | -0.195 to +0.2863 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.8 | 252.8 | -0.0% | -4.402 to +4.238 | STEADY, under the floor |
| response time, 99th percentile (ms) | 446.2 | 446.1 | -0.0% | -5.541 to +5.322 | STEADY, under the floor |
| temperature, peak (C) | 78 | 78 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 63.78 | 63.78 | +0.0% | -0.1636 to +0.1654 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.59e+05 | 1.591e+05 | +0.0% | -262.9 to +382.9 | STEADY, under the floor |
| power-capped share of samples | 0.7373 | 0.739 | +0.2% | -0.006824 to +0.01013 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.49 | 38.83 | +0.9% | -1.025 to +1.704 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.601e+05 | 1.588e+05 | -0.9% | -6992 to +4262 | GAIN, not beyond the noise |
| energy per served request (J) | 25.98 | 25.76 | -0.9% | -1.134 to +0.6915 | GAIN, not beyond the noise |
| power, GPU mean (W) | 251.3 | 249.6 | -0.7% | -10.59 to +7.004 | GAIN, not beyond the noise |
| requests served | 6164 | 6164 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 89 | 88.99 | -0.0% | -0.2497 to +0.2368 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.8 | 252.6 | -0.1% | -2.388 to +1.816 | STEADY, under the floor |
| response time, 99th percentile (ms) | 446.2 | 446.6 | +0.1% | -5.675 to +6.465 | STEADY, under the floor |
| temperature, peak (C) | 78 | 77.67 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 63.78 | 63.81 | +0.0% | -0.3259 to +0.3799 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.59e+05 | 1.592e+05 | +0.1% | -781.9 to +1105 | STEADY, under the floor |
| power-capped share of samples | 0.7373 | 0.7463 | +1.2% | -0.00386 to +0.02173 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.83 | 38.86 | +0.1% | -1.376 to +1.431 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.588e+05 | 1.586e+05 | -0.1% | -5958 to +5663 | STEADY, under the floor |
| energy per served request (J) | 25.76 | 25.73 | -0.1% | -0.9666 to +0.9186 | STEADY, under the floor |
| power, GPU mean (W) | 249.6 | 249 | -0.2% | -10.87 to +9.835 | STEADY, under the floor |
| requests served | 6164 | 6164 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.99 | 89.04 | +0.1% | -0.1308 to +0.2351 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.6 | 252.8 | +0.1% | -2.237 to +2.645 | STEADY, under the floor |
| response time, 99th percentile (ms) | 446.6 | 446.1 | -0.1% | -2.523 to +1.515 | STEADY, under the floor |
| temperature, peak (C) | 77.67 | 78 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 63.81 | 63.78 | -0.0% | -0.2398 to +0.1875 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.592e+05 | 1.591e+05 | -0.1% | -736.5 to +533.2 | STEADY, under the floor |
| power-capped share of samples | 0.7463 | 0.739 | -1.0% | -0.02611 to +0.01154 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.49 -> 38.86 served requests per kJ, difference +0.3672 (95% interval -0.2692 to +1.004).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*