# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 61.76 | 61.79 | 61.8 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.272e+04 | 9.279e+04 | 9.266e+04 |
| energy per served request (J) | 16.19 | 16.18 | 16.18 |
| power, GPU mean (W) | 276.2 | 275.4 | 276.5 |
| requests served | 5727 | 5734 | 5726 |
| requests not served | 1290 | 1284 | 1291 |
| response time, mean (ms) | 4.212e+04 | 4.206e+04 | 4.216e+04 |
| response time, 95th percentile (ms) | 8.05e+04 | 8.028e+04 | 8.052e+04 |
| response time, 99th percentile (ms) | 8.334e+04 | 8.322e+04 | 8.336e+04 |
| temperature, peak (C) | 72 | 71.5 | 72 |
| temperature, mean (C) | 68.51 | 67.68 | 68.48 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.286e+04 | 9.283e+04 | 9.267e+04 |
| power-capped share of samples | 0.9848 | 0.9818 | 0.9851 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.76 | 61.8 | +0.1% | -0.06848 to +0.1321 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.266e+04 | -0.1% | -1037 to +909.2 | STEADY, under the floor |
| energy per served request (J) | 16.19 | 16.18 | -0.1% | -0.03461 to +0.01793 | STEADY, under the floor |
| power, GPU mean (W) | 276.2 | 276.5 | +0.1% | -1.449 to +2.104 | STEADY, under the floor |
| requests served | 5727 | 5726 | -0.0% | -51.82 to +49.82 | STEADY, under the floor |
| requests not served | 1290 | 1291 | +0.1% | -49.82 to +51.82 | STEADY, under the floor |
| response time, mean (ms) | 4.212e+04 | 4.216e+04 | +0.1% | -1811 to +1893 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.05e+04 | 8.052e+04 | +0.0% | -2512 to +2560 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.334e+04 | 8.336e+04 | +0.0% | -2687 to +2730 | STEADY, under the floor |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.51 | 68.48 | -0.0% | -0.7271 to +0.6695 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.286e+04 | 9.267e+04 | -0.2% | -864.4 to +478 | STEADY, under the floor |
| power-capped share of samples | 0.9848 | 0.9851 | +0.0% | -0.003522 to +0.004085 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.76 | 61.79 | +0.0% | -3.905 to +3.961 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.279e+04 | +0.1% | -1833 to +1961 | STEADY, under the floor |
| energy per served request (J) | 16.19 | 16.18 | -0.0% | -1.037 to +1.023 | STEADY, under the floor |
| power, GPU mean (W) | 276.2 | 275.4 | -0.3% | -8.555 to +7.012 | STEADY, under the floor |
| requests served | 5727 | 5734 | +0.1% | -241.3 to +254.3 | STEADY, under the floor |
| requests not served | 1290 | 1284 | -0.5% | -254.3 to +241.3 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.212e+04 | 4.206e+04 | -0.2% | -6113 to +5984 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.05e+04 | 8.028e+04 | -0.3% | -1.13e+04 to +1.087e+04 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.334e+04 | 8.322e+04 | -0.1% | -1.053e+04 to +1.028e+04 | STEADY, under the floor |
| temperature, peak (C) | 72 | 71.5 | -0.7% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 68.51 | 67.68 | -1.2% | -9.386 to +7.734 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.286e+04 | 9.283e+04 | -0.0% | -1676 to +1611 | STEADY, under the floor |
| power-capped share of samples | 0.9848 | 0.9818 | -0.3% | -0.04087 to +0.03487 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.79 | 61.8 | +0.0% | -3.829 to +3.837 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.279e+04 | 9.266e+04 | -0.1% | -1052 to +795.6 | STEADY, under the floor |
| energy per served request (J) | 16.18 | 16.18 | -0.0% | -1.005 to +1.002 | STEADY, under the floor |
| power, GPU mean (W) | 275.4 | 276.5 | +0.4% | -8.461 to +10.66 | STEADY, under the floor |
| requests served | 5734 | 5726 | -0.1% | -306.1 to +291.1 | STEADY, under the floor |
| requests not served | 1284 | 1291 | +0.6% | -291.1 to +306.1 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.206e+04 | 4.216e+04 | +0.3% | -7795 to +8006 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.028e+04 | 8.052e+04 | +0.3% | -1.338e+04 to +1.386e+04 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.322e+04 | 8.336e+04 | +0.2% | -1.297e+04 to +1.326e+04 | STEADY, under the floor |
| temperature, peak (C) | 71.5 | 72 | +0.7% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 67.68 | 68.48 | +1.2% | -7.065 to +8.659 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.283e+04 | 9.267e+04 | -0.2% | -1133 to +811.8 | STEADY, under the floor |
| power-capped share of samples | 0.9818 | 0.9851 | +0.3% | -0.03079 to +0.03735 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 61.76 -> 61.8 served requests per kJ, difference +0.03183 (95% interval -0.06848 to +0.1321).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*