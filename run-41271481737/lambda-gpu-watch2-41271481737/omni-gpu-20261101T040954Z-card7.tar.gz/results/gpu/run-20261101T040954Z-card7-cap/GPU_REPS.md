# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.98 | 42.53 | 42.76 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.254e+04 | 6.173e+04 | 6.14e+04 |
| energy per served request (J) | 23.82 | 23.51 | 23.39 |
| power, GPU mean (W) | 186.1 | 184.3 | 183 |
| requests served | 2625 | 2625 | 2625 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 116.5 | 116.1 | 116.4 |
| response time, 95th percentile (ms) | 380.4 | 377 | 380 |
| response time, 99th percentile (ms) | 656.6 | 652.3 | 656.4 |
| temperature, peak (C) | 65 | 65 | 65 |
| temperature, mean (C) | 54.8 | 54.76 | 54.75 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.208e+04 | 6.193e+04 | 6.185e+04 |
| power-capped share of samples | 0.683 | 0.6782 | 0.6588 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.98 | 42.76 | +1.9% | -9.031 to +10.59 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.254e+04 | 6.14e+04 | -1.8% | -1.55e+04 to +1.322e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 23.82 | 23.39 | -1.8% | -5.904 to +5.036 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.1 | 183 | -1.7% | -44.76 to +38.59 | GAIN, not beyond the noise |
| requests served | 2625 | 2625 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 116.5 | 116.4 | -0.1% | -4.232 to +4.069 | STEADY, under the floor |
| response time, 95th percentile (ms) | 380.4 | 380 | -0.1% | -4.078 to +3.194 | STEADY, under the floor |
| response time, 99th percentile (ms) | 656.6 | 656.4 | -0.0% | -2.468 to +1.955 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.8 | 54.75 | -0.1% | -1.042 to +0.9382 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.208e+04 | 6.185e+04 | -0.4% | -2630 to +2156 | STEADY, under the floor |
| power-capped share of samples | 0.683 | 0.6588 | -3.5% | -0.101 to +0.05249 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.98 | 42.53 | +1.3% | -1.35 to +2.449 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.254e+04 | 6.173e+04 | -1.3% | -3763 to +2139 | GAIN, not beyond the noise |
| energy per served request (J) | 23.82 | 23.51 | -1.3% | -1.433 to +0.8149 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.1 | 184.3 | -1.0% | -12.32 to +8.744 | GAIN, not beyond the noise |
| requests served | 2625 | 2625 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 116.5 | 116.1 | -0.4% | -1.181 to +0.3226 | STEADY, under the floor |
| response time, 95th percentile (ms) | 380.4 | 377 | -0.9% | -28.35 to +21.55 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 656.6 | 652.3 | -0.7% | -10.2 to +1.609 | GAIN, not beyond the noise |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.8 | 54.76 | -0.1% | -1.366 to +1.284 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.208e+04 | 6.193e+04 | -0.2% | -885.9 to +584.3 | STEADY, under the floor |
| power-capped share of samples | 0.683 | 0.6782 | -0.7% | -0.04795 to +0.03838 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.53 | 42.76 | +0.5% | -7.682 to +8.139 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.173e+04 | 6.14e+04 | -0.5% | -1.174e+04 to +1.108e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 23.51 | 23.39 | -0.5% | -4.471 to +4.221 | GAIN, not beyond the noise |
| power, GPU mean (W) | 184.3 | 183 | -0.7% | -32.43 to +29.84 | GAIN, not beyond the noise |
| requests served | 2625 | 2625 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 116.1 | 116.4 | +0.3% | -4.555 to +5.25 | STEADY, under the floor |
| response time, 95th percentile (ms) | 377 | 380 | +0.8% | -25.63 to +31.55 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 652.3 | 656.4 | +0.6% | +0.3465 to +7.727 | LOSS, clear of the noise |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.76 | 54.75 | -0.0% | -0.3459 to +0.3241 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.193e+04 | 6.185e+04 | -0.1% | -1744 to +1572 | STEADY, under the floor |
| power-capped share of samples | 0.6782 | 0.6588 | -2.9% | -0.1393 to +0.1004 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.98 -> 42.76 served requests per kJ, difference +0.7784 (95% interval -9.031 to +10.59).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 14.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*