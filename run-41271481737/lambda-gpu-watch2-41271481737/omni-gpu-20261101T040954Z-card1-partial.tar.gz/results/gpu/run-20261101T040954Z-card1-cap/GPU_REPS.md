# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.82 | 43.75 | 44.02 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.242e+04 | 6.252e+04 | 6.213e+04 |
| energy per served request (J) | 22.82 | 22.86 | 22.72 |
| power, GPU mean (W) | 186.3 | 185.8 | 185.5 |
| requests served | 2735 | 2735 | 2735 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 107.2 | 106.6 | 107.7 |
| response time, 95th percentile (ms) | 338.1 | 332.4 | 339.3 |
| response time, 99th percentile (ms) | 592.1 | 595.8 | 594 |
| temperature, peak (C) | 58 | 58 | 58 |
| temperature, mean (C) | 49.57 | 49.43 | 49.42 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.258e+04 | 6.26e+04 | 6.208e+04 |
| power-capped share of samples | 0.6806 | 0.6792 | 0.6453 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.82 | 44.02 | +0.5% | -2.473 to +2.877 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.242e+04 | 6.213e+04 | -0.5% | -4094 to +3519 | STEADY, under the floor |
| energy per served request (J) | 22.82 | 22.72 | -0.5% | -1.497 to +1.287 | STEADY, under the floor |
| power, GPU mean (W) | 186.3 | 185.5 | -0.5% | -12.66 to +10.93 | STEADY, under the floor |
| requests served | 2735 | 2735 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 107.2 | 107.7 | +0.4% | -1.726 to +2.683 | STEADY, under the floor |
| response time, 95th percentile (ms) | 338.1 | 339.3 | +0.3% | -4.905 to +7.168 | STEADY, under the floor |
| response time, 99th percentile (ms) | 592.1 | 594 | +0.3% | -22.95 to +26.95 | STEADY, under the floor |
| temperature, peak (C) | 58 | 58 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.57 | 49.42 | -0.3% | -0.2843 to -0.01519 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.258e+04 | 6.208e+04 | -0.8% | -1740 to +748 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6806 | 0.6453 | -5.2% | -0.1555 to +0.08493 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.82 | 43.75 | -0.2% | -3.057 to +2.922 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.242e+04 | 6.252e+04 | +0.2% | -4166 to +4357 | STEADY, under the floor |
| energy per served request (J) | 22.82 | 22.86 | +0.2% | -1.523 to +1.593 | STEADY, under the floor |
| power, GPU mean (W) | 186.3 | 185.8 | -0.3% | -23.31 to +22.2 | STEADY, under the floor |
| requests served | 2735 | 2735 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 107.2 | 106.6 | -0.6% | -10.27 to +9.084 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 338.1 | 332.4 | -1.7% | -92.82 to +81.45 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 592.1 | 595.8 | +0.6% | -19.52 to +26.98 | LOSS, not beyond the noise |
| temperature, peak (C) | 58 | 58 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.57 | 49.43 | -0.3% | -0.5973 to +0.3278 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.258e+04 | 6.26e+04 | +0.0% | -1182 to +1232 | STEADY, under the floor |
| power-capped share of samples | 0.6806 | 0.6792 | -0.2% | -0.04818 to +0.04529 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.75 | 44.02 | +0.6% | -0.04463 to +0.5834 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.252e+04 | 6.213e+04 | -0.6% | -837.3 to +72.01 | GAIN, not beyond the noise |
| energy per served request (J) | 22.86 | 22.72 | -0.6% | -0.3061 to +0.02633 | GAIN, not beyond the noise |
| power, GPU mean (W) | 185.8 | 185.5 | -0.2% | -11.27 to +10.66 | STEADY, under the floor |
| requests served | 2735 | 2735 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 106.6 | 107.7 | +1.0% | -6.4 to +8.541 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 332.4 | 339.3 | +2.1% | -86.36 to +99.99 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 595.8 | 594 | -0.3% | -3.433 to -0.02948 | STEADY, under the floor |
| temperature, peak (C) | 58 | 58 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.43 | 49.42 | -0.0% | -0.6121 to +0.5821 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.26e+04 | 6.208e+04 | -0.8% | -2972 to +1930 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6792 | 0.6453 | -5.0% | -0.2008 to +0.1331 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.82 -> 44.02 served requests per kJ, difference +0.2019 (95% interval -2.473 to +2.877).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 22.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*