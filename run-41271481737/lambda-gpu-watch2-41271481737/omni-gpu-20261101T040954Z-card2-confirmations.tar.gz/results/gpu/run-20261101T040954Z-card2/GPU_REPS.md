# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.27 | 40.11 | 40.17 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.537e+05 | 1.542e+05 | 1.54e+05 |
| energy per served request (J) | 24.84 | 24.93 | 24.9 |
| power, GPU mean (W) | 241.2 | 242.8 | 242.7 |
| requests served | 6187 | 6187 | 6187 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 87.02 | 86.99 | 87.05 |
| response time, 95th percentile (ms) | 243.3 | 242.7 | 242.8 |
| response time, 99th percentile (ms) | 432.1 | 432.3 | 431.2 |
| temperature, peak (C) | 67 | 67 | 67 |
| temperature, mean (C) | 55.62 | 55.71 | 55.7 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.541e+05 | 1.541e+05 | 1.538e+05 |
| power-capped share of samples | 0.7369 | 0.7388 | 0.7371 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.27 | 40.17 | -0.3% | -2.042 to +1.841 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.537e+05 | 1.54e+05 | +0.2% | -7116 to +7877 | STEADY, under the floor |
| energy per served request (J) | 24.84 | 24.9 | +0.2% | -1.15 to +1.273 | STEADY, under the floor |
| power, GPU mean (W) | 241.2 | 242.7 | +0.7% | -7.919 to +11.08 | power given, not beyond the noise |
| requests served | 6187 | 6187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.02 | 87.05 | +0.0% | -0.2812 to +0.3405 | STEADY, under the floor |
| response time, 95th percentile (ms) | 243.3 | 242.8 | -0.2% | -1.416 to +0.3086 | STEADY, under the floor |
| response time, 99th percentile (ms) | 432.1 | 431.2 | -0.2% | -2.165 to +0.408 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.62 | 55.7 | +0.1% | -0.06434 to +0.2262 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.541e+05 | 1.538e+05 | -0.2% | -900.2 to +206.2 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7371 | +0.0% | -0.006145 to +0.006612 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.27 | 40.11 | -0.4% | -1.283 to +0.9762 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.537e+05 | 1.542e+05 | +0.4% | -3781 to +4929 | STEADY, under the floor |
| energy per served request (J) | 24.84 | 24.93 | +0.4% | -0.6111 to +0.7967 | STEADY, under the floor |
| power, GPU mean (W) | 241.2 | 242.8 | +0.7% | -2.963 to +6.167 | power given, not beyond the noise |
| requests served | 6187 | 6187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.02 | 86.99 | -0.0% | -0.0848 to +0.02413 | STEADY, under the floor |
| response time, 95th percentile (ms) | 243.3 | 242.7 | -0.3% | -1.93 to +0.6639 | STEADY, under the floor |
| response time, 99th percentile (ms) | 432.1 | 432.3 | +0.1% | -3.883 to +4.417 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.62 | 55.71 | +0.2% | +0.0719 to +0.1111 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.541e+05 | 1.541e+05 | -0.0% | -909.6 to +773.2 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7388 | +0.3% | -0.0174 to +0.02121 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.11 | 40.17 | +0.1% | -0.7614 to +0.8667 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.542e+05 | 1.54e+05 | -0.1% | -3344 to +2956 | STEADY, under the floor |
| energy per served request (J) | 24.93 | 24.9 | -0.1% | -0.5405 to +0.4778 | STEADY, under the floor |
| power, GPU mean (W) | 242.8 | 242.7 | -0.0% | -5.081 to +5.04 | STEADY, under the floor |
| requests served | 6187 | 6187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 86.99 | 87.05 | +0.1% | -0.1974 to +0.3174 | STEADY, under the floor |
| response time, 95th percentile (ms) | 242.7 | 242.8 | +0.0% | -1.985 to +2.145 | STEADY, under the floor |
| response time, 99th percentile (ms) | 432.3 | 431.2 | -0.3% | -4.411 to +2.12 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.71 | 55.7 | -0.0% | -0.1369 to +0.1157 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.541e+05 | 1.538e+05 | -0.2% | -917.9 to +360.3 | STEADY, under the floor |
| power-capped share of samples | 0.7388 | 0.7371 | -0.2% | -0.01482 to +0.01148 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.27 -> 40.17 served requests per kJ, difference -0.1007 (95% interval -2.042 to +1.841).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*