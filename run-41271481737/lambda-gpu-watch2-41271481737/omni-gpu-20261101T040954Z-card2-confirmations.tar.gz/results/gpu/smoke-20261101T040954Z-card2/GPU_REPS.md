# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
1 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.18 | 38.95 | 39.1 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.753e+04 | 4.781e+04 | 4.762e+04 |
| energy per served request (J) | 25.53 | 25.68 | 25.58 |
| power, GPU mean (W) | 221.8 | 223.1 | 222.2 |
| requests served | 1862 | 1862 | 1862 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 92.06 | 91.91 | 91.3 |
| response time, 95th percentile (ms) | 280.3 | 280.8 | 278 |
| response time, 99th percentile (ms) | 520 | 518.3 | 514.5 |
| temperature, peak (C) | 68 | 67 | 67 |
| temperature, mean (C) | 53.9 | 54.05 | 53.27 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.808e+04 | 4.796e+04 | 4.788e+04 |
| power-capped share of samples | 0.6779 | 0.6683 | 0.6818 |

## Total: Omni governs against native, 1 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.18 | 39.1 | -0.2% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.753e+04 | 4.762e+04 | +0.2% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 25.53 | 25.58 | +0.2% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 221.8 | 222.2 | +0.2% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1862 | 1862 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 92.06 | 91.3 | -0.8% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 280.3 | 278 | -0.8% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 520 | 514.5 | -1.1% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 68 | 67 | -1.5% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 53.9 | 53.27 | -1.2% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.808e+04 | 4.788e+04 | -0.4% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6779 | 0.6818 | +0.6% | +nan to +nan | no interval (too few repetitions) |

## Observation: omni watching (writes nothing) against native, 1 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.18 | 38.95 | -0.6% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.753e+04 | 4.781e+04 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 25.53 | 25.68 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 221.8 | 223.1 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1862 | 1862 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 92.06 | 91.91 | -0.2% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 280.3 | 280.8 | +0.2% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 520 | 518.3 | -0.3% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 68 | 67 | -1.5% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 53.9 | 54.05 | +0.3% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.808e+04 | 4.796e+04 | -0.3% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6779 | 0.6683 | -1.4% | +nan to +nan | no interval (too few repetitions) |

## Authority: Omni governs against Omni watching, 1 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.95 | 39.1 | +0.4% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.781e+04 | 4.762e+04 | -0.4% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 25.68 | 25.58 | -0.4% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 223.1 | 222.2 | -0.4% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1862 | 1862 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 91.91 | 91.3 | -0.7% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 280.8 | 278 | -1.0% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 518.3 | 514.5 | -0.7% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 67 | 67 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 54.05 | 53.27 | -1.4% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.796e+04 | 4.788e+04 | -0.2% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6683 | 0.6818 | +2.0% | +nan to +nan | no interval (too few repetitions) |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.18 -> 39.1 served requests per kJ, difference -0.07851 (95% interval +nan to +nan).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: no interval (too few repetitions). Authority (omni against watch): no interval (too few repetitions).
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 95 | 0 | n/a | n/a | 0 | 95 | 0 |
| watch | 1 | 94 | 0 | n/a | n/a | 0 | 94 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*