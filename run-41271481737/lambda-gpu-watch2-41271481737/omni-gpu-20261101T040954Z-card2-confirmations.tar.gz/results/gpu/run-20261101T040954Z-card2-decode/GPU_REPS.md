# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 48.19 | 47.98 | 48.05 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.209e+05 | 1.214e+05 | 1.212e+05 |
| energy per served request (J) | 20.75 | 20.84 | 20.81 |
| power, GPU mean (W) | 189.9 | 190.2 | 190.4 |
| requests served | 5824 | 5824 | 5824 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.7 | 96.85 | 96.66 |
| response time, 95th percentile (ms) | 275.4 | 275.9 | 275.2 |
| response time, 99th percentile (ms) | 452.4 | 454.3 | 452 |
| temperature, peak (C) | 60 | 60 | 60 |
| temperature, mean (C) | 49.15 | 49.1 | 49.18 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.21e+05 | 1.211e+05 | 1.211e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 48.19 | 48.05 | -0.3% | -1.784 to +1.511 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.209e+05 | 1.212e+05 | +0.3% | -3815 to +4511 | STEADY, under the floor |
| energy per served request (J) | 20.75 | 20.81 | +0.3% | -0.6551 to +0.7745 | STEADY, under the floor |
| power, GPU mean (W) | 189.9 | 190.4 | +0.3% | -6.608 to +7.65 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.7 | 96.66 | -0.0% | -0.2245 to +0.1526 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.4 | 275.2 | -0.1% | -1.419 to +1.122 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.4 | 452 | -0.1% | -1.683 to +0.7935 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.15 | 49.18 | +0.1% | -0.2048 to +0.2558 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.21e+05 | 1.211e+05 | +0.0% | -506.6 to +559.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 48.19 | 47.98 | -0.4% | -1.208 to +0.8035 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.209e+05 | 1.214e+05 | +0.4% | -2036 to +3063 | STEADY, under the floor |
| energy per served request (J) | 20.75 | 20.84 | +0.4% | -0.3496 to +0.526 | STEADY, under the floor |
| power, GPU mean (W) | 189.9 | 190.2 | +0.2% | -2.379 to +2.974 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.7 | 96.85 | +0.2% | -0.08496 to +0.3792 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.4 | 275.9 | +0.2% | -0.3835 to +1.436 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.4 | 454.3 | +0.4% | -0.6242 to +4.341 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.15 | 49.1 | -0.1% | -0.1455 to +0.03548 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.21e+05 | 1.211e+05 | +0.0% | -303.9 to +363 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.98 | 48.05 | +0.1% | -2.067 to +2.198 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.214e+05 | 1.212e+05 | -0.1% | -5559 to +5227 | STEADY, under the floor |
| energy per served request (J) | 20.84 | 20.81 | -0.1% | -0.9545 to +0.8976 | STEADY, under the floor |
| power, GPU mean (W) | 190.2 | 190.4 | +0.1% | -7.391 to +7.839 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.85 | 96.66 | -0.2% | -0.4918 to +0.1257 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.9 | 275.2 | -0.2% | -2.16 to +0.8104 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.3 | 452 | -0.5% | -5.151 to +0.5447 | GAIN, not beyond the noise |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.1 | 49.18 | +0.2% | -0.1388 to +0.2999 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.211e+05 | 1.211e+05 | -0.0% | -864.2 to +857.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 48.19 -> 48.05 served requests per kJ, difference -0.1365 (95% interval -1.784 to +1.511).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 24 | 0 | 0 | 0 | 0.204 | 0.36 | 0 | 928 | 23 | True |
| omni | 2 | 30 | 0 | 0 | 0 | 0.204 | 0.301 | 0 | 1.2e+03 | 29 | True |
| omni | 3 | 36 | 0 | 0 | 0 | 0.205 | 0.332 | 0 | 1.43e+03 | 35 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 2 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 284 | 0 | n/a | n/a | 0 | 284 | 0 |
| watch | 3 | 283 | 0 | n/a | n/a | 0 | 283 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 65 | +45.66 | +0 |
| compass | 45 | 993 | -2500 | +52 |
| race | 42 | 173 | -90.13 | -58 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 90.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*