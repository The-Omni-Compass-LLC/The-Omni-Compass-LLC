# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.29 | 42.31 | 42.66 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 5.958e+04 | 6.096e+04 | 6.045e+04 |
| energy per served request (J) | 23.1 | 23.64 | 23.44 |
| power, GPU mean (W) | 176.8 | 181.1 | 179.3 |
| requests served | 2579 | 2579 | 2579 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 111.4 | 111.1 | 112.4 |
| response time, 95th percentile (ms) | 352.1 | 351.9 | 354.9 |
| response time, 99th percentile (ms) | 620.7 | 619.7 | 622.6 |
| temperature, peak (C) | 60 | 60 | 60 |
| temperature, mean (C) | 49.82 | 49.85 | 49.74 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.096e+04 | 6.094e+04 | 6.061e+04 |
| power-capped share of samples | 0.6717 | 0.67 | 0.6455 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.29 | 42.66 | -1.4% | -3.594 to +2.35 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.958e+04 | 6.045e+04 | +1.5% | -3303 to +5041 | power given, not beyond the noise |
| energy per served request (J) | 23.1 | 23.44 | +1.5% | -1.281 to +1.955 | power given, not beyond the noise |
| power, GPU mean (W) | 176.8 | 179.3 | +1.4% | -7.014 to +12.01 | power given, not beyond the noise |
| requests served | 2579 | 2579 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.4 | 112.4 | +0.9% | -3.665 to +5.675 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 352.1 | 354.9 | +0.8% | -58.23 to +63.71 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 620.7 | 622.6 | +0.3% | -42.45 to +46.31 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.82 | 49.74 | -0.2% | -0.3631 to +0.1923 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.096e+04 | 6.061e+04 | -0.6% | -1014 to +314 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6717 | 0.6455 | -3.9% | -0.1296 to +0.07737 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.29 | 42.31 | -2.3% | -1.384 to -0.577 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.958e+04 | 6.096e+04 | +2.3% | +860.7 to +1900 | power given, clear of the noise |
| energy per served request (J) | 23.1 | 23.64 | +2.3% | +0.3337 to +0.7368 | power given, clear of the noise |
| power, GPU mean (W) | 176.8 | 181.1 | +2.4% | +1.786 to +6.821 | power given, clear of the noise |
| requests served | 2579 | 2579 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.4 | 111.1 | -0.3% | -7.373 to +6.795 | STEADY, under the floor |
| response time, 95th percentile (ms) | 352.1 | 351.9 | -0.1% | -41.99 to +41.62 | STEADY, under the floor |
| response time, 99th percentile (ms) | 620.7 | 619.7 | -0.2% | -29.87 to +27.84 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.82 | 49.85 | +0.1% | -0.6193 to +0.6805 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.096e+04 | 6.094e+04 | -0.0% | -434.9 to +380.6 | STEADY, under the floor |
| power-capped share of samples | 0.6717 | 0.67 | -0.2% | -0.04298 to +0.03974 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.31 | 42.66 | +0.8% | -2.21 to +2.927 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.096e+04 | 6.045e+04 | -0.8% | -4164 to +3141 | GAIN, not beyond the noise |
| energy per served request (J) | 23.64 | 23.44 | -0.8% | -1.615 to +1.218 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.1 | 179.3 | -1.0% | -13.84 to +10.23 | GAIN, not beyond the noise |
| requests served | 2579 | 2579 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.1 | 112.4 | +1.2% | -1.119 to +3.708 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 351.9 | 354.9 | +0.8% | -16.23 to +22.09 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 619.7 | 622.6 | +0.5% | -12.58 to +18.47 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.85 | 49.74 | -0.2% | -0.4882 to +0.2562 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.094e+04 | 6.061e+04 | -0.5% | -579.1 to -66.58 | GAIN, clear of the noise |
| power-capped share of samples | 0.67 | 0.6455 | -3.7% | -0.1694 to +0.1204 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.29 -> 42.66 served requests per kJ, difference -0.6217 (95% interval -3.594 to +2.35).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, clear of the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: NOT ATTRIBUTABLE: WATCH DIFFERS FROM NATIVE.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*