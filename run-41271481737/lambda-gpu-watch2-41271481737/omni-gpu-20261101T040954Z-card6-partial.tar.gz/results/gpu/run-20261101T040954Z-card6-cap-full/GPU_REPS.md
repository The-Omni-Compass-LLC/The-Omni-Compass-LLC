# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.78 | 61.07 | 60.81 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.281e+04 | 9.273e+04 | 9.272e+04 |
| energy per served request (J) | 16.45 | 16.38 | 16.44 |
| power, GPU mean (W) | 274 | 275.3 | 275.2 |
| requests served | 5641 | 5662 | 5638 |
| requests not served | 1192 | 1170 | 1194 |
| response time, mean (ms) | 4.075e+04 | 4.065e+04 | 4.078e+04 |
| response time, 95th percentile (ms) | 7.757e+04 | 7.676e+04 | 7.771e+04 |
| response time, 99th percentile (ms) | 8.07e+04 | 7.966e+04 | 8.084e+04 |
| temperature, peak (C) | 63.5 | 64 | 64 |
| temperature, mean (C) | 61.11 | 61.66 | 61.71 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.287e+04 | 9.284e+04 | 9.273e+04 |
| power-capped share of samples | 0.9776 | 0.9818 | 0.9806 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.78 | 60.81 | +0.0% | -1.794 to +1.853 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.281e+04 | 9.272e+04 | -0.1% | -1510 to +1338 | STEADY, under the floor |
| energy per served request (J) | 16.45 | 16.44 | -0.0% | -0.5013 to +0.4853 | STEADY, under the floor |
| power, GPU mean (W) | 274 | 275.2 | +0.4% | -18.71 to +21.02 | STEADY, under the floor |
| requests served | 5641 | 5638 | -0.0% | -85.09 to +80.09 | STEADY, under the floor |
| requests not served | 1192 | 1194 | +0.2% | -80.09 to +85.09 | STEADY, under the floor |
| response time, mean (ms) | 4.075e+04 | 4.078e+04 | +0.1% | -2173 to +2236 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.757e+04 | 7.771e+04 | +0.2% | -4169 to +4452 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.07e+04 | 8.084e+04 | +0.2% | -4351 to +4640 | STEADY, under the floor |
| temperature, peak (C) | 63.5 | 64 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 61.11 | 61.71 | +1.0% | -3.903 to +5.098 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.273e+04 | -0.1% | -2007 to +1733 | STEADY, under the floor |
| power-capped share of samples | 0.9776 | 0.9806 | +0.3% | -0.04986 to +0.0558 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.78 | 61.07 | +0.5% | -1.085 to +1.655 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.281e+04 | 9.273e+04 | -0.1% | -2062 to +1898 | STEADY, under the floor |
| energy per served request (J) | 16.45 | 16.38 | -0.5% | -0.4421 to +0.2886 | STEADY, under the floor |
| power, GPU mean (W) | 274 | 275.3 | +0.5% | -17.25 to +19.78 | STEADY, under the floor |
| requests served | 5641 | 5662 | +0.4% | -226.3 to +269.3 | STEADY, under the floor |
| requests not served | 1192 | 1170 | -1.8% | -269.3 to +226.3 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.075e+04 | 4.065e+04 | -0.2% | -221.7 to +34.22 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.757e+04 | 7.676e+04 | -1.0% | -1.023e+04 to +8622 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.07e+04 | 7.966e+04 | -1.3% | -1.327e+04 to +1.12e+04 | GAIN, not beyond the noise |
| temperature, peak (C) | 63.5 | 64 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 61.11 | 61.66 | +0.9% | -3.325 to +4.422 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.284e+04 | -0.0% | -929.5 to +868.1 | STEADY, under the floor |
| power-capped share of samples | 0.9776 | 0.9818 | +0.4% | -0.06391 to +0.07225 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.07 | 60.81 | -0.4% | -3.449 to +2.938 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.273e+04 | 9.272e+04 | -0.0% | -560.7 to +552.2 | STEADY, under the floor |
| energy per served request (J) | 16.38 | 16.44 | +0.4% | -0.7899 to +0.9274 | STEADY, under the floor |
| power, GPU mean (W) | 275.3 | 275.2 | -0.0% | -1.46 to +1.234 | STEADY, under the floor |
| requests served | 5662 | 5638 | -0.4% | -354.4 to +306.4 | STEADY, under the floor |
| requests not served | 1170 | 1194 | +2.1% | -306.4 to +354.4 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.065e+04 | 4.078e+04 | +0.3% | -2207 to +2458 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.676e+04 | 7.771e+04 | +1.2% | -1.279e+04 to +1.469e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.966e+04 | 8.084e+04 | +1.5% | -1.555e+04 to +1.791e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 61.66 | 61.71 | +0.1% | -0.5779 to +0.6753 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.284e+04 | 9.273e+04 | -0.1% | -1078 to +864.7 | STEADY, under the floor |
| power-capped share of samples | 0.9818 | 0.9806 | -0.1% | -0.01645 to +0.01405 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.78 -> 60.81 served requests per kJ, difference +0.02957 (95% interval -1.794 to +1.853).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*