# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.61 | 60.6 | 60.66 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.28e+04 | 9.283e+04 | 9.272e+04 |
| energy per served request (J) | 16.5 | 16.5 | 16.48 |
| power, GPU mean (W) | 274.3 | 274.7 | 274.5 |
| requests served | 5624 | 5625 | 5625 |
| requests not served | 1264 | 1264 | 1264 |
| response time, mean (ms) | 4.224e+04 | 4.219e+04 | 4.227e+04 |
| response time, 95th percentile (ms) | 8.061e+04 | 8.059e+04 | 8.059e+04 |
| response time, 99th percentile (ms) | 8.387e+04 | 8.385e+04 | 8.386e+04 |
| temperature, peak (C) | 63 | 63 | 63 |
| temperature, mean (C) | 60.75 | 60.86 | 60.31 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.289e+04 | 9.286e+04 | 9.291e+04 |
| power-capped share of samples | 0.9776 | 0.9794 | 0.973 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.61 | 60.66 | +0.1% | -0.6056 to +0.717 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.28e+04 | 9.272e+04 | -0.1% | -1401 to +1247 | STEADY, under the floor |
| energy per served request (J) | 16.5 | 16.48 | -0.1% | -0.1946 to +0.1644 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.5 | +0.1% | -14.2 to +14.51 | STEADY, under the floor |
| requests served | 5624 | 5625 | +0.0% | -18.56 to +19.56 | STEADY, under the floor |
| requests not served | 1264 | 1264 | -0.0% | -19.56 to +18.56 | STEADY, under the floor |
| response time, mean (ms) | 4.224e+04 | 4.227e+04 | +0.1% | -2077 to +2140 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.061e+04 | 8.059e+04 | -0.0% | -1381 to +1346 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.387e+04 | 8.386e+04 | -0.0% | -1372 to +1343 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.75 | 60.31 | -0.7% | -5.543 to +4.664 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.289e+04 | 9.291e+04 | +0.0% | -299.6 to +335.2 | STEADY, under the floor |
| power-capped share of samples | 0.9776 | 0.973 | -0.5% | -0.03289 to +0.02371 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.61 | 60.6 | -0.0% | -0.6202 to +0.596 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.28e+04 | 9.283e+04 | +0.0% | -1009 to +1063 | STEADY, under the floor |
| energy per served request (J) | 16.5 | 16.5 | +0.0% | -0.1623 to +0.1689 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.7 | +0.1% | -9.908 to +10.61 | STEADY, under the floor |
| requests served | 5624 | 5625 | +0.0% | -5.853 to +6.853 | STEADY, under the floor |
| requests not served | 1264 | 1264 | -0.0% | -6.853 to +5.853 | STEADY, under the floor |
| response time, mean (ms) | 4.224e+04 | 4.219e+04 | -0.1% | -102.5 to +4.404 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.061e+04 | 8.059e+04 | -0.0% | -143.1 to +104.8 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.387e+04 | 8.385e+04 | -0.0% | -246.4 to +203.8 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.75 | 60.86 | +0.2% | -1.09 to +1.317 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.289e+04 | 9.286e+04 | -0.0% | -1409 to +1362 | STEADY, under the floor |
| power-capped share of samples | 0.9776 | 0.9794 | +0.2% | -0.04313 to +0.04669 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.6 | 60.66 | +0.1% | -1.202 to +1.337 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.283e+04 | 9.272e+04 | -0.1% | -2464 to +2257 | STEADY, under the floor |
| energy per served request (J) | 16.5 | 16.48 | -0.1% | -0.3635 to +0.3266 | STEADY, under the floor |
| power, GPU mean (W) | 274.7 | 274.5 | -0.1% | -24.81 to +24.41 | STEADY, under the floor |
| requests served | 5625 | 5625 | +0.0% | -25.41 to +25.41 | STEADY, under the floor |
| requests not served | 1264 | 1264 | +0.0% | -25.41 to +25.41 | STEADY, under the floor |
| response time, mean (ms) | 4.219e+04 | 4.227e+04 | +0.2% | -2082 to +2242 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.059e+04 | 8.059e+04 | +0.0% | -1486 to +1489 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.385e+04 | 8.386e+04 | +0.0% | -1576 to +1589 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.86 | 60.31 | -0.9% | -4.453 to +3.347 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.286e+04 | 9.291e+04 | +0.0% | -1662 to +1744 | STEADY, under the floor |
| power-capped share of samples | 0.9794 | 0.973 | -0.7% | -0.02299 to +0.01024 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.61 -> 60.66 served requests per kJ, difference +0.0557 (95% interval -0.6056 to +0.717).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*