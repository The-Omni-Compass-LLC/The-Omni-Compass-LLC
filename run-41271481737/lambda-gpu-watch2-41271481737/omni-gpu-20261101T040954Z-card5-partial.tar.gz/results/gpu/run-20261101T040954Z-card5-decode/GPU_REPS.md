# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 46.34 | 46.43 | 46.51 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.255e+05 | 1.252e+05 | 1.25e+05 |
| energy per served request (J) | 21.58 | 21.54 | 21.5 |
| power, GPU mean (W) | 197.1 | 196.1 | 196.4 |
| requests served | 5815 | 5815 | 5815 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.83 | 96.67 | 96.66 |
| response time, 95th percentile (ms) | 276.2 | 275.7 | 275.8 |
| response time, 99th percentile (ms) | 452.9 | 451.6 | 451.5 |
| temperature, peak (C) | 61 | 61 | 61 |
| temperature, mean (C) | 49.42 | 49.35 | 49.44 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.258e+05 | 1.258e+05 | 1.256e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.34 | 46.51 | +0.4% | -0.1328 to +0.4728 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.255e+05 | 1.25e+05 | -0.4% | -1278 to +358.2 | STEADY, under the floor |
| energy per served request (J) | 21.58 | 21.5 | -0.4% | -0.2197 to +0.06161 | STEADY, under the floor |
| power, GPU mean (W) | 197.1 | 196.4 | -0.4% | -1.214 to -0.2521 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.83 | 96.66 | -0.2% | -0.6223 to +0.2922 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.2 | 275.8 | -0.1% | -2.395 to +1.765 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.9 | 451.5 | -0.3% | -4.806 to +2.126 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.42 | 49.44 | +0.0% | -0.1719 to +0.2145 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.258e+05 | 1.256e+05 | -0.1% | -297 to -53.95 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.34 | 46.43 | +0.2% | -0.04312 to +0.2258 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.255e+05 | 1.252e+05 | -0.2% | -612.7 to +117.9 | STEADY, under the floor |
| energy per served request (J) | 21.58 | 21.54 | -0.2% | -0.1054 to +0.02027 | STEADY, under the floor |
| power, GPU mean (W) | 197.1 | 196.1 | -0.5% | -2.362 to +0.4092 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.83 | 96.67 | -0.2% | -0.5713 to +0.2507 | STEADY, under the floor |
| response time, 95th percentile (ms) | 276.2 | 275.7 | -0.2% | -2.248 to +1.257 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.9 | 451.6 | -0.3% | -4.374 to +1.903 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.42 | 49.35 | -0.1% | -0.3004 to +0.1628 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.258e+05 | 1.258e+05 | -0.0% | -637.8 to +564.4 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.43 | 46.51 | +0.2% | -0.09026 to +0.2477 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.252e+05 | 1.25e+05 | -0.2% | -666.6 to +242.1 | STEADY, under the floor |
| energy per served request (J) | 21.54 | 21.5 | -0.2% | -0.1146 to +0.04163 | STEADY, under the floor |
| power, GPU mean (W) | 196.1 | 196.4 | +0.1% | -1.609 to +2.095 | STEADY, under the floor |
| requests served | 5815 | 5815 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.67 | 96.66 | -0.0% | -0.1837 to +0.1742 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.7 | 275.8 | +0.1% | -1.05 to +1.41 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.6 | 451.5 | -0.0% | -0.7332 to +0.5238 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.35 | 49.44 | +0.2% | -0.249 to +0.4293 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.258e+05 | 1.256e+05 | -0.1% | -859.1 to +581.6 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 46.34 -> 46.51 served requests per kJ, difference +0.17 (95% interval -0.1328 to +0.4728).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 38 | 0 | 0 | 0 | 0.211 | 0.324 | 0 | 890 | 37 | True |
| omni | 2 | 34 | 0 | 0 | 0 | 0.202 | 0.279 | 0 | 856 | 33 | True |
| omni | 3 | 28 | 0 | 0 | 0 | 0.205 | 0.3 | 0 | 710 | 27 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 283 | 0 | n/a | n/a | 0 | 283 | 0 |
| watch | 3 | 283 | 0 | n/a | n/a | 0 | 283 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | +27.96 | +0 |
| compass | 50 | 972 | -2027 | +84 |
| fail_up | 1 | 2 | -140.4 | -3 |
| race | 46 | 170 | -1023 | -81 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 100.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*