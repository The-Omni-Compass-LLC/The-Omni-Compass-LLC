# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.57 | 38.88 | 38.79 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.574e+05 | 1.562e+05 | 1.566e+05 |
| energy per served request (J) | 25.93 | 25.72 | 25.78 |
| power, GPU mean (W) | 247.4 | 245.9 | 246.7 |
| requests served | 6072 | 6072 | 6072 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 91.01 | 90.99 | 90.93 |
| response time, 95th percentile (ms) | 269.9 | 269.2 | 268.7 |
| response time, 99th percentile (ms) | 457.6 | 457 | 456.8 |
| temperature, peak (C) | 69 | 69 | 69 |
| temperature, mean (C) | 56.47 | 56.51 | 56.52 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.565e+05 | 1.564e+05 | 1.564e+05 |
| power-capped share of samples | 0.7333 | 0.7352 | 0.7345 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.57 | 38.79 | +0.6% | -1.387 to +1.824 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.574e+05 | 1.566e+05 | -0.6% | -7444 to +5660 | GAIN, not beyond the noise |
| energy per served request (J) | 25.93 | 25.78 | -0.6% | -1.226 to +0.9322 | GAIN, not beyond the noise |
| power, GPU mean (W) | 247.4 | 246.7 | -0.3% | -9.031 to +7.716 | STEADY, under the floor |
| requests served | 6072 | 6072 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.01 | 90.93 | -0.1% | -0.3731 to +0.2216 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.9 | 268.7 | -0.5% | -2.527 to +0.04465 | STEADY, under the floor |
| response time, 99th percentile (ms) | 457.6 | 456.8 | -0.2% | -2.25 to +0.5726 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.47 | 56.52 | +0.1% | -0.2533 to +0.3618 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.565e+05 | 1.564e+05 | -0.1% | -815.3 to +651 | STEADY, under the floor |
| power-capped share of samples | 0.7333 | 0.7345 | +0.2% | -0.02171 to +0.02407 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.57 | 38.88 | +0.8% | -1.316 to +1.945 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.574e+05 | 1.562e+05 | -0.8% | -7914 to +5366 | GAIN, not beyond the noise |
| energy per served request (J) | 25.93 | 25.72 | -0.8% | -1.303 to +0.8837 | GAIN, not beyond the noise |
| power, GPU mean (W) | 247.4 | 245.9 | -0.6% | -10.37 to +7.273 | GAIN, not beyond the noise |
| requests served | 6072 | 6072 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.01 | 90.99 | -0.0% | -0.1253 to +0.09123 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.9 | 269.2 | -0.3% | -2.646 to +1.183 | STEADY, under the floor |
| response time, 99th percentile (ms) | 457.6 | 457 | -0.1% | -4.61 to +3.311 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.47 | 56.51 | +0.1% | -0.07367 to +0.1506 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.565e+05 | 1.564e+05 | -0.1% | -1399 to +1192 | STEADY, under the floor |
| power-capped share of samples | 0.7333 | 0.7352 | +0.3% | -0.01267 to +0.01646 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.88 | 38.79 | -0.2% | -0.2501 to +0.05917 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.562e+05 | 1.566e+05 | +0.2% | -225.4 to +990.4 | STEADY, under the floor |
| energy per served request (J) | 25.72 | 25.78 | +0.2% | -0.03712 to +0.1631 | STEADY, under the floor |
| power, GPU mean (W) | 245.9 | 246.7 | +0.4% | -1.453 to +3.236 | STEADY, under the floor |
| requests served | 6072 | 6072 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.99 | 90.93 | -0.1% | -0.2892 to +0.1718 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.2 | 268.7 | -0.2% | -3.693 to +2.673 | STEADY, under the floor |
| response time, 99th percentile (ms) | 457 | 456.8 | -0.0% | -5.56 to +5.182 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.51 | 56.52 | +0.0% | -0.2676 to +0.2991 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.564e+05 | 1.564e+05 | +0.0% | -592.3 to +635.6 | STEADY, under the floor |
| power-capped share of samples | 0.7352 | 0.7345 | -0.1% | -0.01586 to +0.01443 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.57 -> 38.79 served requests per kJ, difference +0.2186 (95% interval -1.387 to +1.824).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 2 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*