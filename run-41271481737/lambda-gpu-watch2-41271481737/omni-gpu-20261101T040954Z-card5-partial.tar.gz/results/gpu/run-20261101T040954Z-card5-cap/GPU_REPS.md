# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.11 | 42.71 | 42.08 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.183e+04 | 6.097e+04 | 6.189e+04 |
| energy per served request (J) | 23.75 | 23.42 | 23.77 |
| power, GPU mean (W) | 183.8 | 180.7 | 183.7 |
| requests served | 2604 | 2604 | 2604 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 123.5 | 122.4 | 123.7 |
| response time, 95th percentile (ms) | 424.6 | 424.5 | 425.4 |
| response time, 99th percentile (ms) | 697.9 | 697.1 | 699.2 |
| temperature, peak (C) | 59 | 59 | 59 |
| temperature, mean (C) | 49.46 | 49.4 | 49.24 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.19e+04 | 6.191e+04 | 6.156e+04 |
| power-capped share of samples | 0.6694 | 0.6742 | 0.6349 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.11 | 42.08 | -0.1% | -7.042 to +6.973 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.183e+04 | 6.189e+04 | +0.1% | -1.025e+04 to +1.036e+04 | STEADY, under the floor |
| energy per served request (J) | 23.75 | 23.77 | +0.1% | -3.935 to +3.978 | STEADY, under the floor |
| power, GPU mean (W) | 183.8 | 183.7 | -0.1% | -26.1 to +25.89 | STEADY, under the floor |
| requests served | 2604 | 2604 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 123.5 | 123.7 | +0.2% | -6.359 to +6.739 | STEADY, under the floor |
| response time, 95th percentile (ms) | 424.6 | 425.4 | +0.2% | -5.281 to +7.02 | STEADY, under the floor |
| response time, 99th percentile (ms) | 697.9 | 699.2 | +0.2% | -5.861 to +8.461 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.46 | 49.24 | -0.4% | -0.3879 to -0.05709 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.19e+04 | 6.156e+04 | -0.5% | -1454 to +775.5 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6694 | 0.6349 | -5.1% | -0.07175 to +0.002817 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.11 | 42.71 | +1.4% | -5.622 to +6.812 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.183e+04 | 6.097e+04 | -1.4% | -9806 to +8090 | GAIN, not beyond the noise |
| energy per served request (J) | 23.75 | 23.42 | -1.4% | -3.766 to +3.107 | GAIN, not beyond the noise |
| power, GPU mean (W) | 183.8 | 180.7 | -1.7% | -34.96 to +28.76 | GAIN, not beyond the noise |
| requests served | 2604 | 2604 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 123.5 | 122.4 | -0.9% | -4.712 to +2.464 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 424.6 | 424.5 | -0.0% | -11.31 to +11.15 | STEADY, under the floor |
| response time, 99th percentile (ms) | 697.9 | 697.1 | -0.1% | -12.28 to +10.62 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.46 | 49.4 | -0.1% | -1.35 to +1.22 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.19e+04 | 6.191e+04 | +0.0% | -1460 to +1475 | STEADY, under the floor |
| power-capped share of samples | 0.6694 | 0.6742 | +0.7% | -0.1905 to +0.2001 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.71 | 42.08 | -1.5% | -1.42 to +0.1611 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.097e+04 | 6.189e+04 | +1.5% | -439.5 to +2268 | power given, not beyond the noise |
| energy per served request (J) | 23.42 | 23.77 | +1.5% | -0.1688 to +0.8709 | power given, not beyond the noise |
| power, GPU mean (W) | 180.7 | 183.7 | +1.7% | -2.868 to +8.853 | power given, not beyond the noise |
| requests served | 2604 | 2604 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 122.4 | 123.7 | +1.1% | -8.823 to +11.45 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 424.5 | 425.4 | +0.2% | -16.43 to +18.33 | STEADY, under the floor |
| response time, 99th percentile (ms) | 697.1 | 699.2 | +0.3% | -2.161 to +6.419 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.4 | 49.24 | -0.3% | -1.277 to +0.9623 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.191e+04 | 6.156e+04 | -0.6% | -2929 to +2236 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6742 | 0.6349 | -5.8% | -0.2719 to +0.1934 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.11 -> 42.08 served requests per kJ, difference -0.03464 (95% interval -7.042 to +6.973).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 22.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*