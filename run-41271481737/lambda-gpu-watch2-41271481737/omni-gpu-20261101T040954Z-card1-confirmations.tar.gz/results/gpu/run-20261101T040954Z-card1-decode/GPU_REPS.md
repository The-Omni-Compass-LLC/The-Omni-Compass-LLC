# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 46.66 | 46.61 | 46.92 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.248e+05 | 1.25e+05 | 1.241e+05 |
| energy per served request (J) | 21.43 | 21.45 | 21.31 |
| power, GPU mean (W) | 196 | 196.6 | 195.5 |
| requests served | 5824 | 5824 | 5824 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.68 | 96.76 | 96.66 |
| response time, 95th percentile (ms) | 275.3 | 275.5 | 275.4 |
| response time, 99th percentile (ms) | 451.9 | 453.1 | 451.8 |
| temperature, peak (C) | 60 | 60 | 60 |
| temperature, mean (C) | 49.37 | 49.49 | 49.44 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.248e+05 | 1.25e+05 | 1.247e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.66 | 46.92 | +0.6% | -0.4386 to +0.9598 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.248e+05 | 1.241e+05 | -0.6% | -2543 to +1161 | GAIN, not beyond the noise |
| energy per served request (J) | 21.43 | 21.31 | -0.6% | -0.4366 to +0.1994 | GAIN, not beyond the noise |
| power, GPU mean (W) | 196 | 195.5 | -0.3% | -3.522 to +2.34 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.68 | 96.66 | -0.0% | -0.7999 to +0.7628 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.3 | 275.4 | +0.0% | -2.766 to +2.89 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.9 | 451.8 | -0.0% | -5.129 to +4.993 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.37 | 49.44 | +0.1% | -0.014 to +0.1516 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.248e+05 | 1.247e+05 | -0.1% | -742.5 to +436.6 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.66 | 46.61 | -0.1% | -0.3902 to +0.2897 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.248e+05 | 1.25e+05 | +0.1% | -776.6 to +1046 | STEADY, under the floor |
| energy per served request (J) | 21.43 | 21.45 | +0.1% | -0.1333 to +0.1797 | STEADY, under the floor |
| power, GPU mean (W) | 196 | 196.6 | +0.3% | -0.2836 to +1.403 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.68 | 96.76 | +0.1% | -0.3458 to +0.5238 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.3 | 275.5 | +0.1% | -1.387 to +1.692 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.9 | 453.1 | +0.3% | -4.566 to +6.86 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.37 | 49.49 | +0.2% | -0.1501 to +0.3869 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.248e+05 | 1.25e+05 | +0.1% | -878.5 to +1134 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.61 | 46.92 | +0.7% | -0.1184 to +0.7402 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.25e+05 | 1.241e+05 | -0.7% | -1953 to +301.2 | GAIN, not beyond the noise |
| energy per served request (J) | 21.45 | 21.31 | -0.7% | -0.3353 to +0.05171 | GAIN, not beyond the noise |
| power, GPU mean (W) | 196.6 | 195.5 | -0.6% | -3.261 to +0.9599 | GAIN, not beyond the noise |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.76 | 96.66 | -0.1% | -0.885 to +0.6698 | STEADY, under the floor |
| response time, 95th percentile (ms) | 275.5 | 275.4 | -0.0% | -2.75 to +2.568 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.1 | 451.8 | -0.3% | -9.266 to +6.836 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.49 | 49.44 | -0.1% | -0.2488 to +0.1497 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.25e+05 | 1.247e+05 | -0.2% | -1161 to +599.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 46.66 -> 46.92 served requests per kJ, difference +0.2606 (95% interval -0.4386 to +0.9598).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 38 | 0 | 0 | 0 | 0.201 | 0.254 | 0 | 1.3e+03 | 37 | True |
| omni | 2 | 22 | 0 | 0 | 0 | 0.204 | 0.243 | 0 | 760 | 21 | True |
| omni | 3 | 28 | 0 | 0 | 0 | 0.218 | 0.297 | 0 | 984 | 27 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 1 | 283 | 0 | n/a | n/a | 0 | 283 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 63 | +6.876 | +0 |
| compass | 44 | 1017 | +632.2 | -71 |
| fail_up | 1 | 7 | -109.6 | +1 |
| race | 40 | 143 | -1190 | -6 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 88.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*