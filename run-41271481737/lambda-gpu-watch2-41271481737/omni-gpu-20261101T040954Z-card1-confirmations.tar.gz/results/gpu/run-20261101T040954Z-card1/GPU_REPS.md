# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.01 | 40.13 | 40.2 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.569e+05 | 1.564e+05 | 1.561e+05 |
| energy per served request (J) | 25 | 24.92 | 24.88 |
| power, GPU mean (W) | 245.8 | 245.8 | 244.6 |
| requests served | 6276 | 6276 | 6276 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 85.73 | 85.66 | 85.71 |
| response time, 95th percentile (ms) | 236.4 | 235.9 | 236.4 |
| response time, 99th percentile (ms) | 426.4 | 424.9 | 425.9 |
| temperature, peak (C) | 67 | 67 | 67 |
| temperature, mean (C) | 55.71 | 55.78 | 55.7 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.567e+05 | 1.568e+05 | 1.568e+05 |
| power-capped share of samples | 0.7242 | 0.7327 | 0.7291 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.01 | 40.2 | +0.5% | -0.506 to +0.8912 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.569e+05 | 1.561e+05 | -0.5% | -3489 to +1982 | STEADY, under the floor |
| energy per served request (J) | 25 | 24.88 | -0.5% | -0.556 to +0.3159 | STEADY, under the floor |
| power, GPU mean (W) | 245.8 | 244.6 | -0.5% | -5.794 to +3.374 | STEADY, under the floor |
| requests served | 6276 | 6276 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.73 | 85.71 | -0.0% | -0.2703 to +0.2322 | STEADY, under the floor |
| response time, 95th percentile (ms) | 236.4 | 236.4 | -0.0% | -2.088 to +2.042 | STEADY, under the floor |
| response time, 99th percentile (ms) | 426.4 | 425.9 | -0.1% | -3.927 to +2.948 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.71 | 55.7 | -0.0% | -0.1619 to +0.1443 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.567e+05 | 1.568e+05 | +0.1% | -317.7 to +585.9 | STEADY, under the floor |
| power-capped share of samples | 0.7242 | 0.7291 | +0.7% | +4.969e-05 to +0.00986 | power given, clear of the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.01 | 40.13 | +0.3% | -0.8989 to +1.144 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.569e+05 | 1.564e+05 | -0.3% | -4470 to +3515 | STEADY, under the floor |
| energy per served request (J) | 25 | 24.92 | -0.3% | -0.7123 to +0.56 | STEADY, under the floor |
| power, GPU mean (W) | 245.8 | 245.8 | -0.0% | -7.141 to +7.043 | STEADY, under the floor |
| requests served | 6276 | 6276 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.73 | 85.66 | -0.1% | -0.3851 to +0.2556 | STEADY, under the floor |
| response time, 95th percentile (ms) | 236.4 | 235.9 | -0.2% | -4.514 to +3.487 | STEADY, under the floor |
| response time, 99th percentile (ms) | 426.4 | 424.9 | -0.3% | -4.742 to +1.79 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.71 | 55.78 | +0.1% | -0.2155 to +0.3606 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.567e+05 | 1.568e+05 | +0.0% | -177.1 to +290.1 | STEADY, under the floor |
| power-capped share of samples | 0.7242 | 0.7327 | +1.2% | -0.007383 to +0.02435 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.13 | 40.2 | +0.2% | -0.5623 to +0.7026 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.564e+05 | 1.561e+05 | -0.2% | -2739 to +2188 | STEADY, under the floor |
| energy per served request (J) | 24.92 | 24.88 | -0.2% | -0.4364 to +0.3487 | STEADY, under the floor |
| power, GPU mean (W) | 245.8 | 244.6 | -0.5% | -5.45 to +3.128 | STEADY, under the floor |
| requests served | 6276 | 6276 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.66 | 85.71 | +0.1% | -0.2796 to +0.371 | STEADY, under the floor |
| response time, 95th percentile (ms) | 235.9 | 236.4 | +0.2% | -1.447 to +2.428 | STEADY, under the floor |
| response time, 99th percentile (ms) | 424.9 | 425.9 | +0.2% | -2.556 to +4.529 | STEADY, under the floor |
| temperature, peak (C) | 67 | 67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.78 | 55.7 | -0.1% | -0.4297 to +0.267 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.568e+05 | 1.568e+05 | +0.0% | -182.3 to +337.4 | STEADY, under the floor |
| power-capped share of samples | 0.7327 | 0.7291 | -0.5% | -0.02021 to +0.01315 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.01 -> 40.2 served requests per kJ, difference +0.1926 (95% interval -0.506 to +0.8912).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 3 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*