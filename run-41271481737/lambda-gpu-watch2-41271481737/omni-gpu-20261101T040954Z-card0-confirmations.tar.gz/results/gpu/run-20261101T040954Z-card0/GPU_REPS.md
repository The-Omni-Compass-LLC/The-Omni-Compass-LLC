# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.57 | 39.6 | 39.64 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.565e+05 | 1.564e+05 | 1.562e+05 |
| energy per served request (J) | 25.27 | 25.26 | 25.23 |
| power, GPU mean (W) | 245.4 | 245 | 245.3 |
| requests served | 6192 | 6192 | 6192 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 87.87 | 87.9 | 87.92 |
| response time, 95th percentile (ms) | 247.8 | 247.2 | 247.7 |
| response time, 99th percentile (ms) | 440.5 | 440.4 | 440.5 |
| temperature, peak (C) | 77.67 | 77.33 | 77.33 |
| temperature, mean (C) | 64.14 | 64.11 | 64.17 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.571e+05 | 1.571e+05 | 1.57e+05 |
| power-capped share of samples | 0.7307 | 0.7247 | 0.7288 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.57 | 39.64 | +0.2% | -0.2925 to +0.4288 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.565e+05 | 1.562e+05 | -0.2% | -1700 to +1159 | STEADY, under the floor |
| energy per served request (J) | 25.27 | 25.23 | -0.2% | -0.2745 to +0.1872 | STEADY, under the floor |
| power, GPU mean (W) | 245.4 | 245.3 | -0.0% | -2.374 to +2.198 | STEADY, under the floor |
| requests served | 6192 | 6192 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.87 | 87.92 | +0.1% | -0.1223 to +0.2232 | STEADY, under the floor |
| response time, 95th percentile (ms) | 247.8 | 247.7 | -0.0% | -0.5123 to +0.4632 | STEADY, under the floor |
| response time, 99th percentile (ms) | 440.5 | 440.5 | -0.0% | -2.344 to +2.303 | STEADY, under the floor |
| temperature, peak (C) | 77.67 | 77.33 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 64.14 | 64.17 | +0.0% | -0.2379 to +0.3 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.571e+05 | 1.57e+05 | -0.1% | -516.9 to +357.8 | STEADY, under the floor |
| power-capped share of samples | 0.7307 | 0.7288 | -0.3% | -0.02469 to +0.02077 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.57 | 39.6 | +0.1% | -1.239 to +1.296 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.565e+05 | 1.564e+05 | -0.1% | -5124 to +4915 | STEADY, under the floor |
| energy per served request (J) | 25.27 | 25.26 | -0.1% | -0.8275 to +0.7938 | STEADY, under the floor |
| power, GPU mean (W) | 245.4 | 245 | -0.2% | -8.408 to +7.603 | STEADY, under the floor |
| requests served | 6192 | 6192 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.87 | 87.9 | +0.0% | -0.2185 to +0.2854 | STEADY, under the floor |
| response time, 95th percentile (ms) | 247.8 | 247.2 | -0.2% | -1.192 to +0.1131 | STEADY, under the floor |
| response time, 99th percentile (ms) | 440.5 | 440.4 | -0.0% | -2.284 to +1.95 | STEADY, under the floor |
| temperature, peak (C) | 77.67 | 77.33 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 64.14 | 64.11 | -0.0% | -0.3868 to +0.3238 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.571e+05 | 1.571e+05 | -0.0% | -587 to +584.2 | STEADY, under the floor |
| power-capped share of samples | 0.7307 | 0.7247 | -0.8% | -0.02181 to +0.009724 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.6 | 39.64 | +0.1% | -1.132 to +1.211 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.564e+05 | 1.562e+05 | -0.1% | -4801 to +4468 | STEADY, under the floor |
| energy per served request (J) | 25.26 | 25.23 | -0.1% | -0.7753 to +0.7217 | STEADY, under the floor |
| power, GPU mean (W) | 245 | 245.3 | +0.1% | -6.705 to +7.334 | STEADY, under the floor |
| requests served | 6192 | 6192 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.9 | 87.92 | +0.0% | -0.1868 to +0.2208 | STEADY, under the floor |
| response time, 95th percentile (ms) | 247.2 | 247.7 | +0.2% | -0.4002 to +1.43 | STEADY, under the floor |
| response time, 99th percentile (ms) | 440.4 | 440.5 | +0.0% | -1.987 to +2.281 | STEADY, under the floor |
| temperature, peak (C) | 77.33 | 77.33 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 64.11 | 64.17 | +0.1% | -0.1484 to +0.2734 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.571e+05 | 1.57e+05 | -0.0% | -445.3 to +289 | STEADY, under the floor |
| power-capped share of samples | 0.7247 | 0.7288 | +0.6% | -0.007465 to +0.01563 | power given, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.57 -> 39.64 served requests per kJ, difference +0.06812 (95% interval -0.2925 to +0.4288).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 2 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*