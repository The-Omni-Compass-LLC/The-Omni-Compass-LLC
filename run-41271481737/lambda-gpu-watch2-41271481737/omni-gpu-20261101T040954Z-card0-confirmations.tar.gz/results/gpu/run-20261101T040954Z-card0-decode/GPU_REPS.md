# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.52 | 45.88 | 45.89 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.278e+05 | 1.268e+05 | 1.268e+05 |
| energy per served request (J) | 21.97 | 21.8 | 21.79 |
| power, GPU mean (W) | 200.1 | 198.7 | 198.4 |
| requests served | 5818 | 5818 | 5818 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.43 | 96.3 | 96.51 |
| response time, 95th percentile (ms) | 274.9 | 274.3 | 275 |
| response time, 99th percentile (ms) | 449.6 | 448.1 | 450.8 |
| temperature, peak (C) | 71 | 71 | 71 |
| temperature, mean (C) | 56.76 | 56.7 | 56.67 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.269e+05 | 1.267e+05 | 1.269e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.52 | 45.89 | +0.8% | -0.468 to +1.19 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.278e+05 | 1.268e+05 | -0.8% | -3357 to +1335 | GAIN, not beyond the noise |
| energy per served request (J) | 21.97 | 21.79 | -0.8% | -0.577 to +0.2294 | GAIN, not beyond the noise |
| power, GPU mean (W) | 200.1 | 198.4 | -0.8% | -5.519 to +2.126 | GAIN, not beyond the noise |
| requests served | 5818 | 5818 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.43 | 96.51 | +0.1% | -0.5767 to +0.738 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.9 | 275 | +0.0% | -3.185 to +3.269 | STEADY, under the floor |
| response time, 99th percentile (ms) | 449.6 | 450.8 | +0.3% | -5.131 to +7.655 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.76 | 56.67 | -0.2% | -0.4236 to +0.2288 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.269e+05 | 1.269e+05 | +0.0% | -101.2 to +107.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.52 | 45.88 | +0.8% | -2.04 to +2.76 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.278e+05 | 1.268e+05 | -0.8% | -7698 to +5697 | GAIN, not beyond the noise |
| energy per served request (J) | 21.97 | 21.8 | -0.8% | -1.323 to +0.9792 | GAIN, not beyond the noise |
| power, GPU mean (W) | 200.1 | 198.7 | -0.7% | -11.82 to +8.964 | GAIN, not beyond the noise |
| requests served | 5818 | 5818 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.43 | 96.3 | -0.1% | -0.4782 to +0.2069 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.9 | 274.3 | -0.2% | -2.891 to +1.59 | STEADY, under the floor |
| response time, 99th percentile (ms) | 449.6 | 448.1 | -0.3% | -4.624 to +1.676 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.76 | 56.7 | -0.1% | -0.509 to +0.3734 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.269e+05 | 1.267e+05 | -0.1% | -747.5 to +479.8 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.88 | 45.89 | +0.0% | -1.982 to +1.985 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.268e+05 | 1.268e+05 | -0.0% | -5511 to +5490 | STEADY, under the floor |
| energy per served request (J) | 21.8 | 21.79 | -0.0% | -0.9472 to +0.9435 | STEADY, under the floor |
| power, GPU mean (W) | 198.7 | 198.4 | -0.1% | -8.806 to +8.264 | STEADY, under the floor |
| requests served | 5818 | 5818 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.3 | 96.51 | +0.2% | -0.1198 to +0.5524 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.3 | 275 | +0.3% | -0.5049 to +1.889 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.1 | 450.8 | +0.6% | -0.8055 to +6.278 | LOSS, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.7 | 56.67 | -0.1% | -0.1476 to +0.08837 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.267e+05 | 1.269e+05 | +0.1% | -453.7 to +728.1 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.52 -> 45.89 served requests per kJ, difference +0.3611 (95% interval -0.468 to +1.19).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 30 | 0 | 0 | 0 | 0.199 | 0.274 | 0 | 616 | 29 | True |
| omni | 2 | 26 | 0 | 0 | 0 | 0.204 | 0.247 | 0 | 588 | 25 | True |
| omni | 3 | 42 | 0 | 0 | 0 | 0.203 | 0.286 | 0 | 864 | 41 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| omni | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| omni | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | +56 | +0 |
| compass | 49 | 989 | -1549 | +8 |
| race | 46 | 148 | -307.9 | +16 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 98.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*