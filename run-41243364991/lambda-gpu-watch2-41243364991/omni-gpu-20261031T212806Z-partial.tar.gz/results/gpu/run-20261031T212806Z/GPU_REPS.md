# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.1 | 60.21 | 60.08 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.727e+04 | 6.715e+04 | 6.73e+04 |
| energy per served request (J) | 16.64 | 16.61 | 16.64 |
| power, GPU mean (W) | 106.5 | 106.3 | 106.5 |
| requests served | 4043 | 4043 | 4043 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 140.5 | 140.7 | 140.5 |
| response time, 95th percentile (ms) | 418.8 | 419.6 | 419.3 |
| response time, 99th percentile (ms) | 855.6 | 855.9 | 855.5 |
| temperature, peak (C) | 69 | 68.9 | 69 |
| temperature, mean (C) | 57.67 | 57.65 | 57.67 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.701e+04 | 6.704e+04 | 6.704e+04 |
| power-capped share of samples | 0.8804 | 0.8792 | 0.8802 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.1 | 60.08 | -0.0% | -0.1732 to +0.1258 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.727e+04 | 6.73e+04 | +0.0% | -138.9 to +193.5 | STEADY, under the floor |
| energy per served request (J) | 16.64 | 16.64 | +0.0% | -0.03436 to +0.04785 | STEADY, under the floor |
| power, GPU mean (W) | 106.5 | 106.5 | +0.0% | -0.2348 to +0.3092 | STEADY, under the floor |
| requests served | 4043 | 4043 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 140.5 | 140.5 | +0.0% | -0.3946 to +0.4459 | STEADY, under the floor |
| response time, 95th percentile (ms) | 418.8 | 419.3 | +0.1% | -1.866 to +2.845 | STEADY, under the floor |
| response time, 99th percentile (ms) | 855.6 | 855.5 | -0.0% | -3.446 to +3.185 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.67 | 57.67 | -0.0% | -0.08737 to +0.08325 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.701e+04 | 6.704e+04 | +0.0% | +11.04 to +47.01 | STEADY, under the floor |
| power-capped share of samples | 0.8804 | 0.8802 | -0.0% | -0.001647 to +0.00117 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.1 | 60.21 | +0.2% | -0.002416 to +0.2128 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.727e+04 | 6.715e+04 | -0.2% | -236.9 to +3.257 | STEADY, under the floor |
| energy per served request (J) | 16.64 | 16.61 | -0.2% | -0.05859 to +0.0008057 | STEADY, under the floor |
| power, GPU mean (W) | 106.5 | 106.3 | -0.2% | -0.3761 to +0.005551 | STEADY, under the floor |
| requests served | 4043 | 4043 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 140.5 | 140.7 | +0.1% | -0.2471 to +0.5943 | STEADY, under the floor |
| response time, 95th percentile (ms) | 418.8 | 419.6 | +0.2% | -2.085 to +3.654 | STEADY, under the floor |
| response time, 99th percentile (ms) | 855.6 | 855.9 | +0.0% | -2.293 to +2.963 | STEADY, under the floor |
| temperature, peak (C) | 69 | 68.9 | -0.1% | -0.3262 to +0.1262 | STEADY, under the floor |
| temperature, mean (C) | 57.67 | 57.65 | -0.0% | -0.104 to +0.06034 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.701e+04 | 6.704e+04 | +0.0% | -5.829 to +65.23 | STEADY, under the floor |
| power-capped share of samples | 0.8804 | 0.8792 | -0.1% | -0.002958 to +0.0004961 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.21 | 60.08 | -0.2% | -0.2861 to +0.02831 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.715e+04 | 6.73e+04 | +0.2% | -31.12 to +319.3 | STEADY, under the floor |
| energy per served request (J) | 16.61 | 16.64 | +0.2% | -0.007698 to +0.07897 | STEADY, under the floor |
| power, GPU mean (W) | 106.3 | 106.5 | +0.2% | -0.05946 to +0.5044 | STEADY, under the floor |
| requests served | 4043 | 4043 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 140.7 | 140.5 | -0.1% | -0.493 to +0.1971 | STEADY, under the floor |
| response time, 95th percentile (ms) | 419.6 | 419.3 | -0.1% | -2.955 to +2.365 | STEADY, under the floor |
| response time, 99th percentile (ms) | 855.9 | 855.5 | -0.1% | -3.759 to +2.829 | STEADY, under the floor |
| temperature, peak (C) | 68.9 | 69 | +0.1% | -0.1262 to +0.3262 | STEADY, under the floor |
| temperature, mean (C) | 57.65 | 57.67 | +0.0% | -0.08158 to +0.1212 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.704e+04 | 6.704e+04 | -0.0% | -27.68 to +26.33 | STEADY, under the floor |
| power-capped share of samples | 0.8792 | 0.8802 | +0.1% | -0.0005907 to +0.002575 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.1 -> 60.08 served requests per kJ, difference -0.0237 (95% interval -0.1732 to +0.1258).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 5 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 10 | 305 | 0 | n/a | n/a | 0 | 305 | 0 |
| watch | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 5 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 10 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*