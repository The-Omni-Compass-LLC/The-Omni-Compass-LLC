# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 58.18 | 58.2 | 57.5 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.124e+04 | 2.124e+04 | 2.15e+04 |
| energy per served request (J) | 17.19 | 17.18 | 17.39 |
| power, GPU mean (W) | 100.3 | 100.3 | 101.5 |
| requests served | 1236 | 1236 | 1236 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 135.4 | 136.6 | 136.8 |
| response time, 95th percentile (ms) | 408.2 | 423.7 | 424.2 |
| response time, 99th percentile (ms) | 675.7 | 682.2 | 687.5 |
| temperature, peak (C) | 63.67 | 64 | 64 |
| temperature, mean (C) | 56.14 | 57.07 | 57.12 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.128e+04 | 2.131e+04 | 2.13e+04 |
| power-capped share of samples | 0.8033 | 0.803 | 0.8014 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.18 | 57.5 | -1.2% | -0.9778 to -0.3799 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.124e+04 | 2.15e+04 | +1.2% | +144.7 to +356.5 | power given, clear of the noise |
| energy per served request (J) | 17.19 | 17.39 | +1.2% | +0.1171 to +0.2884 | power given, clear of the noise |
| power, GPU mean (W) | 100.3 | 101.5 | +1.2% | +0.6853 to +1.69 | power given, clear of the noise |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 135.4 | 136.8 | +1.0% | -5.883 to +8.625 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 408.2 | 424.2 | +3.9% | -48.48 to +80.62 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 675.7 | 687.5 | +1.8% | -26.31 to +49.97 | LOSS, not beyond the noise |
| temperature, peak (C) | 63.67 | 64 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 56.14 | 57.12 | +1.7% | -3.37 to +5.332 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.128e+04 | 2.13e+04 | +0.1% | -370.4 to +404.1 | STEADY, under the floor |
| power-capped share of samples | 0.8033 | 0.8014 | -0.2% | -0.01114 to +0.007223 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.18 | 58.2 | +0.0% | -0.606 to +0.6371 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.124e+04 | 2.124e+04 | -0.0% | -232.3 to +220.7 | STEADY, under the floor |
| energy per served request (J) | 17.19 | 17.18 | -0.0% | -0.1879 to +0.1785 | STEADY, under the floor |
| power, GPU mean (W) | 100.3 | 100.3 | -0.0% | -1.131 to +1.082 | STEADY, under the floor |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 135.4 | 136.6 | +0.9% | -4.624 to +7.026 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 408.2 | 423.7 | +3.8% | -20.58 to +51.62 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 675.7 | 682.2 | +1.0% | -20.74 to +33.67 | LOSS, not beyond the noise |
| temperature, peak (C) | 63.67 | 64 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 56.14 | 57.07 | +1.7% | -3.004 to +4.875 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.128e+04 | 2.131e+04 | +0.1% | -229.4 to +285.7 | STEADY, under the floor |
| power-capped share of samples | 0.8033 | 0.803 | -0.0% | -0.01928 to +0.01853 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.2 | 57.5 | -1.2% | -1.137 to -0.252 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.124e+04 | 2.15e+04 | +1.2% | +93.93 to +418.9 | power given, clear of the noise |
| energy per served request (J) | 17.18 | 17.39 | +1.2% | +0.076 to +0.3389 | power given, clear of the noise |
| power, GPU mean (W) | 100.3 | 101.5 | +1.2% | +0.4105 to +2.013 | power given, clear of the noise |
| requests served | 1236 | 1236 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 136.6 | 136.8 | +0.1% | -1.634 to +1.973 | STEADY, under the floor |
| response time, 95th percentile (ms) | 423.7 | 424.2 | +0.1% | -34.86 to +35.95 | STEADY, under the floor |
| response time, 99th percentile (ms) | 682.2 | 687.5 | +0.8% | -8.19 to +18.92 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.07 | 57.12 | +0.1% | -0.3691 to +0.4606 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.131e+04 | 2.13e+04 | -0.1% | -158.5 to +135.8 | STEADY, under the floor |
| power-capped share of samples | 0.803 | 0.8014 | -0.2% | -0.02844 to +0.02528 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 58.18 -> 57.5 served requests per kJ, difference -0.6789 (95% interval -0.9778 to -0.3799).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): power given, clear of the noise.
**Result, by rule: LOSS.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*