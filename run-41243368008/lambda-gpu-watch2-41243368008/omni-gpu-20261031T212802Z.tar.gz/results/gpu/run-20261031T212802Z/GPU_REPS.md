# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 61.35 | 61.47 | 61.44 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.758e+04 | 6.745e+04 | 6.748e+04 |
| energy per served request (J) | 16.3 | 16.27 | 16.28 |
| power, GPU mean (W) | 107 | 106.8 | 106.8 |
| requests served | 4146 | 4146 | 4146 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 135.8 | 136.1 | 136 |
| response time, 95th percentile (ms) | 428.6 | 429.7 | 432 |
| response time, 99th percentile (ms) | 837.6 | 839 | 845.8 |
| temperature, peak (C) | 72 | 72.1 | 72.1 |
| temperature, mean (C) | 60.05 | 60.03 | 60.03 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.668e+04 | 6.669e+04 | 6.668e+04 |
| power-capped share of samples | 0.8828 | 0.8825 | 0.8821 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.35 | 61.44 | +0.2% | -0.1006 to +0.2909 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.758e+04 | 6.748e+04 | -0.2% | -319.2 to +110.6 | STEADY, under the floor |
| energy per served request (J) | 16.3 | 16.28 | -0.2% | -0.077 to +0.02668 | STEADY, under the floor |
| power, GPU mean (W) | 107 | 106.8 | -0.2% | -0.5036 to +0.1772 | STEADY, under the floor |
| requests served | 4146 | 4146 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 135.8 | 136 | +0.2% | -0.5046 to +1.05 | STEADY, under the floor |
| response time, 95th percentile (ms) | 428.6 | 432 | +0.8% | -1.7 to +8.522 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 837.6 | 845.8 | +1.0% | -5.672 to +21.94 | LOSS, not beyond the noise |
| temperature, peak (C) | 72 | 72.1 | +0.1% | -0.1262 to +0.3262 | STEADY, under the floor |
| temperature, mean (C) | 60.05 | 60.03 | -0.0% | -0.05705 to +0.01889 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.668e+04 | 6.668e+04 | +0.0% | -20.52 to +21.47 | STEADY, under the floor |
| power-capped share of samples | 0.8828 | 0.8821 | -0.1% | -0.002566 to +0.001225 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.35 | 61.47 | +0.2% | -0.06166 to +0.3079 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.758e+04 | 6.745e+04 | -0.2% | -338.1 to +67.78 | STEADY, under the floor |
| energy per served request (J) | 16.3 | 16.27 | -0.2% | -0.08155 to +0.01635 | STEADY, under the floor |
| power, GPU mean (W) | 107 | 106.8 | -0.2% | -0.534 to +0.1065 | STEADY, under the floor |
| requests served | 4146 | 4146 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 135.8 | 136.1 | +0.2% | -0.8636 to +1.446 | STEADY, under the floor |
| response time, 95th percentile (ms) | 428.6 | 429.7 | +0.3% | -5.497 to +7.706 | STEADY, under the floor |
| response time, 99th percentile (ms) | 837.6 | 839 | +0.2% | -19.75 to +22.54 | STEADY, under the floor |
| temperature, peak (C) | 72 | 72.1 | +0.1% | -0.1262 to +0.3262 | STEADY, under the floor |
| temperature, mean (C) | 60.05 | 60.03 | -0.0% | -0.05556 to +0.02521 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.668e+04 | 6.669e+04 | +0.0% | -33.15 to +38.45 | STEADY, under the floor |
| power-capped share of samples | 0.8828 | 0.8825 | -0.0% | -0.001821 to +0.001362 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 61.47 | 61.44 | -0.0% | -0.2139 to +0.1579 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.745e+04 | 6.748e+04 | +0.0% | -173.3 to +235 | STEADY, under the floor |
| energy per served request (J) | 16.27 | 16.28 | +0.0% | -0.04181 to +0.05669 | STEADY, under the floor |
| power, GPU mean (W) | 106.8 | 106.8 | +0.0% | -0.2726 to +0.3737 | STEADY, under the floor |
| requests served | 4146 | 4146 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 136.1 | 136 | -0.0% | -0.7289 to +0.6921 | STEADY, under the floor |
| response time, 95th percentile (ms) | 429.7 | 432 | +0.5% | -3.292 to +7.906 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 839 | 845.8 | +0.8% | -6.537 to +20.01 | LOSS, not beyond the noise |
| temperature, peak (C) | 72.1 | 72.1 | +0.0% | -0.3372 to +0.3372 | STEADY, under the floor |
| temperature, mean (C) | 60.03 | 60.03 | -0.0% | -0.03254 to +0.02474 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.669e+04 | 6.668e+04 | -0.0% | -30.48 to +26.13 | STEADY, under the floor |
| power-capped share of samples | 0.8825 | 0.8821 | -0.0% | -0.002508 to +0.001627 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 61.35 -> 61.44 served requests per kJ, difference +0.09516 (95% interval -0.1006 to +0.2909).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 5 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 10 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 5 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 10 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*