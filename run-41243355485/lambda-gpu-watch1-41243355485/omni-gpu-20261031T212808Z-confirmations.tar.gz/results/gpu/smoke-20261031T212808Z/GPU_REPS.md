# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 58.39 | 57.8 | 57.25 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.155e+04 | 2.177e+04 | 2.198e+04 |
| energy per served request (J) | 17.13 | 17.3 | 17.47 |
| power, GPU mean (W) | 101.8 | 102.8 | 103.8 |
| requests served | 1258 | 1258 | 1258 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 144.5 | 145.8 | 146.3 |
| response time, 95th percentile (ms) | 463 | 467 | 470.7 |
| response time, 99th percentile (ms) | 723.9 | 732.3 | 735.5 |
| temperature, peak (C) | 61.67 | 62 | 62 |
| temperature, mean (C) | 54.27 | 54.99 | 55 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.16e+04 | 2.165e+04 | 2.165e+04 |
| power-capped share of samples | 0.7989 | 0.8002 | 0.7998 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.39 | 57.25 | -2.0% | -2.491 to +0.2002 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.155e+04 | 2.198e+04 | +2.0% | -66.96 to +927 | power given, not beyond the noise |
| energy per served request (J) | 17.13 | 17.47 | +2.0% | -0.05323 to +0.7368 | power given, not beyond the noise |
| power, GPU mean (W) | 101.8 | 103.8 | +2.0% | -0.312 to +4.394 | power given, not beyond the noise |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 144.5 | 146.3 | +1.2% | -8.344 to +11.91 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 463 | 470.7 | +1.7% | -41.19 to +56.62 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 723.9 | 735.5 | +1.6% | -53.59 to +76.66 | LOSS, not beyond the noise |
| temperature, peak (C) | 61.67 | 62 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 54.27 | 55 | +1.4% | -2.822 to +4.288 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.16e+04 | 2.165e+04 | +0.2% | -235.8 to +331.3 | STEADY, under the floor |
| power-capped share of samples | 0.7989 | 0.7998 | +0.1% | -0.001484 to +0.003252 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 58.39 | 57.8 | -1.0% | -2.8 to +1.619 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.155e+04 | 2.177e+04 | +1.0% | -603.2 to +1044 | power given, not beyond the noise |
| energy per served request (J) | 17.13 | 17.3 | +1.0% | -0.4795 to +0.83 | power given, not beyond the noise |
| power, GPU mean (W) | 101.8 | 102.8 | +1.0% | -2.854 to +4.944 | power given, not beyond the noise |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 144.5 | 145.8 | +0.9% | -5.738 to +8.383 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 463 | 467 | +0.9% | -33.1 to +41.11 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 723.9 | 732.3 | +1.2% | -49.26 to +66.05 | LOSS, not beyond the noise |
| temperature, peak (C) | 61.67 | 62 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 54.27 | 54.99 | +1.3% | -2.23 to +3.672 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.16e+04 | 2.165e+04 | +0.2% | -204.7 to +300.5 | STEADY, under the floor |
| power-capped share of samples | 0.7989 | 0.8002 | +0.2% | -0.008245 to +0.01077 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.8 | 57.25 | -1.0% | -1.947 to +0.838 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.177e+04 | 2.198e+04 | +1.0% | -315.4 to +734.5 | power given, not beyond the noise |
| energy per served request (J) | 17.3 | 17.47 | +1.0% | -0.2508 to +0.5839 | power given, not beyond the noise |
| power, GPU mean (W) | 102.8 | 103.8 | +1.0% | -1.468 to +3.46 | power given, not beyond the noise |
| requests served | 1258 | 1258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 145.8 | 146.3 | +0.3% | -3.263 to +4.185 | STEADY, under the floor |
| response time, 95th percentile (ms) | 467 | 470.7 | +0.8% | -10.97 to +18.39 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 732.3 | 735.5 | +0.4% | -9.661 to +15.94 | STEADY, under the floor |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.99 | 55 | +0.0% | -0.6067 to +0.6313 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.165e+04 | 2.165e+04 | -0.0% | -47.82 to +47.46 | STEADY, under the floor |
| power-capped share of samples | 0.8002 | 0.7998 | -0.0% | -0.01076 to +0.01001 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 58.39 -> 57.25 served requests per kJ, difference -1.145 (95% interval -2.491 to +0.2002).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*