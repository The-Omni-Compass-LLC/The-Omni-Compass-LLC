# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 37.97 | 37.87 | 38.2 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.695e+04 | 2.702e+04 | 2.678e+04 |
| energy per served request (J) | 26.34 | 26.41 | 26.18 |
| power, GPU mean (W) | 81.23 | 81.44 | 80.74 |
| requests served | 1023 | 1023 | 1023 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 245.8 | 244.1 | 244.5 |
| response time, 95th percentile (ms) | 862.3 | 845.3 | 833.7 |
| response time, 99th percentile (ms) | 1189 | 1179 | 1163 |
| temperature, peak (C) | 52.6 | 52.6 | 52.2 |
| temperature, mean (C) | 47.24 | 47.14 | 46.99 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.608e+04 | 2.607e+04 | 2.589e+04 |
| power-capped share of samples | 0.7339 | 0.7356 | 0.7157 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.97 | 38.2 | +0.6% | +0.1219 to +0.3377 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.695e+04 | 2.678e+04 | -0.6% | -238.3 to -86.05 | GAIN, clear of the noise |
| energy per served request (J) | 26.34 | 26.18 | -0.6% | -0.2329 to -0.08412 | GAIN, clear of the noise |
| power, GPU mean (W) | 81.23 | 80.74 | -0.6% | -0.7193 to -0.2609 | GAIN, clear of the noise |
| requests served | 1023 | 1023 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 245.8 | 244.5 | -0.5% | -6.985 to +4.505 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 862.3 | 833.7 | -3.3% | -71.63 to +14.48 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1189 | 1163 | -2.2% | -64.05 to +12.81 | GAIN, not beyond the noise |
| temperature, peak (C) | 52.6 | 52.2 | -0.8% | -1.815 to +1.015 | GAIN, not beyond the noise |
| temperature, mean (C) | 47.24 | 46.99 | -0.5% | -0.5516 to +0.05128 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.608e+04 | 2.589e+04 | -0.7% | -231.2 to -143.7 | GAIN, clear of the noise |
| power-capped share of samples | 0.7339 | 0.7157 | -2.5% | -0.02214 to -0.01413 | GAIN, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.97 | 37.87 | -0.3% | -0.26 to +0.06144 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.695e+04 | 2.702e+04 | +0.3% | -43.72 to +185.3 | STEADY, under the floor |
| energy per served request (J) | 26.34 | 26.41 | +0.3% | -0.04273 to +0.1811 | STEADY, under the floor |
| power, GPU mean (W) | 81.23 | 81.44 | +0.3% | -0.1302 to +0.5595 | STEADY, under the floor |
| requests served | 1023 | 1023 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 245.8 | 244.1 | -0.7% | -5.047 to +1.599 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 862.3 | 845.3 | -2.0% | -47.81 to +13.74 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1189 | 1179 | -0.8% | -23.93 to +5.142 | GAIN, not beyond the noise |
| temperature, peak (C) | 52.6 | 52.6 | +0.0% | -0.8778 to +0.8778 | STEADY, under the floor |
| temperature, mean (C) | 47.24 | 47.14 | -0.2% | -0.4123 to +0.2111 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.608e+04 | 2.607e+04 | -0.0% | -39.34 to +21.84 | STEADY, under the floor |
| power-capped share of samples | 0.7339 | 0.7356 | +0.2% | -0.003066 to +0.006452 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.87 | 38.2 | +0.9% | +0.1411 to +0.5171 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.702e+04 | 2.678e+04 | -0.9% | -366.2 to -99.72 | GAIN, clear of the noise |
| energy per served request (J) | 26.41 | 26.18 | -0.9% | -0.3579 to -0.09748 | GAIN, clear of the noise |
| power, GPU mean (W) | 81.44 | 80.74 | -0.9% | -1.109 to -0.3006 | GAIN, clear of the noise |
| requests served | 1023 | 1023 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 244.1 | 244.5 | +0.2% | -4.185 to +5.152 | STEADY, under the floor |
| response time, 95th percentile (ms) | 845.3 | 833.7 | -1.4% | -46.91 to +23.83 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1179 | 1163 | -1.4% | -59.91 to +27.46 | GAIN, not beyond the noise |
| temperature, peak (C) | 52.6 | 52.2 | -0.8% | -1.08 to +0.28 | GAIN, not beyond the noise |
| temperature, mean (C) | 47.14 | 46.99 | -0.3% | -0.1976 to -0.1016 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.607e+04 | 2.589e+04 | -0.7% | -205 to -152.3 | GAIN, clear of the noise |
| power-capped share of samples | 0.7356 | 0.7157 | -2.7% | -0.02352 to -0.01614 | GAIN, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 37.97 -> 38.2 served requests per kJ, difference +0.2298 (95% interval +0.1219 to +0.3377).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: GAIN (within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 80.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*