# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 65.61 | 65.55 | 66.51 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 3.459e+04 | 3.458e+04 | 3.437e+04 |
| energy per served request (J) | 15.24 | 15.26 | 15.04 |
| power, GPU mean (W) | 104.3 | 104.2 | 103.6 |
| requests served | 2270 | 2267 | 2286 |
| requests not served | 546.4 | 549.4 | 529.8 |
| response time, mean (ms) | 4.155e+04 | 4.163e+04 | 4.076e+04 |
| response time, 95th percentile (ms) | 8.265e+04 | 8.278e+04 | 8.151e+04 |
| response time, 99th percentile (ms) | 8.756e+04 | 8.771e+04 | 8.594e+04 |
| temperature, peak (C) | 58 | 58 | 57.6 |
| temperature, mean (C) | 54.77 | 54.97 | 54.71 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 3.463e+04 | 3.463e+04 | 3.442e+04 |
| power-capped share of samples | 0.9955 | 0.9961 | 0.9714 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.61 | 66.51 | +1.4% | +0.4872 to +1.308 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.459e+04 | 3.437e+04 | -0.6% | -251.3 to -182.8 | GAIN, clear of the noise |
| energy per served request (J) | 15.24 | 15.04 | -1.4% | -0.3002 to -0.1114 | GAIN, clear of the noise |
| power, GPU mean (W) | 104.3 | 103.6 | -0.6% | -0.7377 to -0.5687 | GAIN, clear of the noise |
| requests served | 2270 | 2286 | +0.7% | +3.562 to +29.64 | GAIN, clear of the noise |
| requests not served | 546.4 | 529.8 | -3.0% | -29.64 to -3.562 | GAIN, clear of the noise |
| response time, mean (ms) | 4.155e+04 | 4.076e+04 | -1.9% | -1367 to -206.1 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 8.265e+04 | 8.151e+04 | -1.4% | -2050 to -232.7 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 8.756e+04 | 8.594e+04 | -1.9% | -2815 to -438.9 | GAIN, clear of the noise |
| temperature, peak (C) | 58 | 57.6 | -0.7% | -1.08 to +0.28 | GAIN, not beyond the noise |
| temperature, mean (C) | 54.77 | 54.71 | -0.1% | -0.6192 to +0.5012 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.463e+04 | 3.442e+04 | -0.6% | -246.4 to -183.8 | GAIN, clear of the noise |
| power-capped share of samples | 0.9955 | 0.9714 | -2.4% | -0.09009 to +0.04193 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.61 | 65.55 | -0.1% | -0.2899 to +0.1559 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.459e+04 | 3.458e+04 | -0.0% | -29.48 to +8.68 | STEADY, under the floor |
| energy per served request (J) | 15.24 | 15.26 | +0.1% | -0.03609 to +0.06732 | STEADY, under the floor |
| power, GPU mean (W) | 104.3 | 104.2 | -0.0% | -0.09924 to +0.05378 | STEADY, under the floor |
| requests served | 2270 | 2267 | -0.1% | -9.628 to +3.628 | STEADY, under the floor |
| requests not served | 546.4 | 549.4 | +0.5% | -3.628 to +9.628 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.155e+04 | 4.163e+04 | +0.2% | -274.4 to +443.4 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.265e+04 | 8.278e+04 | +0.2% | -375.6 to +638.6 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.756e+04 | 8.771e+04 | +0.2% | -341.4 to +623.6 | STEADY, under the floor |
| temperature, peak (C) | 58 | 58 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.77 | 54.97 | +0.4% | -0.3023 to +0.6863 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.463e+04 | 3.463e+04 | -0.0% | -15.76 to +8.371 | STEADY, under the floor |
| power-capped share of samples | 0.9955 | 0.9961 | +0.1% | +7.385e-05 to +0.001135 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.55 | 66.51 | +1.5% | +0.582 to +1.347 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.458e+04 | 3.437e+04 | -0.6% | -253.9 to -159.4 | GAIN, clear of the noise |
| energy per served request (J) | 15.26 | 15.04 | -1.5% | -0.31 to -0.1328 | GAIN, clear of the noise |
| power, GPU mean (W) | 104.2 | 103.6 | -0.6% | -0.7685 to -0.4925 | GAIN, clear of the noise |
| requests served | 2267 | 2286 | +0.9% | +8.269 to +30.93 | GAIN, clear of the noise |
| requests not served | 549.4 | 529.8 | -3.6% | -30.93 to -8.269 | GAIN, clear of the noise |
| response time, mean (ms) | 4.163e+04 | 4.076e+04 | -2.1% | -1177 to -564.3 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 8.278e+04 | 8.151e+04 | -1.5% | -1856 to -690.2 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 8.771e+04 | 8.594e+04 | -2.0% | -2761 to -774.8 | GAIN, clear of the noise |
| temperature, peak (C) | 58 | 57.6 | -0.7% | -1.08 to +0.28 | GAIN, not beyond the noise |
| temperature, mean (C) | 54.97 | 54.71 | -0.5% | -0.3747 to -0.1274 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.463e+04 | 3.442e+04 | -0.6% | -235.2 to -187.6 | GAIN, clear of the noise |
| power-capped share of samples | 0.9961 | 0.9714 | -2.5% | -0.09069 to +0.04133 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 65.61 -> 66.51 served requests per kJ, difference +0.8974 (95% interval +0.4872 to +1.308).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: GAIN (within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 10.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*