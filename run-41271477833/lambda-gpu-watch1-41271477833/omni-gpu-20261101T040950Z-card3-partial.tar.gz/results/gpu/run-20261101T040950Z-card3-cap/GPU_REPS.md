# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.01 | 41.86 | 42.55 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.289e+04 | 6.311e+04 | 6.209e+04 |
| energy per served request (J) | 23.81 | 23.89 | 23.5 |
| power, GPU mean (W) | 186.7 | 187 | 184 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 117.1 | 116.5 | 117 |
| response time, 95th percentile (ms) | 389.8 | 388.3 | 389.6 |
| response time, 99th percentile (ms) | 669.2 | 667.2 | 666.3 |
| temperature, peak (C) | 62.5 | 62.5 | 62.5 |
| temperature, mean (C) | 51.84 | 51.87 | 51.89 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.287e+04 | 6.289e+04 | 6.264e+04 |
| power-capped share of samples | 0.6656 | 0.6785 | 0.6574 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.01 | 42.55 | +1.3% | -2.186 to +3.265 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.289e+04 | 6.209e+04 | -1.3% | -4970 to +3366 | GAIN, not beyond the noise |
| energy per served request (J) | 23.81 | 23.5 | -1.3% | -1.881 to +1.274 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.7 | 184 | -1.5% | -9.869 to +4.433 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 117.1 | 117 | -0.1% | -9.69 to +9.564 | STEADY, under the floor |
| response time, 95th percentile (ms) | 389.8 | 389.6 | -0.0% | -12.42 to +12.15 | STEADY, under the floor |
| response time, 99th percentile (ms) | 669.2 | 666.3 | -0.4% | -65.59 to +59.79 | STEADY, under the floor |
| temperature, peak (C) | 62.5 | 62.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 51.84 | 51.89 | +0.1% | -1.676 to +1.785 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.287e+04 | 6.264e+04 | -0.4% | -2063 to +1604 | STEADY, under the floor |
| power-capped share of samples | 0.6656 | 0.6574 | -1.2% | -0.3296 to +0.3133 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.01 | 41.86 | -0.3% | -10.57 to +10.28 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.289e+04 | 6.311e+04 | +0.4% | -1.544e+04 to +1.588e+04 | STEADY, under the floor |
| energy per served request (J) | 23.81 | 23.89 | +0.4% | -5.844 to +6.011 | STEADY, under the floor |
| power, GPU mean (W) | 186.7 | 187 | +0.1% | -40.93 to +41.37 | STEADY, under the floor |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 117.1 | 116.5 | -0.5% | -6.798 to +5.631 | STEADY, under the floor |
| response time, 95th percentile (ms) | 389.8 | 388.3 | -0.4% | -4.914 to +2.058 | STEADY, under the floor |
| response time, 99th percentile (ms) | 669.2 | 667.2 | -0.3% | -81.1 to +76.96 | STEADY, under the floor |
| temperature, peak (C) | 62.5 | 62.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 51.84 | 51.87 | +0.1% | -1.211 to +1.285 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.287e+04 | 6.289e+04 | +0.0% | -1172 to +1224 | STEADY, under the floor |
| power-capped share of samples | 0.6656 | 0.6785 | +1.9% | -0.001633 to +0.02751 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.86 | 42.55 | +1.6% | -7.012 to +8.383 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.311e+04 | 6.209e+04 | -1.6% | -1.252e+04 to +1.047e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 23.89 | 23.5 | -1.6% | -4.737 to +3.963 | GAIN, not beyond the noise |
| power, GPU mean (W) | 187 | 184 | -1.6% | -36.93 to +31.06 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 116.5 | 117 | +0.4% | -2.891 to +3.933 | STEADY, under the floor |
| response time, 95th percentile (ms) | 388.3 | 389.6 | +0.3% | -14.47 to +17.06 | STEADY, under the floor |
| response time, 99th percentile (ms) | 667.2 | 666.3 | -0.1% | -17.17 to +15.51 | STEADY, under the floor |
| temperature, peak (C) | 62.5 | 62.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 51.87 | 51.89 | +0.0% | -0.4656 to +0.5003 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.289e+04 | 6.264e+04 | -0.4% | -3287 to +2776 | STEADY, under the floor |
| power-capped share of samples | 0.6785 | 0.6574 | -3.1% | -0.3279 to +0.2858 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.01 -> 42.55 served requests per kJ, difference +0.5396 (95% interval -2.186 to +3.265).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| watch | 2 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 20.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*