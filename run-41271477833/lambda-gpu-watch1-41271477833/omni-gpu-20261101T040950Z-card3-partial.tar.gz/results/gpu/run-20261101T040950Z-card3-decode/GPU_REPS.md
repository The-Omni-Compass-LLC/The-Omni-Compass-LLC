# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.77 | 45.83 | 46.07 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.272e+05 | 1.271e+05 | 1.264e+05 |
| energy per served request (J) | 21.85 | 21.82 | 21.71 |
| power, GPU mean (W) | 199.3 | 199.3 | 197.9 |
| requests served | 5824 | 5824 | 5824 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.46 | 96.44 | 96.38 |
| response time, 95th percentile (ms) | 274.6 | 274.7 | 274.1 |
| response time, 99th percentile (ms) | 449.9 | 449.7 | 449.2 |
| temperature, peak (C) | 67.67 | 67.67 | 68 |
| temperature, mean (C) | 52.88 | 52.84 | 52.82 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.273e+05 | 1.273e+05 | 1.274e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.77 | 46.07 | +0.6% | -0.5788 to +1.168 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.272e+05 | 1.264e+05 | -0.6% | -3259 to +1619 | GAIN, not beyond the noise |
| energy per served request (J) | 21.85 | 21.71 | -0.6% | -0.5596 to +0.278 | GAIN, not beyond the noise |
| power, GPU mean (W) | 199.3 | 197.9 | -0.7% | -5.712 to +2.934 | GAIN, not beyond the noise |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.46 | 96.38 | -0.1% | -0.4948 to +0.3446 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.6 | 274.1 | -0.2% | -1.799 to +0.7931 | STEADY, under the floor |
| response time, 99th percentile (ms) | 449.9 | 449.2 | -0.2% | -4.422 to +2.963 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 68 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 52.88 | 52.82 | -0.1% | -0.4167 to +0.2839 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.274e+05 | +0.1% | -140.3 to +390.1 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.77 | 45.83 | +0.1% | -1.205 to +1.311 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.272e+05 | 1.271e+05 | -0.1% | -3654 to +3350 | STEADY, under the floor |
| energy per served request (J) | 21.85 | 21.82 | -0.1% | -0.6274 to +0.5752 | STEADY, under the floor |
| power, GPU mean (W) | 199.3 | 199.3 | +0.0% | -5.616 to +5.673 | STEADY, under the floor |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.46 | 96.44 | -0.0% | -0.6054 to +0.56 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.6 | 274.7 | +0.0% | -1.065 to +1.143 | STEADY, under the floor |
| response time, 99th percentile (ms) | 449.9 | 449.7 | -0.0% | -7.22 to +6.855 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 67.67 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 52.88 | 52.84 | -0.1% | -0.4581 to +0.377 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.273e+05 | +0.0% | -372.6 to +481.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.83 | 46.07 | +0.5% | -0.1588 to +0.6424 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.271e+05 | 1.264e+05 | -0.5% | -1776 to +439.9 | GAIN, not beyond the noise |
| energy per served request (J) | 21.82 | 21.71 | -0.5% | -0.3049 to +0.07553 | GAIN, not beyond the noise |
| power, GPU mean (W) | 199.3 | 197.9 | -0.7% | -3.333 to +0.498 | GAIN, not beyond the noise |
| requests served | 5824 | 5824 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.44 | 96.38 | -0.1% | -0.749 to +0.6442 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.7 | 274.1 | -0.2% | -2.358 to +1.274 | STEADY, under the floor |
| response time, 99th percentile (ms) | 449.7 | 449.2 | -0.1% | -6.909 to +5.815 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 68 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 52.84 | 52.82 | -0.0% | -0.1557 to +0.1041 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.274e+05 | +0.1% | -369.4 to +510.5 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.77 -> 46.07 served requests per kJ, difference +0.2949 (95% interval -0.5788 to +1.168).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.209 | 0.3 | 0 | 440 | 27 | True |
| omni | 2 | 28 | 0 | 0 | 0 | 0.209 | 0.513 | 0 | 566 | 27 | True |
| omni | 3 | 28 | 0 | 0 | 0 | 0.235 | 0.358 | 0 | 598 | 27 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 65 | -160.9 | +0 |
| compass | 42 | 986 | -1009 | -5 |
| race | 39 | 140 | +744.8 | +15 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 84.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*