# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.71 | 60.39 | 60.43 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.287e+04 | 9.293e+04 | 9.289e+04 |
| energy per served request (J) | 16.47 | 16.56 | 16.55 |
| power, GPU mean (W) | 275 | 275.1 | 275.4 |
| requests served | 5638 | 5612 | 5613 |
| requests not served | 1324 | 1350 | 1349 |
| response time, mean (ms) | 4.284e+04 | 4.354e+04 | 4.355e+04 |
| response time, 95th percentile (ms) | 8.204e+04 | 8.341e+04 | 8.335e+04 |
| response time, 99th percentile (ms) | 8.543e+04 | 8.681e+04 | 8.675e+04 |
| temperature, peak (C) | 68.5 | 69 | 69 |
| temperature, mean (C) | 64.68 | 65.65 | 65.7 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.296e+04 | 9.305e+04 | 9.295e+04 |
| power-capped share of samples | 0.9785 | 0.9791 | 0.9788 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.71 | 60.43 | -0.5% | -5.422 to +4.865 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.287e+04 | 9.289e+04 | +0.0% | -2003 to +2033 | STEADY, under the floor |
| energy per served request (J) | 16.47 | 16.55 | +0.5% | -1.324 to +1.476 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 275.4 | +0.1% | -0.05126 to +0.7646 | STEADY, under the floor |
| requests served | 5638 | 5613 | -0.4% | -380.8 to +330.8 | STEADY, under the floor |
| requests not served | 1324 | 1349 | +1.9% | -330.8 to +380.8 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.284e+04 | 4.355e+04 | +1.7% | -9998 to +1.142e+04 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.204e+04 | 8.335e+04 | +1.6% | -1.74e+04 to +2.002e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.543e+04 | 8.675e+04 | +1.5% | -1.754e+04 to +2.018e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 68.5 | 69 | +0.7% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 64.68 | 65.7 | +1.6% | -9.93 to +11.98 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.296e+04 | 9.295e+04 | -0.0% | -1173 to +1163 | STEADY, under the floor |
| power-capped share of samples | 0.9785 | 0.9788 | +0.0% | -0.0341 to +0.03464 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.71 | 60.39 | -0.5% | -4.346 to +3.705 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.287e+04 | 9.293e+04 | +0.1% | -1079 to +1204 | STEADY, under the floor |
| energy per served request (J) | 16.47 | 16.56 | +0.5% | -1.007 to +1.181 | power given, not beyond the noise |
| power, GPU mean (W) | 275 | 275.1 | +0.0% | -0.5215 to +0.6636 | STEADY, under the floor |
| requests served | 5638 | 5612 | -0.5% | -330.9 to +278.9 | STEADY, under the floor |
| requests not served | 1324 | 1350 | +2.0% | -278.9 to +330.9 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.284e+04 | 4.354e+04 | +1.6% | -8592 to +9983 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.204e+04 | 8.341e+04 | +1.7% | -1.476e+04 to +1.749e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.543e+04 | 8.681e+04 | +1.6% | -1.495e+04 to +1.77e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 68.5 | 69 | +0.7% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 64.68 | 65.65 | +1.5% | -9.405 to +11.34 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.296e+04 | 9.305e+04 | +0.1% | -189.9 to +378.7 | STEADY, under the floor |
| power-capped share of samples | 0.9785 | 0.9791 | +0.1% | -0.01486 to +0.01602 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.39 | 60.43 | +0.1% | -1.076 to +1.16 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.293e+04 | 9.289e+04 | -0.1% | -924.5 to +828.7 | STEADY, under the floor |
| energy per served request (J) | 16.56 | 16.55 | -0.1% | -0.3175 to +0.2945 | STEADY, under the floor |
| power, GPU mean (W) | 275.1 | 275.4 | +0.1% | -0.7148 to +1.286 | STEADY, under the floor |
| requests served | 5612 | 5613 | +0.0% | -49.82 to +51.82 | STEADY, under the floor |
| requests not served | 1350 | 1349 | -0.1% | -51.82 to +49.82 | STEADY, under the floor |
| response time, mean (ms) | 4.354e+04 | 4.355e+04 | +0.0% | -1407 to +1438 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.341e+04 | 8.335e+04 | -0.1% | -2645 to +2528 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.681e+04 | 8.675e+04 | -0.1% | -2598 to +2472 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 65.65 | 65.7 | +0.1% | -0.525 to +0.6418 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.305e+04 | 9.295e+04 | -0.1% | -983.4 to +784 | STEADY, under the floor |
| power-capped share of samples | 0.9791 | 0.9788 | -0.0% | -0.01924 to +0.01862 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.71 -> 60.43 served requests per kJ, difference -0.2786 (95% interval -5.422 to +4.865).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*