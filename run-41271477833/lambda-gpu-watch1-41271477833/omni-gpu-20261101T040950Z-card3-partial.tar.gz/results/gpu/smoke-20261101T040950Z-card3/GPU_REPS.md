# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
1 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.54 | 37.09 | 38.33 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 4.84e+04 | 5.029e+04 | 4.866e+04 |
| energy per served request (J) | 25.95 | 26.96 | 26.09 |
| power, GPU mean (W) | 226 | 234.8 | 227.2 |
| requests served | 1865 | 1865 | 1865 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 94.22 | 95.6 | 95.81 |
| response time, 95th percentile (ms) | 296.9 | 305.8 | 307.5 |
| response time, 99th percentile (ms) | 532.9 | 543.3 | 546.2 |
| temperature, peak (C) | 72 | 74 | 74 |
| temperature, mean (C) | 56.75 | 58.37 | 58.34 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 4.921e+04 | 4.949e+04 | 4.94e+04 |
| power-capped share of samples | 0.6512 | 0.6624 | 0.6611 |

## Total: Omni governs against native, 1 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.54 | 38.33 | -0.5% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.84e+04 | 4.866e+04 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 25.95 | 26.09 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 226 | 227.2 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1865 | 1865 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 94.22 | 95.81 | +1.7% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 296.9 | 307.5 | +3.6% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 532.9 | 546.2 | +2.5% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 72 | 74 | +2.8% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 56.75 | 58.34 | +2.8% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.921e+04 | 4.94e+04 | +0.4% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6512 | 0.6611 | +1.5% | +nan to +nan | no interval (too few repetitions) |

## Observation: omni watching (writes nothing) against native, 1 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.54 | 37.09 | -3.8% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 4.84e+04 | 5.029e+04 | +3.9% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 25.95 | 26.96 | +3.9% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 226 | 234.8 | +3.9% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1865 | 1865 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 94.22 | 95.6 | +1.5% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 296.9 | 305.8 | +3.0% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 532.9 | 543.3 | +2.0% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 72 | 74 | +2.8% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 56.75 | 58.37 | +2.9% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.921e+04 | 4.949e+04 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6512 | 0.6624 | +1.7% | +nan to +nan | no interval (too few repetitions) |

## Authority: Omni governs against Omni watching, 1 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.09 | 38.33 | +3.3% | +nan to +nan | no interval (too few repetitions) |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.029e+04 | 4.866e+04 | -3.2% | +nan to +nan | no interval (too few repetitions) |
| energy per served request (J) | 26.96 | 26.09 | -3.2% | +nan to +nan | no interval (too few repetitions) |
| power, GPU mean (W) | 234.8 | 227.2 | -3.2% | +nan to +nan | no interval (too few repetitions) |
| requests served | 1865 | 1865 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| requests not served | 0 | 0 | +0 | +nan to +nan | no interval (too few repetitions) |
| response time, mean (ms) | 95.6 | 95.81 | +0.2% | +nan to +nan | no interval (too few repetitions) |
| response time, 95th percentile (ms) | 305.8 | 307.5 | +0.6% | +nan to +nan | no interval (too few repetitions) |
| response time, 99th percentile (ms) | 543.3 | 546.2 | +0.5% | +nan to +nan | no interval (too few repetitions) |
| temperature, peak (C) | 74 | 74 | +0.0% | +nan to +nan | no interval (too few repetitions) |
| temperature, mean (C) | 58.37 | 58.34 | -0.0% | +nan to +nan | no interval (too few repetitions) |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 4.949e+04 | 4.94e+04 | -0.2% | +nan to +nan | no interval (too few repetitions) |
| power-capped share of samples | 0.6624 | 0.6611 | -0.2% | +nan to +nan | no interval (too few repetitions) |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.54 -> 38.33 served requests per kJ, difference -0.2115 (95% interval +nan to +nan).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: no interval (too few repetitions). Authority (omni against watch): no interval (too few repetitions).
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 94 | 0 | n/a | n/a | 0 | 94 | 0 |
| watch | 1 | 92 | 0 | n/a | n/a | 0 | 92 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*