# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.68 | 39.81 | 39.86 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.556e+05 | 1.551e+05 | 1.549e+05 |
| energy per served request (J) | 25.2 | 25.12 | 25.09 |
| power, GPU mean (W) | 245.2 | 244.4 | 244.1 |
| requests served | 6173 | 6173 | 6173 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 88.32 | 88.59 | 88.42 |
| response time, 95th percentile (ms) | 250.6 | 251.3 | 250.9 |
| response time, 99th percentile (ms) | 444.4 | 446.4 | 445.8 |
| temperature, peak (C) | 75 | 75 | 75 |
| temperature, mean (C) | 59.78 | 59.8 | 59.77 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.557e+05 | 1.557e+05 | 1.558e+05 |
| power-capped share of samples | 0.7385 | 0.7365 | 0.7399 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.68 | 39.86 | +0.5% | -0.213 to +0.578 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.556e+05 | 1.549e+05 | -0.5% | -2247 to +821.2 | STEADY, under the floor |
| energy per served request (J) | 25.2 | 25.09 | -0.5% | -0.364 to +0.133 | STEADY, under the floor |
| power, GPU mean (W) | 245.2 | 244.1 | -0.4% | -3.563 to +1.48 | STEADY, under the floor |
| requests served | 6173 | 6173 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.32 | 88.42 | +0.1% | -0.4936 to +0.6985 | STEADY, under the floor |
| response time, 95th percentile (ms) | 250.6 | 250.9 | +0.1% | -4.3 to +4.845 | STEADY, under the floor |
| response time, 99th percentile (ms) | 444.4 | 445.8 | +0.3% | -6.099 to +8.962 | STEADY, under the floor |
| temperature, peak (C) | 75 | 75 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.78 | 59.77 | -0.0% | -0.2057 to +0.18 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.557e+05 | 1.558e+05 | +0.0% | -768.2 to +870.4 | STEADY, under the floor |
| power-capped share of samples | 0.7385 | 0.7399 | +0.2% | -0.0224 to +0.02521 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.68 | 39.81 | +0.3% | -0.1154 to +0.3772 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.556e+05 | 1.551e+05 | -0.3% | -1454 to +439.5 | STEADY, under the floor |
| energy per served request (J) | 25.2 | 25.12 | -0.3% | -0.2355 to +0.07119 | STEADY, under the floor |
| power, GPU mean (W) | 245.2 | 244.4 | -0.3% | -2.257 to +0.7718 | STEADY, under the floor |
| requests served | 6173 | 6173 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.32 | 88.59 | +0.3% | -0.04801 to +0.5846 | STEADY, under the floor |
| response time, 95th percentile (ms) | 250.6 | 251.3 | +0.3% | -0.6428 to +1.978 | STEADY, under the floor |
| response time, 99th percentile (ms) | 444.4 | 446.4 | +0.5% | -4.245 to +8.304 | STEADY, under the floor |
| temperature, peak (C) | 75 | 75 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.78 | 59.8 | +0.0% | -0.1717 to +0.2045 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.557e+05 | 1.557e+05 | +0.0% | -278.1 to +307.7 | STEADY, under the floor |
| power-capped share of samples | 0.7385 | 0.7365 | -0.3% | -0.01485 to +0.01098 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.81 | 39.86 | +0.1% | -0.4868 to +0.5901 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.551e+05 | 1.549e+05 | -0.1% | -2293 to +1882 | STEADY, under the floor |
| energy per served request (J) | 25.12 | 25.09 | -0.1% | -0.3715 to +0.3049 | STEADY, under the floor |
| power, GPU mean (W) | 244.4 | 244.1 | -0.1% | -3.534 to +2.936 | STEADY, under the floor |
| requests served | 6173 | 6173 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.59 | 88.42 | -0.2% | -0.5342 to +0.2026 | STEADY, under the floor |
| response time, 95th percentile (ms) | 251.3 | 250.9 | -0.2% | -4.12 to +3.331 | STEADY, under the floor |
| response time, 99th percentile (ms) | 446.4 | 445.8 | -0.1% | -4.343 to +3.146 | STEADY, under the floor |
| temperature, peak (C) | 75 | 75 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.8 | 59.77 | -0.0% | -0.2448 to +0.1862 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.557e+05 | 1.558e+05 | +0.0% | -508.3 to +581 | STEADY, under the floor |
| power-capped share of samples | 0.7365 | 0.7399 | +0.5% | -0.01836 to +0.02505 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.68 -> 39.86 served requests per kJ, difference +0.1825 (95% interval -0.213 to +0.578).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 269 | 0 | n/a | n/a | 0 | 269 | 0 |
| omni | 2 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| omni | 3 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*