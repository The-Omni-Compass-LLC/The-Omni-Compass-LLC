# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.37 | 47.45 | 47.71 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.228e+05 | 1.227e+05 | 1.22e+05 |
| energy per served request (J) | 21.11 | 21.08 | 20.96 |
| power, GPU mean (W) | 193.4 | 193.2 | 192.1 |
| requests served | 5819 | 5819 | 5819 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.29 | 96.31 | 96.21 |
| response time, 95th percentile (ms) | 274.5 | 274.8 | 274.1 |
| response time, 99th percentile (ms) | 448.1 | 448.5 | 447.7 |
| temperature, peak (C) | 65 | 65 | 65 |
| temperature, mean (C) | 50.92 | 50.97 | 50.95 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.226e+05 | 1.226e+05 | 1.227e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.37 | 47.71 | +0.7% | -0.4623 to +1.152 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.228e+05 | 1.22e+05 | -0.7% | -2969 to +1192 | GAIN, not beyond the noise |
| energy per served request (J) | 21.11 | 20.96 | -0.7% | -0.5103 to +0.2048 | GAIN, not beyond the noise |
| power, GPU mean (W) | 193.4 | 192.1 | -0.7% | -4.995 to +2.36 | GAIN, not beyond the noise |
| requests served | 5819 | 5819 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.29 | 96.21 | -0.1% | -0.6831 to +0.5317 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.5 | 274.1 | -0.2% | -3.657 to +2.727 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.1 | 447.7 | -0.1% | -3.931 to +3.216 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.92 | 50.95 | +0.1% | -0.1147 to +0.1796 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.226e+05 | 1.227e+05 | +0.0% | -481.4 to +566.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.37 | 47.45 | +0.2% | -0.8731 to +1.028 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.228e+05 | 1.227e+05 | -0.2% | -2637 to +2243 | STEADY, under the floor |
| energy per served request (J) | 21.11 | 21.08 | -0.2% | -0.4531 to +0.3854 | STEADY, under the floor |
| power, GPU mean (W) | 193.4 | 193.2 | -0.1% | -4.407 to +4.033 | STEADY, under the floor |
| requests served | 5819 | 5819 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.29 | 96.31 | +0.0% | -0.6636 to +0.707 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.5 | 274.8 | +0.1% | -3.943 to +4.442 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.1 | 448.5 | +0.1% | -4.353 to +5.182 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.92 | 50.97 | +0.1% | -0.1845 to +0.2909 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.226e+05 | 1.226e+05 | -0.0% | -319.5 to +256.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.45 | 47.71 | +0.6% | -0.3573 to +0.8913 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.227e+05 | 1.22e+05 | -0.6% | -2317 to +933.4 | GAIN, not beyond the noise |
| energy per served request (J) | 21.08 | 20.96 | -0.6% | -0.3981 to +0.1604 | GAIN, not beyond the noise |
| power, GPU mean (W) | 193.2 | 192.1 | -0.6% | -4.143 to +1.883 | GAIN, not beyond the noise |
| requests served | 5819 | 5819 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.31 | 96.21 | -0.1% | -0.6247 to +0.43 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.8 | 274.1 | -0.3% | -3.616 to +2.187 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.5 | 447.7 | -0.2% | -4.496 to +2.952 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.97 | 50.95 | -0.0% | -0.36 to +0.3185 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.226e+05 | 1.227e+05 | +0.1% | -213.7 to +362.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.37 -> 47.71 served requests per kJ, difference +0.3447 (95% interval -0.4623 to +1.152).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.228 | 0.32 | 0 | 812 | 27 | True |
| omni | 2 | 22 | 0 | 0 | 0 | 0.22 | 0.325 | 0 | 712 | 21 | True |
| omni | 3 | 26 | 0 | 0 | 0 | 0.223 | 0.368 | 0 | 702 | 25 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | -43.48 | +0 |
| compass | 38 | 1007 | +9.217 | +45 |
| race | 35 | 110 | -644.3 | -44 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 76.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*