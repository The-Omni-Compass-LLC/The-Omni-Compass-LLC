# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.57 | 60.81 | 60.69 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.289e+04 | 9.29e+04 | 9.279e+04 |
| energy per served request (J) | 16.51 | 16.45 | 16.48 |
| power, GPU mean (W) | 276.5 | 276.1 | 276.4 |
| requests served | 5626 | 5649 | 5632 |
| requests not served | 1308 | 1285 | 1302 |
| response time, mean (ms) | 4.285e+04 | 4.223e+04 | 4.27e+04 |
| response time, 95th percentile (ms) | 8.196e+04 | 8.07e+04 | 8.169e+04 |
| response time, 99th percentile (ms) | 8.533e+04 | 8.408e+04 | 8.506e+04 |
| temperature, peak (C) | 68 | 67 | 68 |
| temperature, mean (C) | 64.68 | 63.79 | 64.67 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.299e+04 | 9.297e+04 | 9.28e+04 |
| power-capped share of samples | 0.9836 | 0.9821 | 0.9112 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.57 | 60.69 | +0.2% | -0.08179 to +0.3226 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.289e+04 | 9.279e+04 | -0.1% | -1338 to +1152 | STEADY, under the floor |
| energy per served request (J) | 16.51 | 16.48 | -0.2% | -0.08327 to +0.01785 | STEADY, under the floor |
| power, GPU mean (W) | 276.5 | 276.4 | -0.0% | -2.076 to +1.943 | STEADY, under the floor |
| requests served | 5626 | 5632 | +0.1% | -51.68 to +62.68 | STEADY, under the floor |
| requests not served | 1308 | 1302 | -0.4% | -62.68 to +51.68 | STEADY, under the floor |
| response time, mean (ms) | 4.285e+04 | 4.27e+04 | -0.3% | -1455 to +1158 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.196e+04 | 8.169e+04 | -0.3% | -2972 to +2421 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.533e+04 | 8.506e+04 | -0.3% | -3043 to +2492 | STEADY, under the floor |
| temperature, peak (C) | 68 | 68 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 64.68 | 64.67 | -0.0% | -0.9462 to +0.9241 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.299e+04 | 9.28e+04 | -0.2% | -410.3 to +37.07 | STEADY, under the floor |
| power-capped share of samples | 0.9836 | 0.9112 | -7.4% | -0.9375 to +0.7927 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.57 | 60.81 | +0.4% | -4.893 to +5.37 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.289e+04 | 9.29e+04 | +0.0% | -1556 to +1584 | STEADY, under the floor |
| energy per served request (J) | 16.51 | 16.45 | -0.4% | -1.461 to +1.331 | STEADY, under the floor |
| power, GPU mean (W) | 276.5 | 276.1 | -0.2% | -8.188 to +7.296 | STEADY, under the floor |
| requests served | 5626 | 5649 | +0.4% | -358.2 to +404.2 | STEADY, under the floor |
| requests not served | 1308 | 1285 | -1.8% | -404.2 to +358.2 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.285e+04 | 4.223e+04 | -1.5% | -1.065e+04 to +9401 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.196e+04 | 8.07e+04 | -1.5% | -2.179e+04 to +1.926e+04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.533e+04 | 8.408e+04 | -1.5% | -2.121e+04 to +1.872e+04 | GAIN, not beyond the noise |
| temperature, peak (C) | 68 | 67 | -1.5% | -1 to -1 | GAIN, clear of the noise |
| temperature, mean (C) | 64.68 | 63.79 | -1.4% | -10.79 to +8.999 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.299e+04 | 9.297e+04 | -0.0% | -188.3 to +143.4 | STEADY, under the floor |
| power-capped share of samples | 0.9836 | 0.9821 | -0.2% | -0.005108 to +0.002126 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.81 | 60.69 | -0.2% | -5.451 to +5.215 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.29e+04 | 9.279e+04 | -0.1% | -2922 to +2707 | STEADY, under the floor |
| energy per served request (J) | 16.45 | 16.48 | +0.2% | -1.414 to +1.479 | STEADY, under the floor |
| power, GPU mean (W) | 276.1 | 276.4 | +0.1% | -5.353 to +6.111 | STEADY, under the floor |
| requests served | 5649 | 5632 | -0.3% | -341.5 to +306.5 | STEADY, under the floor |
| requests not served | 1285 | 1302 | +1.4% | -306.5 to +341.5 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.223e+04 | 4.27e+04 | +1.1% | -8243 to +9192 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.07e+04 | 8.169e+04 | +1.2% | -1.684e+04 to +1.882e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.408e+04 | 8.506e+04 | +1.2% | -1.623e+04 to +1.817e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 67 | 68 | +1.5% | +1 to +1 | power given, clear of the noise |
| temperature, mean (C) | 63.79 | 64.67 | +1.4% | -8.075 to +9.841 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.297e+04 | 9.28e+04 | -0.2% | -553.6 to +225.4 | STEADY, under the floor |
| power-capped share of samples | 0.9821 | 0.9112 | -7.2% | -0.9396 to +0.7978 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.57 -> 60.69 served requests per kJ, difference +0.1204 (95% interval -0.08179 to +0.3226).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*