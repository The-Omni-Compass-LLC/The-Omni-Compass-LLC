# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.49 | 42.32 | 43.19 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.119e+04 | 6.144e+04 | 6.02e+04 |
| energy per served request (J) | 23.53 | 23.63 | 23.15 |
| power, GPU mean (W) | 182.6 | 182.3 | 179.5 |
| requests served | 2600 | 2600 | 2600 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 114.1 | 114.7 | 114.4 |
| response time, 95th percentile (ms) | 374 | 376.2 | 372.7 |
| response time, 99th percentile (ms) | 646.5 | 646.9 | 644.8 |
| temperature, peak (C) | 61 | 61 | 61 |
| temperature, mean (C) | 50.68 | 50.47 | 50.48 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.155e+04 | 6.147e+04 | 6.101e+04 |
| power-capped share of samples | 0.6867 | 0.673 | 0.6365 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.49 | 43.19 | +1.7% | -7.235 to +8.638 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.119e+04 | 6.02e+04 | -1.6% | -1.219e+04 to +1.021e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 23.53 | 23.15 | -1.6% | -4.69 to +3.928 | GAIN, not beyond the noise |
| power, GPU mean (W) | 182.6 | 179.5 | -1.7% | -37.42 to +31.14 | GAIN, not beyond the noise |
| requests served | 2600 | 2600 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.1 | 114.4 | +0.2% | -7.5 to +8.032 | STEADY, under the floor |
| response time, 95th percentile (ms) | 374 | 372.7 | -0.4% | -59.72 to +57.01 | STEADY, under the floor |
| response time, 99th percentile (ms) | 646.5 | 644.8 | -0.3% | -58.85 to +55.57 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.68 | 50.48 | -0.4% | -1.154 to +0.7544 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.155e+04 | 6.101e+04 | -0.9% | -4260 to +3192 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6867 | 0.6365 | -7.3% | -0.1724 to +0.07207 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.49 | 42.32 | -0.4% | -8.714 to +8.374 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.119e+04 | 6.144e+04 | +0.4% | -1.212e+04 to +1.262e+04 | STEADY, under the floor |
| energy per served request (J) | 23.53 | 23.63 | +0.4% | -4.66 to +4.853 | STEADY, under the floor |
| power, GPU mean (W) | 182.6 | 182.3 | -0.2% | -46.7 to +46.08 | STEADY, under the floor |
| requests served | 2600 | 2600 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.1 | 114.7 | +0.5% | -5.779 to +6.954 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 374 | 376.2 | +0.6% | -21.9 to +26.24 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 646.5 | 646.9 | +0.1% | -19.43 to +20.33 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.68 | 50.47 | -0.4% | -0.7114 to +0.2903 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.155e+04 | 6.147e+04 | -0.1% | -1065 to +908.3 | STEADY, under the floor |
| power-capped share of samples | 0.6867 | 0.673 | -2.0% | -0.04024 to +0.01296 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.32 | 43.19 | +2.1% | +0.2639 to +1.479 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.144e+04 | 6.02e+04 | -2.0% | -2405 to -76.39 | GAIN, clear of the noise |
| energy per served request (J) | 23.63 | 23.15 | -2.0% | -0.9251 to -0.02938 | GAIN, clear of the noise |
| power, GPU mean (W) | 182.3 | 179.5 | -1.6% | -14.94 to +9.285 | GAIN, not beyond the noise |
| requests served | 2600 | 2600 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.7 | 114.4 | -0.3% | -1.721 to +1.078 | STEADY, under the floor |
| response time, 95th percentile (ms) | 376.2 | 372.7 | -0.9% | -37.82 to +30.77 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 646.9 | 644.8 | -0.3% | -39.42 to +35.25 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 50.47 | 50.48 | +0.0% | -0.4426 to +0.4642 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.147e+04 | 6.101e+04 | -0.7% | -3195 to +2284 | GAIN, not beyond the noise |
| power-capped share of samples | 0.673 | 0.6365 | -5.4% | -0.1322 to +0.05911 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.49 -> 43.19 served requests per kJ, difference +0.7013 (95% interval -7.235 to +8.638).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*