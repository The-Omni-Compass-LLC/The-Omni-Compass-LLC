# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 44.75 | 44.76 | 44.78 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.285e+05 | 1.285e+05 | 1.284e+05 |
| energy per served request (J) | 22.35 | 22.34 | 22.33 |
| power, GPU mean (W) | 201.3 | 201.6 | 201.1 |
| requests served | 5752 | 5752 | 5752 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.12 | 96.28 | 96.21 |
| response time, 95th percentile (ms) | 264.5 | 265.1 | 264.6 |
| response time, 99th percentile (ms) | 450.7 | 452.8 | 452.6 |
| temperature, peak (C) | 67.33 | 67.33 | 67.33 |
| temperature, mean (C) | 53.19 | 53.18 | 53.12 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.283e+05 | 1.284e+05 | 1.283e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.75 | 44.78 | +0.1% | -0.3692 to +0.4402 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.285e+05 | 1.284e+05 | -0.1% | -1256 to +1051 | STEADY, under the floor |
| energy per served request (J) | 22.35 | 22.33 | -0.1% | -0.2184 to +0.1828 | STEADY, under the floor |
| power, GPU mean (W) | 201.3 | 201.1 | -0.1% | -2.032 to +1.772 | STEADY, under the floor |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.12 | 96.21 | +0.1% | -0.5356 to +0.7166 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.5 | 264.6 | +0.1% | -2.067 to +2.433 | STEADY, under the floor |
| response time, 99th percentile (ms) | 450.7 | 452.6 | +0.4% | -4.081 to +7.735 | STEADY, under the floor |
| temperature, peak (C) | 67.33 | 67.33 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 53.19 | 53.12 | -0.1% | -0.3974 to +0.2661 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.283e+05 | 1.283e+05 | -0.0% | -742.5 to +736 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.75 | 44.76 | +0.0% | -1.407 to +1.432 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.285e+05 | 1.285e+05 | -0.0% | -4120 to +4033 | STEADY, under the floor |
| energy per served request (J) | 22.35 | 22.34 | -0.0% | -0.7163 to +0.7011 | STEADY, under the floor |
| power, GPU mean (W) | 201.3 | 201.6 | +0.2% | -7.236 to +7.89 | STEADY, under the floor |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.12 | 96.28 | +0.2% | -0.181 to +0.4989 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.5 | 265.1 | +0.2% | -2.622 to +3.88 | STEADY, under the floor |
| response time, 99th percentile (ms) | 450.7 | 452.8 | +0.5% | -0.4143 to +4.613 | STEADY, under the floor |
| temperature, peak (C) | 67.33 | 67.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 53.19 | 53.18 | -0.0% | -0.4234 to +0.4112 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.283e+05 | 1.284e+05 | +0.1% | -252 to +529.5 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.76 | 44.78 | +0.1% | -1.319 to +1.364 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.285e+05 | 1.284e+05 | -0.0% | -3921 to +3804 | STEADY, under the floor |
| energy per served request (J) | 22.34 | 22.33 | -0.0% | -0.6816 to +0.6612 | STEADY, under the floor |
| power, GPU mean (W) | 201.6 | 201.1 | -0.2% | -7.738 to +6.823 | STEADY, under the floor |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.28 | 96.21 | -0.1% | -0.9587 to +0.8217 | STEADY, under the floor |
| response time, 95th percentile (ms) | 265.1 | 264.6 | -0.2% | -4.322 to +3.43 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.8 | 452.6 | -0.1% | -8.421 to +7.876 | STEADY, under the floor |
| temperature, peak (C) | 67.33 | 67.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 53.18 | 53.12 | -0.1% | -0.1508 to +0.03166 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.284e+05 | 1.283e+05 | -0.1% | -560.2 to +276.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 44.75 -> 44.78 served requests per kJ, difference +0.03548 (95% interval -0.3692 to +0.4402).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.213 | 0.259 | 0 | 304 | 27 | True |
| omni | 2 | 24 | 0 | 0 | 0 | 0.227 | 0.331 | 0 | 446 | 23 | True |
| omni | 3 | 26 | 0 | 0 | 0 | 0.208 | 0.42 | 0 | 410 | 25 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 65 | -225.3 | +0 |
| compass | 39 | 995 | +794.8 | -6 |
| fail_up | 1 | 7 | +87.17 | +0 |
| race | 35 | 161 | +524.3 | +7 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 78.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*