# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.63 | 38.61 | 38.54 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.582e+05 | 1.583e+05 | 1.586e+05 |
| energy per served request (J) | 25.89 | 25.9 | 25.95 |
| power, GPU mean (W) | 248.2 | 248.4 | 249.1 |
| requests served | 6111 | 6111 | 6111 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 90.57 | 90.73 | 90.64 |
| response time, 95th percentile (ms) | 269 | 271.2 | 269.6 |
| response time, 99th percentile (ms) | 461.8 | 462 | 462.2 |
| temperature, peak (C) | 76.67 | 76.67 | 77 |
| temperature, mean (C) | 61.43 | 61.38 | 61.5 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.584e+05 | 1.583e+05 | 1.584e+05 |
| power-capped share of samples | 0.7329 | 0.7348 | 0.7304 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.63 | 38.54 | -0.2% | -0.5029 to +0.3226 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.582e+05 | 1.586e+05 | +0.2% | -1340 to +2085 | STEADY, under the floor |
| energy per served request (J) | 25.89 | 25.95 | +0.2% | -0.2193 to +0.3411 | STEADY, under the floor |
| power, GPU mean (W) | 248.2 | 249.1 | +0.4% | -0.5819 to +2.458 | STEADY, under the floor |
| requests served | 6111 | 6111 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.57 | 90.64 | +0.1% | -0.3976 to +0.5351 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269 | 269.6 | +0.2% | -1.912 to +3.145 | STEADY, under the floor |
| response time, 99th percentile (ms) | 461.8 | 462.2 | +0.1% | -5.184 to +6.094 | STEADY, under the floor |
| temperature, peak (C) | 76.67 | 77 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 61.43 | 61.5 | +0.1% | -0.1811 to +0.3288 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.584e+05 | 1.584e+05 | -0.0% | -368.6 to +331.5 | STEADY, under the floor |
| power-capped share of samples | 0.7329 | 0.7304 | -0.3% | -0.005516 to +0.0005397 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.63 | 38.61 | -0.1% | -0.862 to +0.8187 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.582e+05 | 1.583e+05 | +0.1% | -3359 to +3543 | STEADY, under the floor |
| energy per served request (J) | 25.89 | 25.9 | +0.1% | -0.5497 to +0.5797 | STEADY, under the floor |
| power, GPU mean (W) | 248.2 | 248.4 | +0.1% | -4.899 to +5.361 | STEADY, under the floor |
| requests served | 6111 | 6111 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.57 | 90.73 | +0.2% | -0.6335 to +0.9463 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269 | 271.2 | +0.8% | -2.606 to +7.007 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 461.8 | 462 | +0.0% | -7.285 to +7.65 | STEADY, under the floor |
| temperature, peak (C) | 76.67 | 76.67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 61.43 | 61.38 | -0.1% | -0.1163 to +0.02234 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.584e+05 | 1.583e+05 | -0.1% | -425.1 to +167.6 | STEADY, under the floor |
| power-capped share of samples | 0.7329 | 0.7348 | +0.3% | -0.01328 to +0.01695 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.61 | 38.54 | -0.2% | -0.5964 to +0.4594 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.583e+05 | 1.586e+05 | +0.2% | -1874 to +2435 | STEADY, under the floor |
| energy per served request (J) | 25.9 | 25.95 | +0.2% | -0.3067 to +0.3985 | STEADY, under the floor |
| power, GPU mean (W) | 248.4 | 249.1 | +0.3% | -3.007 to +4.42 | STEADY, under the floor |
| requests served | 6111 | 6111 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.73 | 90.64 | -0.1% | -0.4118 to +0.2364 | STEADY, under the floor |
| response time, 95th percentile (ms) | 271.2 | 269.6 | -0.6% | -3.91 to +0.7411 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 462 | 462.2 | +0.1% | -1.689 to +2.233 | STEADY, under the floor |
| temperature, peak (C) | 76.67 | 77 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 61.38 | 61.5 | +0.2% | -0.07063 to +0.3123 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.583e+05 | 1.584e+05 | +0.1% | -521.7 to +742 | STEADY, under the floor |
| power-capped share of samples | 0.7348 | 0.7304 | -0.6% | -0.01716 to +0.008517 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.63 -> 38.54 served requests per kJ, difference -0.09012 (95% interval -0.5029 to +0.3226).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 1 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |
| watch | 2 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| watch | 3 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*