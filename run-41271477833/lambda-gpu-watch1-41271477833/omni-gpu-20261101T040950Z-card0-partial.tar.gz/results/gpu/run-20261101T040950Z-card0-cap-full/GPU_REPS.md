# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.07 | 60.33 | 60.36 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.278e+04 | 9.283e+04 | 9.278e+04 |
| energy per served request (J) | 16.65 | 16.58 | 16.57 |
| power, GPU mean (W) | 275.2 | 274.9 | 274.8 |
| requests served | 5573 | 5600 | 5600 |
| requests not served | 1263 | 1236 | 1236 |
| response time, mean (ms) | 4.235e+04 | 4.236e+04 | 4.216e+04 |
| response time, 95th percentile (ms) | 8.085e+04 | 7.995e+04 | 7.993e+04 |
| response time, 99th percentile (ms) | 8.405e+04 | 8.314e+04 | 8.311e+04 |
| temperature, peak (C) | 69 | 69 | 69 |
| temperature, mean (C) | 65.19 | 65.96 | 66.11 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.282e+04 | 9.288e+04 | 9.285e+04 |
| power-capped share of samples | 0.9803 | 0.979 | 0.973 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.07 | 60.36 | +0.5% | -4.088 to +4.663 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.278e+04 | 9.278e+04 | +0.0% | -1264 to +1275 | STEADY, under the floor |
| energy per served request (J) | 16.65 | 16.57 | -0.5% | -1.299 to +1.138 | STEADY, under the floor |
| power, GPU mean (W) | 275.2 | 274.8 | -0.2% | -2.862 to +2.002 | STEADY, under the floor |
| requests served | 5573 | 5600 | +0.5% | -455.8 to +509.8 | STEADY, under the floor |
| requests not served | 1263 | 1236 | -2.1% | -509.8 to +455.8 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.235e+04 | 4.216e+04 | -0.5% | -5956 to +5571 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.085e+04 | 7.993e+04 | -1.1% | -1.937e+04 to +1.753e+04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.405e+04 | 8.311e+04 | -1.1% | -2.009e+04 to +1.821e+04 | GAIN, not beyond the noise |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 65.19 | 66.11 | +1.4% | -9.879 to +11.71 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.282e+04 | 9.285e+04 | +0.0% | -423.7 to +483.7 | STEADY, under the floor |
| power-capped share of samples | 0.9803 | 0.973 | -0.7% | -0.03129 to +0.01673 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.07 | 60.33 | +0.4% | -5.788 to +6.307 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.278e+04 | 9.283e+04 | +0.1% | -222.9 to +335.5 | STEADY, under the floor |
| energy per served request (J) | 16.65 | 16.58 | -0.4% | -1.75 to +1.604 | STEADY, under the floor |
| power, GPU mean (W) | 275.2 | 274.9 | -0.1% | -2.274 to +1.579 | STEADY, under the floor |
| requests served | 5573 | 5600 | +0.5% | -550.6 to +605.6 | STEADY, under the floor |
| requests not served | 1263 | 1236 | -2.2% | -605.6 to +550.6 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.235e+04 | 4.236e+04 | +0.0% | -9742 to +9760 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.085e+04 | 7.995e+04 | -1.1% | -2.492e+04 to +2.311e+04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.405e+04 | 8.314e+04 | -1.1% | -2.526e+04 to +2.344e+04 | GAIN, not beyond the noise |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 65.19 | 65.96 | +1.2% | -9.867 to +11.4 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.282e+04 | 9.288e+04 | +0.1% | +51.19 to +56.22 | STEADY, under the floor |
| power-capped share of samples | 0.9803 | 0.979 | -0.1% | -0.008439 to +0.005975 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.33 | 60.36 | +0.0% | -1.644 to +1.7 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.283e+04 | 9.278e+04 | -0.1% | -1042 to +939.3 | STEADY, under the floor |
| energy per served request (J) | 16.58 | 16.57 | -0.0% | -0.4665 to +0.4512 | STEADY, under the floor |
| power, GPU mean (W) | 274.9 | 274.8 | -0.0% | -0.5874 to +0.4231 | STEADY, under the floor |
| requests served | 5600 | 5600 | -0.0% | -95.79 to +94.79 | STEADY, under the floor |
| requests not served | 1236 | 1236 | +0.0% | -94.79 to +95.79 | STEADY, under the floor |
| response time, mean (ms) | 4.236e+04 | 4.216e+04 | -0.5% | -4188 to +3786 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.995e+04 | 7.993e+04 | -0.0% | -5588 to +5545 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.314e+04 | 8.311e+04 | -0.0% | -5224 to +5165 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 65.96 | 66.11 | +0.2% | -0.01246 to +0.3121 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.288e+04 | 9.285e+04 | -0.0% | -479.9 to +432.5 | STEADY, under the floor |
| power-capped share of samples | 0.979 | 0.973 | -0.6% | -0.02285 to +0.01076 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.07 -> 60.36 served requests per kJ, difference +0.2876 (95% interval -4.088 to +4.663).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*