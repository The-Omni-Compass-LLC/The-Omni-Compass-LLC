# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.31 | 41.46 | 41.57 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.195e+04 | 6.172e+04 | 6.156e+04 |
| energy per served request (J) | 24.21 | 24.12 | 24.06 |
| power, GPU mean (W) | 183.8 | 182.9 | 182.6 |
| requests served | 2559 | 2559 | 2559 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 112.9 | 115.4 | 114.8 |
| response time, 95th percentile (ms) | 359.3 | 381.3 | 374.6 |
| response time, 99th percentile (ms) | 621.7 | 656.4 | 658.3 |
| temperature, peak (C) | 62.5 | 62.5 | 62 |
| temperature, mean (C) | 51.94 | 52 | 51.98 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.217e+04 | 6.223e+04 | 6.192e+04 |
| power-capped share of samples | 0.6694 | 0.6695 | 0.6552 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.31 | 41.57 | +0.6% | -4.215 to +4.721 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.195e+04 | 6.156e+04 | -0.6% | -7108 to +6340 | GAIN, not beyond the noise |
| energy per served request (J) | 24.21 | 24.06 | -0.6% | -2.778 to +2.477 | GAIN, not beyond the noise |
| power, GPU mean (W) | 183.8 | 182.6 | -0.7% | -19.58 to +17.05 | GAIN, not beyond the noise |
| requests served | 2559 | 2559 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 112.9 | 114.8 | +1.7% | -26.61 to +30.33 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 359.3 | 374.6 | +4.3% | -188.3 to +218.9 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 621.7 | 658.3 | +5.9% | -395.6 to +468.8 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.5 | 62 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 51.94 | 51.98 | +0.1% | -1.556 to +1.631 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.217e+04 | 6.192e+04 | -0.4% | -1968 to +1455 | STEADY, under the floor |
| power-capped share of samples | 0.6694 | 0.6552 | -2.1% | -0.1499 to +0.1216 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.31 | 41.46 | +0.4% | -6.638 to +6.931 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.195e+04 | 6.172e+04 | -0.4% | -1.039e+04 to +9936 | STEADY, under the floor |
| energy per served request (J) | 24.21 | 24.12 | -0.4% | -4.059 to +3.883 | STEADY, under the floor |
| power, GPU mean (W) | 183.8 | 182.9 | -0.5% | -25.59 to +23.81 | STEADY, under the floor |
| requests served | 2559 | 2559 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 112.9 | 115.4 | +2.2% | -36.5 to +41.48 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 359.3 | 381.3 | +6.1% | -284.9 to +328.9 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 621.7 | 656.4 | +5.6% | -406.5 to +475.9 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.5 | 62.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 51.94 | 52 | +0.1% | -1.202 to +1.311 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.217e+04 | 6.223e+04 | +0.1% | -1193 to +1298 | STEADY, under the floor |
| power-capped share of samples | 0.6694 | 0.6695 | +0.0% | -0.0842 to +0.08438 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.46 | 41.57 | +0.3% | -2.209 to +2.423 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.172e+04 | 6.156e+04 | -0.3% | -3596 to +3280 | STEADY, under the floor |
| energy per served request (J) | 24.12 | 24.06 | -0.3% | -1.405 to +1.282 | STEADY, under the floor |
| power, GPU mean (W) | 182.9 | 182.6 | -0.2% | -6.755 to +6.014 | STEADY, under the floor |
| requests served | 2559 | 2559 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.4 | 114.8 | -0.5% | -11.15 to +9.897 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 381.3 | 374.6 | -1.8% | -110 to +96.58 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 656.4 | 658.3 | +0.3% | -7.061 to +10.9 | STEADY, under the floor |
| temperature, peak (C) | 62.5 | 62 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 52 | 51.98 | -0.0% | -0.3542 to +0.3197 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.223e+04 | 6.192e+04 | -0.5% | -774.8 to +156.9 | STEADY, under the floor |
| power-capped share of samples | 0.6695 | 0.6552 | -2.1% | -0.06574 to +0.03723 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.31 -> 41.57 served requests per kJ, difference +0.253 (95% interval -4.215 to +4.721).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 2 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 12.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*