# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.09 | 42.73 | 43.05 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.136e+04 | 6.188e+04 | 6.141e+04 |
| energy per served request (J) | 23.21 | 23.4 | 23.23 |
| power, GPU mean (W) | 181.9 | 183.6 | 182.2 |
| requests served | 2644 | 2644 | 2644 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 111.9 | 113.6 | 111.9 |
| response time, 95th percentile (ms) | 355.9 | 373.9 | 355.1 |
| response time, 99th percentile (ms) | 627.4 | 653.7 | 626.5 |
| temperature, peak (C) | 59 | 59 | 59 |
| temperature, mean (C) | 49.44 | 49.42 | 49.32 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.195e+04 | 6.198e+04 | 6.171e+04 |
| power-capped share of samples | 0.6835 | 0.6736 | 0.6597 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.09 | 43.05 | -0.1% | -2.341 to +2.263 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.136e+04 | 6.141e+04 | +0.1% | -3226 to +3337 | STEADY, under the floor |
| energy per served request (J) | 23.21 | 23.23 | +0.1% | -1.22 to +1.262 | STEADY, under the floor |
| power, GPU mean (W) | 181.9 | 182.2 | +0.1% | -10.51 to +10.93 | STEADY, under the floor |
| requests served | 2644 | 2644 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.9 | 111.9 | -0.0% | -2.697 to +2.685 | STEADY, under the floor |
| response time, 95th percentile (ms) | 355.9 | 355.1 | -0.2% | -20.11 to +18.47 | STEADY, under the floor |
| response time, 99th percentile (ms) | 627.4 | 626.5 | -0.1% | -43.64 to +41.91 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.44 | 49.32 | -0.2% | -0.7096 to +0.477 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.195e+04 | 6.171e+04 | -0.4% | -988 to +518.3 | STEADY, under the floor |
| power-capped share of samples | 0.6835 | 0.6597 | -3.5% | -0.1338 to +0.08614 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.09 | 42.73 | -0.8% | -2.953 to +2.225 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.136e+04 | 6.188e+04 | +0.9% | -3209 to +4256 | power given, not beyond the noise |
| energy per served request (J) | 23.21 | 23.4 | +0.9% | -1.214 to +1.61 | power given, not beyond the noise |
| power, GPU mean (W) | 181.9 | 183.6 | +0.9% | -9.461 to +12.7 | power given, not beyond the noise |
| requests served | 2644 | 2644 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.9 | 113.6 | +1.6% | -23.04 to +26.57 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 355.9 | 373.9 | +5.0% | -212.6 to +248.4 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 627.4 | 653.7 | +4.2% | -313.9 to +366.5 | LOSS, not beyond the noise |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.44 | 49.42 | -0.0% | -0.1971 to +0.1555 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.195e+04 | 6.198e+04 | +0.0% | -709 to +763.3 | STEADY, under the floor |
| power-capped share of samples | 0.6835 | 0.6736 | -1.5% | -0.1352 to +0.1153 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.73 | 43.05 | +0.8% | +0.03786 to +0.6127 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.188e+04 | 6.141e+04 | -0.8% | -918.2 to -17.16 | GAIN, clear of the noise |
| energy per served request (J) | 23.4 | 23.23 | -0.8% | -0.3473 to -0.00649 | GAIN, clear of the noise |
| power, GPU mean (W) | 183.6 | 182.2 | -0.8% | -1.772 to -1.044 | GAIN, clear of the noise |
| requests served | 2644 | 2644 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 113.6 | 111.9 | -1.6% | -29.26 to +25.73 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 373.9 | 355.1 | -5.0% | -230 to +192.5 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 653.7 | 626.5 | -4.2% | -324.6 to +270.2 | GAIN, not beyond the noise |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.42 | 49.32 | -0.2% | -0.5125 to +0.3215 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.198e+04 | 6.171e+04 | -0.4% | -1751 to +1227 | STEADY, under the floor |
| power-capped share of samples | 0.6736 | 0.6597 | -2.1% | -0.02919 to +0.001465 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.09 -> 43.05 served requests per kJ, difference -0.03878 (95% interval -2.341 to +2.263).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 2 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 16.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*