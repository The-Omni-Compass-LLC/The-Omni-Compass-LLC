# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.61 | 62.13 | 62.24 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.285e+04 | 9.285e+04 | 9.276e+04 |
| energy per served request (J) | 15.97 | 16.09 | 16.07 |
| power, GPU mean (W) | 274.8 | 275 | 274.7 |
| requests served | 5813 | 5769 | 5774 |
| requests not served | 1325 | 1369 | 1364 |
| response time, mean (ms) | 4.234e+04 | 4.297e+04 | 4.28e+04 |
| response time, 95th percentile (ms) | 8.05e+04 | 8.196e+04 | 8.175e+04 |
| response time, 99th percentile (ms) | 8.289e+04 | 8.491e+04 | 8.47e+04 |
| temperature, peak (C) | 63 | 63.5 | 63.5 |
| temperature, mean (C) | 60.69 | 61.17 | 61.18 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.287e+04 | 9.288e+04 | 9.283e+04 |
| power-capped share of samples | 0.9785 | 0.9794 | 0.9585 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.61 | 62.24 | -0.6% | -1.381 to +0.6441 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.285e+04 | 9.276e+04 | -0.1% | -514.7 to +345.2 | STEADY, under the floor |
| energy per served request (J) | 15.97 | 16.07 | +0.6% | -0.161 to +0.3501 | power given, not beyond the noise |
| power, GPU mean (W) | 274.8 | 274.7 | -0.0% | -7.211 to +7.048 | STEADY, under the floor |
| requests served | 5813 | 5774 | -0.7% | -160.2 to +81.21 | LOSS, not beyond the noise |
| requests not served | 1325 | 1364 | +3.0% | -81.21 to +160.2 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.234e+04 | 4.28e+04 | +1.1% | -4588 to +5505 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.05e+04 | 8.175e+04 | +1.6% | -1005 to +3510 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.289e+04 | 8.47e+04 | +2.2% | -3285 to +6919 | LOSS, not beyond the noise |
| temperature, peak (C) | 63 | 63.5 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 60.69 | 61.18 | +0.8% | -5.348 to +6.317 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.283e+04 | -0.0% | -710.5 to +632 | STEADY, under the floor |
| power-capped share of samples | 0.9785 | 0.9585 | -2.0% | -0.3033 to +0.2634 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.61 | 62.13 | -0.8% | -1.597 to +0.644 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.285e+04 | 9.285e+04 | +0.0% | -370 to +377.8 | STEADY, under the floor |
| energy per served request (J) | 15.97 | 16.09 | +0.8% | -0.1603 to +0.4051 | power given, not beyond the noise |
| power, GPU mean (W) | 274.8 | 275 | +0.1% | -9.437 to +9.792 | STEADY, under the floor |
| requests served | 5813 | 5769 | -0.8% | -171.1 to +83.06 | LOSS, not beyond the noise |
| requests not served | 1325 | 1369 | +3.3% | -83.06 to +171.1 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.234e+04 | 4.297e+04 | +1.5% | -2877 to +4132 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.05e+04 | 8.196e+04 | +1.8% | -1698 to +4618 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.289e+04 | 8.491e+04 | +2.4% | -3832 to +7874 | LOSS, not beyond the noise |
| temperature, peak (C) | 63 | 63.5 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 60.69 | 61.17 | +0.8% | -5.039 to +5.995 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.287e+04 | 9.288e+04 | +0.0% | -684 to +718.6 | STEADY, under the floor |
| power-capped share of samples | 0.9785 | 0.9794 | +0.1% | -0.02594 to +0.02768 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.13 | 62.24 | +0.2% | +8.235e-05 to +0.2157 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.285e+04 | 9.276e+04 | -0.1% | -144.7 to -32.58 | STEADY, under the floor |
| energy per served request (J) | 16.09 | 16.07 | -0.2% | -0.055 to -0.0007922 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 274.7 | -0.1% | -2.743 to +2.226 | STEADY, under the floor |
| requests served | 5769 | 5774 | +0.1% | -1.853 to +10.85 | STEADY, under the floor |
| requests not served | 1369 | 1364 | -0.3% | -10.85 to +1.853 | STEADY, under the floor |
| response time, mean (ms) | 4.297e+04 | 4.28e+04 | -0.4% | -1711 to +1373 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.196e+04 | 8.175e+04 | -0.3% | -1108 to +692.9 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.491e+04 | 8.47e+04 | -0.2% | -955.2 to +546.8 | STEADY, under the floor |
| temperature, peak (C) | 63.5 | 63.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 61.17 | 61.18 | +0.0% | -0.31 to +0.3227 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.288e+04 | 9.283e+04 | -0.1% | -86.63 to -26.56 | STEADY, under the floor |
| power-capped share of samples | 0.9794 | 0.9585 | -2.1% | -0.2774 to +0.2357 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.61 -> 62.24 served requests per kJ, difference -0.3686 (95% interval -1.381 to +0.6441).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*