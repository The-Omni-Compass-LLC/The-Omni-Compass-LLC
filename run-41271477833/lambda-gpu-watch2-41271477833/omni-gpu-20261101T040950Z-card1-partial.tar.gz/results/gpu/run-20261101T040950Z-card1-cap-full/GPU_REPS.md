# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.35 | 62.25 | 62.34 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.272e+04 | 9.269e+04 | 9.22e+04 |
| energy per served request (J) | 16.04 | 16.06 | 16.04 |
| power, GPU mean (W) | 275.8 | 276 | 274.6 |
| requests served | 5780 | 5770 | 5748 |
| requests not served | 1244 | 1254 | 1278 |
| response time, mean (ms) | 4.192e+04 | 4.211e+04 | 4.246e+04 |
| response time, 95th percentile (ms) | 7.879e+04 | 7.923e+04 | 7.997e+04 |
| response time, 99th percentile (ms) | 8.115e+04 | 8.163e+04 | 8.27e+04 |
| temperature, peak (C) | 61 | 61 | 61 |
| temperature, mean (C) | 59.34 | 58.94 | 59.27 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.283e+04 | 9.272e+04 | 9.22e+04 |
| power-capped share of samples | 0.9829 | 0.9833 | 0.56 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.35 | 62.34 | -0.0% | -0.617 to +0.6015 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.22e+04 | -0.6% | -6488 to +5459 | GAIN, not beyond the noise |
| energy per served request (J) | 16.04 | 16.04 | +0.0% | -0.1546 to +0.1582 | STEADY, under the floor |
| power, GPU mean (W) | 275.8 | 274.6 | -0.4% | -23.93 to +21.52 | STEADY, under the floor |
| requests served | 5780 | 5748 | -0.6% | -465 to +399 | LOSS, not beyond the noise |
| requests not served | 1244 | 1278 | +2.7% | -399 to +465 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.192e+04 | 4.246e+04 | +1.3% | -6585 to +7661 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.879e+04 | 7.997e+04 | +1.5% | -1.367e+04 to +1.602e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.115e+04 | 8.27e+04 | +1.9% | -1.804e+04 to +2.114e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.34 | 59.27 | -0.1% | -0.8047 to +0.6675 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.283e+04 | 9.22e+04 | -0.7% | -5437 to +4192 | GAIN, not beyond the noise |
| power-capped share of samples | 0.9829 | 0.56 | -43.0% | -5.819 to +4.973 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.35 | 62.25 | -0.1% | -1.575 to +1.391 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.269e+04 | -0.0% | -58.01 to +11.01 | STEADY, under the floor |
| energy per served request (J) | 16.04 | 16.06 | +0.1% | -0.3542 to +0.4008 | STEADY, under the floor |
| power, GPU mean (W) | 275.8 | 276 | +0.1% | -2.147 to +2.45 | STEADY, under the floor |
| requests served | 5780 | 5770 | -0.2% | -149.8 to +129.8 | STEADY, under the floor |
| requests not served | 1244 | 1254 | +0.8% | -129.8 to +149.8 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.192e+04 | 4.211e+04 | +0.5% | -6683 to +7073 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.879e+04 | 7.923e+04 | +0.6% | -5023 to +5900 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.115e+04 | 8.163e+04 | +0.6% | -5744 to +6712 | LOSS, not beyond the noise |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.34 | 58.94 | -0.7% | -5.552 to +4.756 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.283e+04 | 9.272e+04 | -0.1% | -1108 to +904.5 | STEADY, under the floor |
| power-capped share of samples | 0.9829 | 0.9833 | +0.0% | -0.003554 to +0.004184 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.25 | 62.34 | +0.1% | -0.7891 to +0.9577 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.269e+04 | 9.22e+04 | -0.5% | -6430 to +5448 | GAIN, not beyond the noise |
| energy per served request (J) | 16.06 | 16.04 | -0.1% | -0.2426 to +0.1997 | STEADY, under the floor |
| power, GPU mean (W) | 276 | 274.6 | -0.5% | -21.78 to +19.07 | STEADY, under the floor |
| requests served | 5770 | 5748 | -0.4% | -315.2 to +269.2 | STEADY, under the floor |
| requests not served | 1254 | 1278 | +1.8% | -269.2 to +315.2 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.211e+04 | 4.246e+04 | +0.8% | +98.2 to +588.2 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 7.923e+04 | 7.997e+04 | +0.9% | -8647 to +1.012e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.163e+04 | 8.27e+04 | +1.3% | -1.23e+04 to +1.443e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 58.94 | 59.27 | +0.6% | -5.561 to +6.219 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.272e+04 | 9.22e+04 | -0.6% | -6342 to +5300 | GAIN, not beyond the noise |
| power-capped share of samples | 0.9833 | 0.56 | -43.0% | -5.816 to +4.969 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.35 -> 62.34 served requests per kJ, difference -0.007732 (95% interval -0.617 to +0.6015).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 6.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*