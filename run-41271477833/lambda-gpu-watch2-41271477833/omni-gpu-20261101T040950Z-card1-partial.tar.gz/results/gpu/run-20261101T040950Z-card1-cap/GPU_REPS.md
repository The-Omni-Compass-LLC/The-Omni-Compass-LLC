# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.47 | 43.16 | 43.65 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.078e+04 | 6.122e+04 | 6.053e+04 |
| energy per served request (J) | 23 | 23.17 | 22.91 |
| power, GPU mean (W) | 179.5 | 181.7 | 180 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 111.6 | 111.7 | 111.9 |
| response time, 95th percentile (ms) | 362.4 | 361.2 | 361.2 |
| response time, 99th percentile (ms) | 638.8 | 636.4 | 636.2 |
| temperature, peak (C) | 57 | 57 | 57 |
| temperature, mean (C) | 47.86 | 47.87 | 47.89 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.164e+04 | 6.164e+04 | 6.144e+04 |
| power-capped share of samples | 0.6723 | 0.6718 | 0.66 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.47 | 43.65 | +0.4% | -6.209 to +6.57 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.078e+04 | 6.053e+04 | -0.4% | -9151 to +8647 | STEADY, under the floor |
| energy per served request (J) | 23 | 22.91 | -0.4% | -3.464 to +3.273 | STEADY, under the floor |
| power, GPU mean (W) | 179.5 | 180 | +0.3% | -14.91 to +15.94 | STEADY, under the floor |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.6 | 111.9 | +0.3% | -1.392 to +2.017 | STEADY, under the floor |
| response time, 95th percentile (ms) | 362.4 | 361.2 | -0.3% | -5.191 to +2.815 | STEADY, under the floor |
| response time, 99th percentile (ms) | 638.8 | 636.2 | -0.4% | -22.61 to +17.29 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.86 | 47.89 | +0.1% | -0.9502 to +1.021 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.164e+04 | 6.144e+04 | -0.3% | -2434 to +2036 | STEADY, under the floor |
| power-capped share of samples | 0.6723 | 0.66 | -1.8% | -0.1015 to +0.07688 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.47 | 43.16 | -0.7% | -1.594 to +0.9697 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.078e+04 | 6.122e+04 | +0.7% | -1310 to +2187 | power given, not beyond the noise |
| energy per served request (J) | 23 | 23.17 | +0.7% | -0.496 to +0.8276 | power given, not beyond the noise |
| power, GPU mean (W) | 179.5 | 181.7 | +1.3% | -8.948 to +13.44 | power given, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.6 | 111.7 | +0.1% | -2.153 to +2.271 | STEADY, under the floor |
| response time, 95th percentile (ms) | 362.4 | 361.2 | -0.3% | -22.42 to +19.95 | STEADY, under the floor |
| response time, 99th percentile (ms) | 638.8 | 636.4 | -0.4% | -22.72 to +17.82 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.86 | 47.87 | +0.0% | -0.3615 to +0.3896 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.164e+04 | 6.164e+04 | +0.0% | -2300 to +2306 | STEADY, under the floor |
| power-capped share of samples | 0.6723 | 0.6718 | -0.1% | -0.1269 to +0.1261 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.16 | 43.65 | +1.1% | -4.615 to +5.6 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.122e+04 | 6.053e+04 | -1.1% | -7841 to +6460 | GAIN, not beyond the noise |
| energy per served request (J) | 23.17 | 22.91 | -1.1% | -2.968 to +2.445 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.7 | 180 | -1.0% | -28.35 to +24.89 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.7 | 111.9 | +0.2% | -3.663 to +4.17 | STEADY, under the floor |
| response time, 95th percentile (ms) | 361.2 | 361.2 | +0.0% | -25.14 to +25.24 | STEADY, under the floor |
| response time, 99th percentile (ms) | 636.4 | 636.2 | -0.0% | -40.43 to +40.01 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.87 | 47.89 | +0.0% | -0.5887 to +0.6317 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.164e+04 | 6.144e+04 | -0.3% | -270.7 to -133.8 | STEADY, under the floor |
| power-capped share of samples | 0.6718 | 0.66 | -1.8% | -0.2275 to +0.2038 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.47 -> 43.65 served requests per kJ, difference +0.1807 (95% interval -6.209 to +6.57).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 14.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*