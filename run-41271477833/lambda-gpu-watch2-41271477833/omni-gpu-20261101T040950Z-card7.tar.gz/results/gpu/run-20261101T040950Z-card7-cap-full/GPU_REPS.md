# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.05 | 60.23 | 60.09 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.272e+04 | 9.279e+04 | 9.262e+04 |
| energy per served request (J) | 16.65 | 16.6 | 16.64 |
| power, GPU mean (W) | 276.2 | 276.3 | 276.2 |
| requests served | 5568 | 5588 | 5566 |
| requests not served | 1348 | 1328 | 1351 |
| response time, mean (ms) | 4.399e+04 | 4.342e+04 | 4.408e+04 |
| response time, 95th percentile (ms) | 8.399e+04 | 8.325e+04 | 8.412e+04 |
| response time, 99th percentile (ms) | 8.737e+04 | 8.663e+04 | 8.744e+04 |
| temperature, peak (C) | 71 | 71 | 71 |
| temperature, mean (C) | 68.07 | 67.27 | 68.06 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.285e+04 | 9.282e+04 | 9.267e+04 |
| power-capped share of samples | 0.9841 | 0.9836 | 0.9765 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.05 | 60.09 | +0.1% | -0.9819 to +1.059 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.262e+04 | -0.1% | -537.1 to +335.5 | STEADY, under the floor |
| energy per served request (J) | 16.65 | 16.64 | -0.1% | -0.2932 to +0.272 | STEADY, under the floor |
| power, GPU mean (W) | 276.2 | 276.2 | +0.0% | -2.666 to +2.696 | STEADY, under the floor |
| requests served | 5568 | 5566 | -0.0% | -123.2 to +118.2 | STEADY, under the floor |
| requests not served | 1348 | 1351 | +0.2% | -118.2 to +123.2 | STEADY, under the floor |
| response time, mean (ms) | 4.399e+04 | 4.408e+04 | +0.2% | -3405 to +3587 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.399e+04 | 8.412e+04 | +0.2% | -5466 to +5738 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.737e+04 | 8.744e+04 | +0.1% | -4684 to +4816 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.07 | 68.06 | -0.0% | -0.7351 to +0.7139 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.285e+04 | 9.267e+04 | -0.2% | -1254 to +887 | STEADY, under the floor |
| power-capped share of samples | 0.9841 | 0.9765 | -0.8% | -0.1129 to +0.09757 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.05 | 60.23 | +0.3% | -1.654 to +1.999 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.272e+04 | 9.279e+04 | +0.1% | -707.5 to +841.5 | STEADY, under the floor |
| energy per served request (J) | 16.65 | 16.6 | -0.3% | -0.5511 to +0.4561 | STEADY, under the floor |
| power, GPU mean (W) | 276.2 | 276.3 | +0.0% | -3.417 to +3.591 | STEADY, under the floor |
| requests served | 5568 | 5588 | +0.4% | -196 to +236 | STEADY, under the floor |
| requests not served | 1348 | 1328 | -1.5% | -236 to +196 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.399e+04 | 4.342e+04 | -1.3% | -7608 to +6470 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.399e+04 | 8.325e+04 | -0.9% | -9159 to +7684 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.737e+04 | 8.663e+04 | -0.8% | -9195 to +7726 | GAIN, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.07 | 67.27 | -1.2% | -11.84 to +10.22 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.285e+04 | 9.282e+04 | -0.0% | -634 to +576.5 | STEADY, under the floor |
| power-capped share of samples | 0.9841 | 0.9836 | -0.1% | -0.03124 to +0.03006 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.23 | 60.09 | -0.2% | -0.9398 to +0.6723 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.279e+04 | 9.262e+04 | -0.2% | -506 to +170.3 | STEADY, under the floor |
| energy per served request (J) | 16.6 | 16.64 | +0.2% | -0.1842 to +0.258 | STEADY, under the floor |
| power, GPU mean (W) | 276.3 | 276.2 | -0.0% | -6.257 to +6.113 | STEADY, under the floor |
| requests served | 5588 | 5566 | -0.4% | -117.8 to +72.79 | STEADY, under the floor |
| requests not served | 1328 | 1351 | +1.7% | -72.79 to +117.8 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.342e+04 | 4.408e+04 | +1.5% | -2883 to +4203 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.325e+04 | 8.412e+04 | +1.0% | -1946 to +3693 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.663e+04 | 8.744e+04 | +0.9% | -2910 to +4511 | LOSS, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 67.27 | 68.06 | +1.2% | -9.51 to +11.1 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.282e+04 | 9.267e+04 | -0.2% | -1830 to +1521 | STEADY, under the floor |
| power-capped share of samples | 0.9836 | 0.9765 | -0.7% | -0.0817 to +0.06751 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.05 -> 60.09 served requests per kJ, difference +0.0384 (95% interval -0.9819 to +1.059).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 6.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*