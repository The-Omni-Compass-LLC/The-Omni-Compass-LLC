# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.15 | 41.87 | 42.93 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.128e+04 | 6.169e+04 | 6.017e+04 |
| energy per served request (J) | 23.72 | 23.88 | 23.29 |
| power, GPU mean (W) | 182.6 | 182.8 | 179.8 |
| requests served | 2583 | 2583 | 2583 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 115.2 | 115.6 | 116 |
| response time, 95th percentile (ms) | 383.3 | 386.8 | 385.5 |
| response time, 99th percentile (ms) | 658.1 | 660.3 | 660.4 |
| temperature, peak (C) | 64.5 | 64 | 63.5 |
| temperature, mean (C) | 53.62 | 53.6 | 53.66 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.15e+04 | 6.159e+04 | 6.11e+04 |
| power-capped share of samples | 0.6661 | 0.6672 | 0.6414 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.15 | 42.93 | +1.8% | +0.6805 to +0.8724 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.128e+04 | 6.017e+04 | -1.8% | -1192 to -1025 | GAIN, clear of the noise |
| energy per served request (J) | 23.72 | 23.29 | -1.8% | -0.4614 to -0.3968 | GAIN, clear of the noise |
| power, GPU mean (W) | 182.6 | 179.8 | -1.5% | -6.171 to +0.616 | GAIN, not beyond the noise |
| requests served | 2583 | 2583 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.2 | 116 | +0.7% | -3.259 to +4.819 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 383.3 | 385.5 | +0.6% | -17.55 to +21.94 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 658.1 | 660.4 | +0.3% | -27.86 to +32.43 | STEADY, under the floor |
| temperature, peak (C) | 64.5 | 63.5 | -1.6% | -1 to -1 | GAIN, clear of the noise |
| temperature, mean (C) | 53.62 | 53.66 | +0.1% | -0.2663 to +0.3313 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.15e+04 | 6.11e+04 | -0.7% | -783.7 to -24.59 | GAIN, clear of the noise |
| power-capped share of samples | 0.6661 | 0.6414 | -3.7% | -0.158 to +0.1087 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.15 | 41.87 | -0.7% | -3.976 to +3.416 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.128e+04 | 6.169e+04 | +0.7% | -5015 to +5837 | power given, not beyond the noise |
| energy per served request (J) | 23.72 | 23.88 | +0.7% | -1.942 to +2.26 | power given, not beyond the noise |
| power, GPU mean (W) | 182.6 | 182.8 | +0.1% | -7.369 to +7.811 | STEADY, under the floor |
| requests served | 2583 | 2583 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.2 | 115.6 | +0.3% | -12.77 to +13.48 | STEADY, under the floor |
| response time, 95th percentile (ms) | 383.3 | 386.8 | +0.9% | -28.34 to +35.39 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 658.1 | 660.3 | +0.3% | -17.17 to +21.58 | STEADY, under the floor |
| temperature, peak (C) | 64.5 | 64 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 53.62 | 53.6 | -0.0% | -0.2913 to +0.2386 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.15e+04 | 6.159e+04 | +0.1% | -710.1 to +882.1 | STEADY, under the floor |
| power-capped share of samples | 0.6661 | 0.6672 | +0.2% | -0.02132 to +0.0236 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.87 | 42.93 | +2.5% | -2.736 to +4.848 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.169e+04 | 6.017e+04 | -2.5% | -7028 to +3990 | GAIN, not beyond the noise |
| energy per served request (J) | 23.88 | 23.29 | -2.5% | -2.721 to +1.545 | GAIN, not beyond the noise |
| power, GPU mean (W) | 182.8 | 179.8 | -1.6% | -7.195 to +1.197 | GAIN, not beyond the noise |
| requests served | 2583 | 2583 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.6 | 116 | +0.4% | -8.657 to +9.509 | STEADY, under the floor |
| response time, 95th percentile (ms) | 386.8 | 385.5 | -0.3% | -13.45 to +10.79 | STEADY, under the floor |
| response time, 99th percentile (ms) | 660.3 | 660.4 | +0.0% | -49.44 to +49.6 | STEADY, under the floor |
| temperature, peak (C) | 64 | 63.5 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 53.6 | 53.66 | +0.1% | +0.02502 to +0.09268 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.159e+04 | 6.11e+04 | -0.8% | -1666 to +685.5 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6672 | 0.6414 | -3.9% | -0.1367 to +0.08514 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.15 -> 42.93 served requests per kJ, difference +0.7765 (95% interval +0.6805 to +0.8724).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: GAIN (within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*