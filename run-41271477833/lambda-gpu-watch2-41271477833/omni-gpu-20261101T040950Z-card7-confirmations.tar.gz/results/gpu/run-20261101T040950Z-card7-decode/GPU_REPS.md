# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.44 | 45.27 | 45.44 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.268e+05 | 1.273e+05 | 1.269e+05 |
| energy per served request (J) | 22.01 | 22.09 | 22.01 |
| power, GPU mean (W) | 199.7 | 200.6 | 199.7 |
| requests served | 5764 | 5764 | 5764 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.65 | 96.72 | 96.68 |
| response time, 95th percentile (ms) | 267.2 | 267.5 | 267.5 |
| response time, 99th percentile (ms) | 455 | 455.9 | 455.6 |
| temperature, peak (C) | 70 | 70 | 70 |
| temperature, mean (C) | 55.18 | 55.27 | 55.18 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.274e+05 | 1.273e+05 | 1.271e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.44 | 45.44 | -0.0% | -0.1671 to +0.1561 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.268e+05 | 1.269e+05 | +0.0% | -433.9 to +462.3 | STEADY, under the floor |
| energy per served request (J) | 22.01 | 22.01 | +0.0% | -0.07528 to +0.0802 | STEADY, under the floor |
| power, GPU mean (W) | 199.7 | 199.7 | +0.0% | -0.8964 to +0.9788 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.65 | 96.68 | +0.0% | -0.6409 to +0.7003 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.2 | 267.5 | +0.1% | -2.076 to +2.788 | STEADY, under the floor |
| response time, 99th percentile (ms) | 455 | 455.6 | +0.1% | -6.134 to +7.172 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.18 | 55.18 | -0.0% | -0.1531 to +0.1433 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.274e+05 | 1.271e+05 | -0.2% | -1037 to +589 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.44 | 45.27 | -0.4% | -0.48 to +0.1329 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.268e+05 | 1.273e+05 | +0.4% | -375.6 to +1347 | STEADY, under the floor |
| energy per served request (J) | 22.01 | 22.09 | +0.4% | -0.06516 to +0.2337 | STEADY, under the floor |
| power, GPU mean (W) | 199.7 | 200.6 | +0.4% | -0.2826 to +2.022 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.65 | 96.72 | +0.1% | -0.1717 to +0.3092 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.2 | 267.5 | +0.1% | -0.3702 to +0.9861 | STEADY, under the floor |
| response time, 99th percentile (ms) | 455 | 455.9 | +0.2% | -1.315 to +3.094 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.18 | 55.27 | +0.2% | -0.1908 to +0.3597 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.274e+05 | 1.273e+05 | -0.0% | -695.4 to +591.8 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.27 | 45.44 | +0.4% | -0.1806 to +0.5166 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.273e+05 | 1.269e+05 | -0.4% | -1458 to +514.5 | STEADY, under the floor |
| energy per served request (J) | 22.09 | 22.01 | -0.4% | -0.2529 to +0.08927 | STEADY, under the floor |
| power, GPU mean (W) | 200.6 | 199.7 | -0.4% | -2.334 to +0.677 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.72 | 96.68 | -0.0% | -0.8182 to +0.7402 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.5 | 267.5 | +0.0% | -2.289 to +2.385 | STEADY, under the floor |
| response time, 99th percentile (ms) | 455.9 | 455.6 | -0.1% | -8.599 to +7.859 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.27 | 55.18 | -0.2% | -0.4997 to +0.321 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.271e+05 | -0.1% | -623.6 to +279.4 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.44 -> 45.44 served requests per kJ, difference -0.005519 (95% interval -0.1671 to +0.1561).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.203 | 0.272 | 0 | 450 | 27 | True |
| omni | 2 | 32 | 0 | 0 | 0 | 0.218 | 0.316 | 0 | 402 | 31 | True |
| omni | 3 | 34 | 0 | 0 | 0 | 0.211 | 0.316 | 0 | 450 | 33 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 2 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 68 | -52.28 | +0 |
| compass | 47 | 970 | -543.7 | +90 |
| fail_up | 1 | 2 | +7.588 | -1 |
| race | 43 | 168 | -1116 | -111 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 94.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*