# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.1 | 39.1 | 38.98 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.578e+05 | 1.578e+05 | 1.583e+05 |
| energy per served request (J) | 25.58 | 25.58 | 25.65 |
| power, GPU mean (W) | 248.7 | 248.6 | 249.4 |
| requests served | 6171 | 6171 | 6171 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 91.06 | 91.19 | 91.11 |
| response time, 95th percentile (ms) | 259.7 | 260.6 | 260.6 |
| response time, 99th percentile (ms) | 463.2 | 463.3 | 463.2 |
| temperature, peak (C) | 78.33 | 78 | 78 |
| temperature, mean (C) | 63.68 | 63.72 | 63.65 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.578e+05 | 1.578e+05 | 1.579e+05 |
| power-capped share of samples | 0.7369 | 0.7396 | 0.7389 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.1 | 38.98 | -0.3% | -0.9911 to +0.7481 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.578e+05 | 1.583e+05 | +0.3% | -3005 to +3969 | STEADY, under the floor |
| energy per served request (J) | 25.58 | 25.65 | +0.3% | -0.4869 to +0.6432 | STEADY, under the floor |
| power, GPU mean (W) | 248.7 | 249.4 | +0.3% | -4.66 to +6.172 | STEADY, under the floor |
| requests served | 6171 | 6171 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.06 | 91.11 | +0.1% | -0.3709 to +0.4777 | STEADY, under the floor |
| response time, 95th percentile (ms) | 259.7 | 260.6 | +0.3% | -2.2 to +3.973 | STEADY, under the floor |
| response time, 99th percentile (ms) | 463.2 | 463.2 | -0.0% | -4.473 to +4.458 | STEADY, under the floor |
| temperature, peak (C) | 78.33 | 78 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 63.68 | 63.65 | -0.1% | -0.2552 to +0.181 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.578e+05 | 1.579e+05 | +0.1% | -285.8 to +483.5 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7389 | +0.3% | -0.03033 to +0.03431 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.1 | 39.1 | +0.0% | -0.6489 to +0.6517 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.578e+05 | 1.578e+05 | +0.0% | -2574 to +2599 | STEADY, under the floor |
| energy per served request (J) | 25.58 | 25.58 | +0.0% | -0.4171 to +0.4212 | STEADY, under the floor |
| power, GPU mean (W) | 248.7 | 248.6 | -0.0% | -3.909 to +3.686 | STEADY, under the floor |
| requests served | 6171 | 6171 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.06 | 91.19 | +0.1% | -0.2435 to +0.5058 | STEADY, under the floor |
| response time, 95th percentile (ms) | 259.7 | 260.6 | +0.4% | -3.839 to +5.69 | STEADY, under the floor |
| response time, 99th percentile (ms) | 463.2 | 463.3 | +0.0% | -3.848 to +3.914 | STEADY, under the floor |
| temperature, peak (C) | 78.33 | 78 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 63.68 | 63.72 | +0.1% | -0.2458 to +0.3268 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.578e+05 | 1.578e+05 | +0.0% | -132.4 to +248.4 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7396 | +0.4% | -0.01734 to +0.02278 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.1 | 38.98 | -0.3% | -1.639 to +1.394 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.578e+05 | 1.583e+05 | +0.3% | -5589 to +6529 | STEADY, under the floor |
| energy per served request (J) | 25.58 | 25.65 | +0.3% | -0.9058 to +1.058 | STEADY, under the floor |
| power, GPU mean (W) | 248.6 | 249.4 | +0.3% | -8.291 to +10.03 | STEADY, under the floor |
| requests served | 6171 | 6171 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.19 | 91.11 | -0.1% | -0.1341 to -0.0214 | STEADY, under the floor |
| response time, 95th percentile (ms) | 260.6 | 260.6 | -0.0% | -1.764 to +1.685 | STEADY, under the floor |
| response time, 99th percentile (ms) | 463.3 | 463.2 | -0.0% | -5.482 to +5.401 | STEADY, under the floor |
| temperature, peak (C) | 78 | 78 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 63.72 | 63.65 | -0.1% | -0.1459 to -0.009328 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.578e+05 | 1.579e+05 | +0.0% | -287.5 to +369.2 | STEADY, under the floor |
| power-capped share of samples | 0.7396 | 0.7389 | -0.1% | -0.01301 to +0.01156 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.1 -> 38.98 served requests per kJ, difference -0.1215 (95% interval -0.9911 to +0.7481).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 3 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*