# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 46.37 | 46.71 | 46.45 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.242e+05 | 1.233e+05 | 1.24e+05 |
| energy per served request (J) | 21.57 | 21.41 | 21.53 |
| power, GPU mean (W) | 195.5 | 193.9 | 195.5 |
| requests served | 5760 | 5760 | 5760 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.49 | 96.6 | 96.67 |
| response time, 95th percentile (ms) | 266.4 | 267 | 267.4 |
| response time, 99th percentile (ms) | 452.3 | 453.1 | 453.4 |
| temperature, peak (C) | 61 | 61 | 61 |
| temperature, mean (C) | 49.29 | 49.25 | 49.29 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.234e+05 | 1.235e+05 | 1.234e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.37 | 46.45 | +0.2% | -0.6556 to +0.8168 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.242e+05 | 1.24e+05 | -0.2% | -2174 to +1752 | STEADY, under the floor |
| energy per served request (J) | 21.57 | 21.53 | -0.2% | -0.3773 to +0.3042 | STEADY, under the floor |
| power, GPU mean (W) | 195.5 | 195.5 | -0.0% | -2.908 to +2.787 | STEADY, under the floor |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.49 | 96.67 | +0.2% | -0.2963 to +0.6521 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.4 | 267.4 | +0.4% | -1.621 to +3.759 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.3 | 453.4 | +0.2% | -2.151 to +4.357 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.29 | 49.29 | +0.0% | -0.04066 to +0.0477 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.234e+05 | 1.234e+05 | -0.1% | -527.8 to +383.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.37 | 46.71 | +0.7% | -1.134 to +1.819 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.242e+05 | 1.233e+05 | -0.7% | -4815 to +3019 | GAIN, not beyond the noise |
| energy per served request (J) | 21.57 | 21.41 | -0.7% | -0.836 to +0.5241 | GAIN, not beyond the noise |
| power, GPU mean (W) | 195.5 | 193.9 | -0.9% | -6.607 to +3.267 | GAIN, not beyond the noise |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.49 | 96.6 | +0.1% | -0.5883 to +0.8192 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.4 | 267 | +0.2% | -3.188 to +4.396 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.3 | 453.1 | +0.2% | -5.829 to +7.311 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.29 | 49.25 | -0.1% | -0.2028 to +0.119 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.234e+05 | 1.235e+05 | +0.0% | -889.2 to +943.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 46.71 | 46.45 | -0.6% | -2.396 to +1.873 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.233e+05 | 1.24e+05 | +0.6% | -4987 to +6362 | power given, not beyond the noise |
| energy per served request (J) | 21.41 | 21.53 | +0.6% | -0.8658 to +1.105 | power given, not beyond the noise |
| power, GPU mean (W) | 193.9 | 195.5 | +0.8% | -5.822 to +9.041 | power given, not beyond the noise |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.6 | 96.67 | +0.1% | -0.256 to +0.3809 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267 | 267.4 | +0.2% | -1.859 to +2.788 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.1 | 453.4 | +0.1% | -2.985 to +3.71 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.25 | 49.29 | +0.1% | -0.07674 to +0.1677 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.235e+05 | 1.234e+05 | -0.1% | -1347 to +1149 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 46.37 -> 46.45 served requests per kJ, difference +0.08058 (95% interval -0.6556 to +0.8168).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 34 | 0 | 0 | 0 | 0.212 | 0.321 | 0 | 1.14e+03 | 33 | True |
| omni | 2 | 32 | 0 | 0 | 0 | 0.224 | 0.453 | 0 | 1.08e+03 | 31 | True |
| omni | 3 | 24 | 0 | 0 | 0 | 0.215 | 0.281 | 0 | 790 | 23 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 63 | -183 | +0 |
| compass | 45 | 996 | +2.116 | +149 |
| fail_up | 2 | 12 | +5.525 | -11 |
| race | 40 | 143 | -268.1 | -173 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 90.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*