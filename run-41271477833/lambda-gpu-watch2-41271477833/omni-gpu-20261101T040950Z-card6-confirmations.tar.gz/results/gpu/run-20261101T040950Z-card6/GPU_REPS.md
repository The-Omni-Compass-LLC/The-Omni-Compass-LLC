# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.55 | 40.02 | 40.21 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.555e+05 | 1.575e+05 | 1.568e+05 |
| energy per served request (J) | 24.66 | 24.99 | 24.87 |
| power, GPU mean (W) | 245 | 248.3 | 247.2 |
| requests served | 6305 | 6305 | 6305 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 86.76 | 86.85 | 86.73 |
| response time, 95th percentile (ms) | 243.5 | 243.1 | 243.1 |
| response time, 99th percentile (ms) | 436.2 | 437.1 | 435.5 |
| temperature, peak (C) | 70.33 | 70.33 | 70 |
| temperature, mean (C) | 57.05 | 57 | 57.06 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.564e+05 | 1.565e+05 | 1.563e+05 |
| power-capped share of samples | 0.7406 | 0.7357 | 0.7323 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.55 | 40.21 | -0.8% | -0.5838 to -0.1018 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.555e+05 | 1.568e+05 | +0.9% | +370.1 to +2285 | power given, clear of the noise |
| energy per served request (J) | 24.66 | 24.87 | +0.9% | +0.05869 to +0.3625 | power given, clear of the noise |
| power, GPU mean (W) | 245 | 247.2 | +0.9% | +0.7631 to +3.626 | power given, clear of the noise |
| requests served | 6305 | 6305 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 86.76 | 86.73 | -0.0% | -0.3059 to +0.2517 | STEADY, under the floor |
| response time, 95th percentile (ms) | 243.5 | 243.1 | -0.2% | -3.255 to +2.383 | STEADY, under the floor |
| response time, 99th percentile (ms) | 436.2 | 435.5 | -0.2% | -3.958 to +2.492 | STEADY, under the floor |
| temperature, peak (C) | 70.33 | 70 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 57.05 | 57.06 | +0.0% | -0.2923 to +0.295 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.564e+05 | 1.563e+05 | -0.1% | -938.3 to +669.7 | STEADY, under the floor |
| power-capped share of samples | 0.7406 | 0.7323 | -1.1% | -0.03478 to +0.01811 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.55 | 40.02 | -1.3% | -1.133 to +0.06764 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.555e+05 | 1.575e+05 | +1.3% | -266.1 to +4405 | power given, not beyond the noise |
| energy per served request (J) | 24.66 | 24.99 | +1.3% | -0.04221 to +0.6987 | power given, not beyond the noise |
| power, GPU mean (W) | 245 | 248.3 | +1.4% | -0.3192 to +6.944 | power given, not beyond the noise |
| requests served | 6305 | 6305 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 86.76 | 86.85 | +0.1% | -0.1859 to +0.3809 | STEADY, under the floor |
| response time, 95th percentile (ms) | 243.5 | 243.1 | -0.2% | -3.245 to +2.418 | STEADY, under the floor |
| response time, 99th percentile (ms) | 436.2 | 437.1 | +0.2% | -3.344 to +5.183 | STEADY, under the floor |
| temperature, peak (C) | 70.33 | 70.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 57.05 | 57 | -0.1% | -0.06352 to -0.04638 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.564e+05 | 1.565e+05 | +0.0% | -282.8 to +430.4 | STEADY, under the floor |
| power-capped share of samples | 0.7406 | 0.7357 | -0.7% | -0.01788 to +0.007939 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.02 | 40.21 | +0.5% | -0.3321 to +0.7116 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.575e+05 | 1.568e+05 | -0.5% | -2792 to +1308 | STEADY, under the floor |
| energy per served request (J) | 24.99 | 24.87 | -0.5% | -0.4428 to +0.2075 | STEADY, under the floor |
| power, GPU mean (W) | 248.3 | 247.2 | -0.5% | -4.429 to +2.194 | STEADY, under the floor |
| requests served | 6305 | 6305 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 86.85 | 86.73 | -0.1% | -0.505 to +0.2559 | STEADY, under the floor |
| response time, 95th percentile (ms) | 243.1 | 243.1 | -0.0% | -0.3511 to +0.3059 | STEADY, under the floor |
| response time, 99th percentile (ms) | 437.1 | 435.5 | -0.4% | -4.59 to +1.285 | STEADY, under the floor |
| temperature, peak (C) | 70.33 | 70 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 57 | 57.06 | +0.1% | -0.2343 to +0.3469 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.565e+05 | 1.563e+05 | -0.1% | -701.1 to +285 | STEADY, under the floor |
| power-capped share of samples | 0.7357 | 0.7323 | -0.5% | -0.01692 to +0.01019 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.55 -> 40.21 served requests per kJ, difference -0.3428 (95% interval -0.5838 to -0.1018).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: LOSS.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| omni | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 1 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |
| watch | 2 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| watch | 3 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*