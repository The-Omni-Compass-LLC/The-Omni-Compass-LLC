# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 59.66 | 59.67 | 59.91 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.308e+04 | 9.304e+04 | 9.296e+04 |
| energy per served request (J) | 16.76 | 16.76 | 16.69 |
| power, GPU mean (W) | 274.3 | 274.7 | 275.8 |
| requests served | 5554 | 5552 | 5570 |
| requests not served | 1434 | 1436 | 1418 |
| response time, mean (ms) | 4.508e+04 | 4.509e+04 | 4.468e+04 |
| response time, 95th percentile (ms) | 8.642e+04 | 8.645e+04 | 8.586e+04 |
| response time, 99th percentile (ms) | 8.983e+04 | 8.987e+04 | 8.931e+04 |
| temperature, peak (C) | 64 | 64 | 63.5 |
| temperature, mean (C) | 61.18 | 61.24 | 60.72 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.315e+04 | 9.311e+04 | 9.305e+04 |
| power-capped share of samples | 0.9749 | 0.9761 | 0.9638 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.66 | 59.91 | +0.4% | -3.275 to +3.774 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.308e+04 | 9.296e+04 | -0.1% | -2835 to +2596 | STEADY, under the floor |
| energy per served request (J) | 16.76 | 16.69 | -0.4% | -1.052 to +0.9128 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 275.8 | +0.5% | -14.62 to +17.57 | power given, not beyond the noise |
| requests served | 5554 | 5570 | +0.3% | -149.2 to +181.2 | STEADY, under the floor |
| requests not served | 1434 | 1418 | -1.1% | -181.2 to +149.2 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.508e+04 | 4.468e+04 | -0.9% | -5456 to +4649 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.642e+04 | 8.586e+04 | -0.6% | -7148 to +6037 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.983e+04 | 8.931e+04 | -0.6% | -7018 to +5988 | GAIN, not beyond the noise |
| temperature, peak (C) | 64 | 63.5 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 61.18 | 60.72 | -0.8% | -4.746 to +3.828 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.315e+04 | 9.305e+04 | -0.1% | -1019 to +802.6 | STEADY, under the floor |
| power-capped share of samples | 0.9749 | 0.9638 | -1.1% | -0.1519 to +0.1297 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.66 | 59.67 | +0.0% | -0.2542 to +0.274 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.308e+04 | 9.304e+04 | -0.0% | -587.3 to +506 | STEADY, under the floor |
| energy per served request (J) | 16.76 | 16.76 | -0.0% | -0.07693 to +0.07136 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.7 | +0.1% | -1.013 to +1.651 | STEADY, under the floor |
| requests served | 5554 | 5552 | -0.0% | -58.68 to +55.68 | STEADY, under the floor |
| requests not served | 1434 | 1436 | +0.1% | -55.68 to +58.68 | STEADY, under the floor |
| response time, mean (ms) | 4.508e+04 | 4.509e+04 | +0.0% | -716.5 to +740.8 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.642e+04 | 8.645e+04 | +0.0% | -1375 to +1443 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.983e+04 | 8.987e+04 | +0.0% | -1109 to +1194 | STEADY, under the floor |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 61.18 | 61.24 | +0.1% | -0.3858 to +0.494 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.315e+04 | 9.311e+04 | -0.0% | -231.3 to +147.3 | STEADY, under the floor |
| power-capped share of samples | 0.9749 | 0.9761 | +0.1% | -0.005942 to +0.008338 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.67 | 59.91 | +0.4% | -3.549 to +4.028 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.304e+04 | 9.296e+04 | -0.1% | -2248 to +2090 | STEADY, under the floor |
| energy per served request (J) | 16.76 | 16.69 | -0.4% | -1.123 to +0.9898 | STEADY, under the floor |
| power, GPU mean (W) | 274.7 | 275.8 | +0.4% | -16.27 to +18.58 | STEADY, under the floor |
| requests served | 5552 | 5570 | +0.3% | -204.9 to +239.9 | STEADY, under the floor |
| requests not served | 1436 | 1418 | -1.2% | -239.9 to +204.9 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.509e+04 | 4.468e+04 | -0.9% | -6196 to +5366 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.645e+04 | 8.586e+04 | -0.7% | -8592 to +7413 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.987e+04 | 8.931e+04 | -0.6% | -8212 to +7097 | GAIN, not beyond the noise |
| temperature, peak (C) | 64 | 63.5 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 61.24 | 60.72 | -0.8% | -5.24 to +4.214 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.311e+04 | 9.305e+04 | -0.1% | -787.6 to +655.3 | STEADY, under the floor |
| power-capped share of samples | 0.9761 | 0.9638 | -1.3% | -0.1459 to +0.1213 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 59.66 -> 59.91 served requests per kJ, difference +0.2494 (95% interval -3.275 to +3.774).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*