# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.88 | 41.56 | 41.6 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.152e+04 | 6.196e+04 | 6.191e+04 |
| energy per served request (J) | 23.89 | 24.06 | 24.04 |
| power, GPU mean (W) | 182.4 | 183.5 | 183.4 |
| requests served | 2575 | 2575 | 2575 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 120.8 | 122.4 | 121.7 |
| response time, 95th percentile (ms) | 416.3 | 431.6 | 419.5 |
| response time, 99th percentile (ms) | 706.7 | 709.9 | 706 |
| temperature, peak (C) | 59.5 | 59.5 | 59 |
| temperature, mean (C) | 49.3 | 49.36 | 49.14 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.25e+04 | 6.242e+04 | 6.205e+04 |
| power-capped share of samples | 0.6632 | 0.6739 | 0.6288 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.88 | 41.6 | -0.7% | -9.903 to +9.343 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.152e+04 | 6.191e+04 | +0.6% | -1.371e+04 to +1.447e+04 | power given, not beyond the noise |
| energy per served request (J) | 23.89 | 24.04 | +0.6% | -5.323 to +5.621 | power given, not beyond the noise |
| power, GPU mean (W) | 182.4 | 183.4 | +0.6% | -41.26 to +43.3 | power given, not beyond the noise |
| requests served | 2575 | 2575 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 120.8 | 121.7 | +0.8% | -8.943 to +10.78 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 416.3 | 419.5 | +0.8% | -64.64 to +71.05 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 706.7 | 706 | -0.1% | -61.85 to +60.33 | STEADY, under the floor |
| temperature, peak (C) | 59.5 | 59 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 49.3 | 49.14 | -0.3% | -1.369 to +1.063 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.25e+04 | 6.205e+04 | -0.7% | -3169 to +2276 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6632 | 0.6288 | -5.2% | -0.1529 to +0.08413 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.88 | 41.56 | -0.8% | -10.68 to +10.04 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.152e+04 | 6.196e+04 | +0.7% | -1.475e+04 to +1.562e+04 | power given, not beyond the noise |
| energy per served request (J) | 23.89 | 24.06 | +0.7% | -5.726 to +6.066 | power given, not beyond the noise |
| power, GPU mean (W) | 182.4 | 183.5 | +0.6% | -27.74 to +29.95 | power given, not beyond the noise |
| requests served | 2575 | 2575 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 120.8 | 122.4 | +1.3% | -18.36 to +21.51 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 416.3 | 431.6 | +3.7% | -166.2 to +196.8 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 706.7 | 709.9 | +0.4% | -24.04 to +30.33 | STEADY, under the floor |
| temperature, peak (C) | 59.5 | 59.5 | +0.0% | -12.71 to +12.71 | STEADY, under the floor |
| temperature, mean (C) | 49.3 | 49.36 | +0.1% | -1.913 to +2.049 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.25e+04 | 6.242e+04 | -0.1% | -571.3 to +417.8 | STEADY, under the floor |
| power-capped share of samples | 0.6632 | 0.6739 | +1.6% | -0.1728 to +0.1942 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.56 | 41.6 | +0.1% | -0.7001 to +0.7726 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.196e+04 | 6.191e+04 | -0.1% | -1145 to +1038 | STEADY, under the floor |
| energy per served request (J) | 24.06 | 24.04 | -0.1% | -0.4446 to +0.4032 | STEADY, under the floor |
| power, GPU mean (W) | 183.5 | 183.4 | -0.0% | -13.52 to +13.34 | STEADY, under the floor |
| requests served | 2575 | 2575 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 122.4 | 121.7 | -0.5% | -10.73 to +9.416 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 431.6 | 419.5 | -2.8% | -125.8 to +101.6 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 709.9 | 706 | -0.5% | -37.8 to +30 | GAIN, not beyond the noise |
| temperature, peak (C) | 59.5 | 59 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 49.36 | 49.14 | -0.4% | -0.9859 to +0.5448 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.242e+04 | 6.205e+04 | -0.6% | -2598 to +1858 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6739 | 0.6288 | -6.7% | -0.1101 to +0.01992 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.88 -> 41.6 served requests per kJ, difference -0.2802 (95% interval -9.903 to +9.343).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 28.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*