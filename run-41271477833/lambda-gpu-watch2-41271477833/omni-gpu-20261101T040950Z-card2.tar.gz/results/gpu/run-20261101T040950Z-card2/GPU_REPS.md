# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.05 | 38.67 | 39.15 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.565e+05 | 1.581e+05 | 1.561e+05 |
| energy per served request (J) | 25.61 | 25.86 | 25.55 |
| power, GPU mean (W) | 245.9 | 248.8 | 245.6 |
| requests served | 6112 | 6112 | 6112 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 90.07 | 90.01 | 89.96 |
| response time, 95th percentile (ms) | 266.4 | 266.6 | 266.1 |
| response time, 99th percentile (ms) | 454.1 | 452.9 | 451.6 |
| temperature, peak (C) | 71 | 71.33 | 71 |
| temperature, mean (C) | 56.94 | 57.03 | 57.03 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.563e+05 | 1.566e+05 | 1.564e+05 |
| power-capped share of samples | 0.7289 | 0.7345 | 0.7309 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.05 | 39.15 | +0.2% | -1.745 to +1.932 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.565e+05 | 1.561e+05 | -0.3% | -7813 to +7002 | STEADY, under the floor |
| energy per served request (J) | 25.61 | 25.55 | -0.3% | -1.278 to +1.146 | STEADY, under the floor |
| power, GPU mean (W) | 245.9 | 245.6 | -0.2% | -12.71 to +11.97 | STEADY, under the floor |
| requests served | 6112 | 6112 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.07 | 89.96 | -0.1% | -0.3111 to +0.09766 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.4 | 266.1 | -0.1% | -4.207 to +3.545 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.1 | 451.6 | -0.5% | -6.734 to +1.757 | GAIN, not beyond the noise |
| temperature, peak (C) | 71 | 71 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.94 | 57.03 | +0.2% | -0.07195 to +0.2572 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.563e+05 | 1.564e+05 | +0.1% | -467.5 to +636 | STEADY, under the floor |
| power-capped share of samples | 0.7289 | 0.7309 | +0.3% | -0.01828 to +0.02216 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.05 | 38.67 | -1.0% | -1.65 to +0.8813 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.565e+05 | 1.581e+05 | +1.0% | -3597 to +6662 | power given, not beyond the noise |
| energy per served request (J) | 25.61 | 25.86 | +1.0% | -0.5885 to +1.09 | power given, not beyond the noise |
| power, GPU mean (W) | 245.9 | 248.8 | +1.1% | -5.813 to +11.46 | power given, not beyond the noise |
| requests served | 6112 | 6112 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.07 | 90.01 | -0.1% | -0.2737 to +0.1507 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.4 | 266.6 | +0.1% | -2.766 to +3.12 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.1 | 452.9 | -0.3% | -3.383 to +0.8677 | STEADY, under the floor |
| temperature, peak (C) | 71 | 71.33 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 56.94 | 57.03 | +0.2% | -0.05928 to +0.2468 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.563e+05 | 1.566e+05 | +0.2% | -206.7 to +761.8 | STEADY, under the floor |
| power-capped share of samples | 0.7289 | 0.7345 | +0.8% | -0.03172 to +0.04287 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.67 | 39.15 | +1.2% | -0.5861 to +1.543 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.581e+05 | 1.561e+05 | -1.2% | -6252 to +2375 | GAIN, not beyond the noise |
| energy per served request (J) | 25.86 | 25.55 | -1.2% | -1.023 to +0.3885 | GAIN, not beyond the noise |
| power, GPU mean (W) | 248.8 | 245.6 | -1.3% | -8.976 to +2.583 | GAIN, not beyond the noise |
| requests served | 6112 | 6112 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 90.01 | 89.96 | -0.1% | -0.09327 to +0.002865 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.6 | 266.1 | -0.2% | -2.345 to +1.33 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.9 | 451.6 | -0.3% | -4.775 to +2.314 | STEADY, under the floor |
| temperature, peak (C) | 71.33 | 71 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 57.03 | 57.03 | -0.0% | -0.01919 to +0.01683 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.566e+05 | 1.564e+05 | -0.1% | -404.1 to +17.45 | STEADY, under the floor |
| power-capped share of samples | 0.7345 | 0.7309 | -0.5% | -0.02125 to +0.01398 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.05 -> 39.15 served requests per kJ, difference +0.09366 (95% interval -1.745 to +1.932).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| omni | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 1 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*