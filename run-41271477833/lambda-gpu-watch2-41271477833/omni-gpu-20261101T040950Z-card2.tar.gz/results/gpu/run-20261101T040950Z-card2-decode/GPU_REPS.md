# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.94 | 45.67 | 45.58 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.267e+05 | 1.275e+05 | 1.277e+05 |
| energy per served request (J) | 21.77 | 21.89 | 21.94 |
| power, GPU mean (W) | 198.8 | 199.9 | 200.8 |
| requests served | 5822 | 5822 | 5822 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.31 | 96.27 | 96.28 |
| response time, 95th percentile (ms) | 274.3 | 274.2 | 274.1 |
| response time, 99th percentile (ms) | 448.9 | 448.9 | 448.9 |
| temperature, peak (C) | 63 | 63 | 63 |
| temperature, mean (C) | 49.79 | 49.75 | 49.84 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.273e+05 | 1.272e+05 | 1.272e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.94 | 45.58 | -0.8% | -1.326 to +0.6034 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.267e+05 | 1.277e+05 | +0.8% | -1690 to +3703 | power given, not beyond the noise |
| energy per served request (J) | 21.77 | 21.94 | +0.8% | -0.2903 to +0.636 | power given, not beyond the noise |
| power, GPU mean (W) | 198.8 | 200.8 | +1.0% | -3.284 to +7.21 | power given, not beyond the noise |
| requests served | 5822 | 5822 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.31 | 96.28 | -0.0% | -0.6755 to +0.6095 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.3 | 274.1 | -0.1% | -1.886 to +1.532 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.9 | 448.9 | -0.0% | -6.139 to +5.998 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.79 | 49.84 | +0.1% | -0.3033 to +0.4188 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.272e+05 | -0.1% | -603.9 to +369.6 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.94 | 45.67 | -0.6% | -0.636 to +0.1077 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.267e+05 | 1.275e+05 | +0.6% | -296.8 to +1761 | power given, not beyond the noise |
| energy per served request (J) | 21.77 | 21.89 | +0.6% | -0.05098 to +0.3024 | power given, not beyond the noise |
| power, GPU mean (W) | 198.8 | 199.9 | +0.5% | -0.5068 to +2.67 | power given, not beyond the noise |
| requests served | 5822 | 5822 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.31 | 96.27 | -0.0% | -0.5376 to +0.4619 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.3 | 274.2 | -0.1% | -1.084 to +0.8053 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.9 | 448.9 | -0.0% | -5.138 to +4.997 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.79 | 49.75 | -0.1% | -0.06653 to +0.002158 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.273e+05 | 1.272e+05 | -0.1% | -510.1 to +199.3 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.67 | 45.58 | -0.2% | -0.6905 to +0.496 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.275e+05 | 1.277e+05 | +0.2% | -1394 to +1943 | STEADY, under the floor |
| energy per served request (J) | 21.89 | 21.94 | +0.2% | -0.2395 to +0.3337 | STEADY, under the floor |
| power, GPU mean (W) | 199.9 | 200.8 | +0.4% | -2.807 to +4.57 | STEADY, under the floor |
| requests served | 5822 | 5822 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.27 | 96.28 | +0.0% | -0.1679 to +0.1777 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274.2 | 274.1 | -0.0% | -0.9318 to +0.8568 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.9 | 448.9 | -0.0% | -1.781 to +1.78 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.75 | 49.84 | +0.2% | -0.2449 to +0.4249 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.272e+05 | 1.272e+05 | +0.0% | -302.7 to +379.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.94 -> 45.58 served requests per kJ, difference -0.3614 (95% interval -1.326 to +0.6034).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.23 | 0.33 | 0 | 630 | 31 | True |
| omni | 2 | 34 | 0 | 0 | 0 | 0.199 | 0.356 | 0 | 614 | 33 | True |
| omni | 3 | 30 | 0 | 0 | 0 | 0.206 | 0.256 | 0 | 602 | 29 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | -64.21 | +0 |
| compass | 48 | 974 | -1676 | +91 |
| race | 45 | 154 | -199.9 | -155 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 96.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*