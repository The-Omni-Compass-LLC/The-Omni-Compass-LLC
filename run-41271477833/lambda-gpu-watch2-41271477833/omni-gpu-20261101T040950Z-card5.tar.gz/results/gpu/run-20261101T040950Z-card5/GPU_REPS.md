# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.56 | 40.85 | 40.74 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.562e+05 | 1.551e+05 | 1.555e+05 |
| energy per served request (J) | 24.65 | 24.48 | 24.55 |
| power, GPU mean (W) | 246.2 | 244.4 | 245.2 |
| requests served | 6334 | 6334 | 6334 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 85.84 | 85.9 | 85.9 |
| response time, 95th percentile (ms) | 240.2 | 240.2 | 241.6 |
| response time, 99th percentile (ms) | 433.2 | 433.3 | 433.6 |
| temperature, peak (C) | 66 | 66.33 | 66.33 |
| temperature, mean (C) | 53.3 | 53.37 | 53.41 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.556e+05 | 1.555e+05 | 1.558e+05 |
| power-capped share of samples | 0.7293 | 0.7288 | 0.7302 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.56 | 40.74 | +0.4% | -0.8774 to +1.227 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.562e+05 | 1.555e+05 | -0.4% | -4613 to +3316 | STEADY, under the floor |
| energy per served request (J) | 24.65 | 24.55 | -0.4% | -0.7283 to +0.5235 | STEADY, under the floor |
| power, GPU mean (W) | 246.2 | 245.2 | -0.4% | -7.314 to +5.315 | STEADY, under the floor |
| requests served | 6334 | 6334 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.84 | 85.9 | +0.1% | -0.1017 to +0.2173 | STEADY, under the floor |
| response time, 95th percentile (ms) | 240.2 | 241.6 | +0.6% | -1.188 to +4.088 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 433.2 | 433.6 | +0.1% | -2.371 to +3.234 | STEADY, under the floor |
| temperature, peak (C) | 66 | 66.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 53.3 | 53.41 | +0.2% | -0.08157 to +0.286 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.556e+05 | 1.558e+05 | +0.1% | -70.21 to +485.1 | STEADY, under the floor |
| power-capped share of samples | 0.7293 | 0.7302 | +0.1% | -0.0003654 to +0.002061 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.56 | 40.85 | +0.7% | -0.9201 to +1.487 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.562e+05 | 1.551e+05 | -0.7% | -5662 to +3502 | GAIN, not beyond the noise |
| energy per served request (J) | 24.65 | 24.48 | -0.7% | -0.8939 to +0.5529 | GAIN, not beyond the noise |
| power, GPU mean (W) | 246.2 | 244.4 | -0.7% | -9.008 to +5.554 | GAIN, not beyond the noise |
| requests served | 6334 | 6334 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.84 | 85.9 | +0.1% | -0.09773 to +0.217 | STEADY, under the floor |
| response time, 95th percentile (ms) | 240.2 | 240.2 | +0.0% | -3.073 to +3.107 | STEADY, under the floor |
| response time, 99th percentile (ms) | 433.2 | 433.3 | +0.0% | -4.381 to +4.613 | STEADY, under the floor |
| temperature, peak (C) | 66 | 66.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 53.3 | 53.37 | +0.1% | -0.08992 to +0.2277 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.556e+05 | 1.555e+05 | -0.0% | -120 to +12.51 | STEADY, under the floor |
| power-capped share of samples | 0.7293 | 0.7288 | -0.1% | -0.01503 to +0.0139 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.85 | 40.74 | -0.3% | -2.231 to +2.014 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.551e+05 | 1.555e+05 | +0.3% | -7607 to +8469 | STEADY, under the floor |
| energy per served request (J) | 24.48 | 24.55 | +0.3% | -1.201 to +1.337 | STEADY, under the floor |
| power, GPU mean (W) | 244.4 | 245.2 | +0.3% | -11.94 to +13.39 | STEADY, under the floor |
| requests served | 6334 | 6334 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 85.9 | 85.9 | -0.0% | -0.1361 to +0.1325 | STEADY, under the floor |
| response time, 95th percentile (ms) | 240.2 | 241.6 | +0.6% | -3.827 to +6.693 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 433.3 | 433.6 | +0.1% | -2.359 to +2.991 | STEADY, under the floor |
| temperature, peak (C) | 66.33 | 66.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 53.37 | 53.41 | +0.1% | -0.2514 to +0.3181 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.555e+05 | 1.558e+05 | +0.2% | +11.39 to +511.1 | STEADY, under the floor |
| power-capped share of samples | 0.7288 | 0.7302 | +0.2% | -0.01341 to +0.01623 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.56 -> 40.74 served requests per kJ, difference +0.1748 (95% interval -0.8774 to +1.227).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 3 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 1 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| watch | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*