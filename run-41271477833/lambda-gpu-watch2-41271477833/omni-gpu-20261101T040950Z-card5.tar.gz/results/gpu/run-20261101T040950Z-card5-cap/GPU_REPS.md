# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 44.08 | 42.97 | 43.5 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 5.994e+04 | 6.149e+04 | 6.075e+04 |
| energy per served request (J) | 22.69 | 23.27 | 22.99 |
| power, GPU mean (W) | 176.8 | 181.5 | 180.4 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 109.2 | 109.2 | 109.7 |
| response time, 95th percentile (ms) | 348.4 | 348.7 | 347.9 |
| response time, 99th percentile (ms) | 614 | 614.9 | 611.6 |
| temperature, peak (C) | 55 | 55 | 55 |
| temperature, mean (C) | 45.79 | 45.91 | 45.75 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.141e+04 | 6.15e+04 | 6.088e+04 |
| power-capped share of samples | 0.6663 | 0.6772 | 0.649 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.08 | 43.5 | -1.3% | -9.734 to +8.572 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.994e+04 | 6.075e+04 | +1.3% | -1.188e+04 to +1.349e+04 | power given, not beyond the noise |
| energy per served request (J) | 22.69 | 22.99 | +1.3% | -4.496 to +5.107 | power given, not beyond the noise |
| power, GPU mean (W) | 176.8 | 180.4 | +2.1% | -18.92 to +26.25 | power given, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.2 | 109.7 | +0.4% | -2.353 to +3.235 | STEADY, under the floor |
| response time, 95th percentile (ms) | 348.4 | 347.9 | -0.2% | -13.42 to +12.29 | STEADY, under the floor |
| response time, 99th percentile (ms) | 614 | 611.6 | -0.4% | -15.41 to +10.59 | STEADY, under the floor |
| temperature, peak (C) | 55 | 55 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.79 | 45.75 | -0.1% | -0.7574 to +0.6792 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.141e+04 | 6.088e+04 | -0.9% | -1245 to +185.2 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6663 | 0.649 | -2.6% | -0.1364 to +0.1019 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.08 | 42.97 | -2.5% | -2.985 to +0.7674 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 5.994e+04 | 6.149e+04 | +2.6% | -1322 to +4421 | power given, not beyond the noise |
| energy per served request (J) | 22.69 | 23.27 | +2.6% | -0.5003 to +1.673 | power given, not beyond the noise |
| power, GPU mean (W) | 176.8 | 181.5 | +2.7% | +2.325 to +7.257 | power given, clear of the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.2 | 109.2 | +0.0% | -2.127 to +2.167 | STEADY, under the floor |
| response time, 95th percentile (ms) | 348.4 | 348.7 | +0.1% | -6.205 to +6.763 | STEADY, under the floor |
| response time, 99th percentile (ms) | 614 | 614.9 | +0.1% | -35.51 to +37.29 | STEADY, under the floor |
| temperature, peak (C) | 55 | 55 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.79 | 45.91 | +0.3% | +0.04768 to +0.1921 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.141e+04 | 6.15e+04 | +0.1% | -1926 to +2106 | STEADY, under the floor |
| power-capped share of samples | 0.6663 | 0.6772 | +1.6% | -0.0007764 to +0.02258 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.97 | 43.5 | +1.2% | -10.5 to +11.56 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.149e+04 | 6.075e+04 | -1.2% | -1.63e+04 to +1.482e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 23.27 | 22.99 | -1.2% | -6.169 to +5.608 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.5 | 180.4 | -0.6% | -21.25 to +18.99 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.2 | 109.7 | +0.4% | -4.52 to +5.361 | STEADY, under the floor |
| response time, 95th percentile (ms) | 348.7 | 347.9 | -0.2% | -20.18 to +18.5 | STEADY, under the floor |
| response time, 99th percentile (ms) | 614.9 | 611.6 | -0.5% | -52.7 to +46.09 | GAIN, not beyond the noise |
| temperature, peak (C) | 55 | 55 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.91 | 45.75 | -0.3% | -0.9495 to +0.6315 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.15e+04 | 6.088e+04 | -1.0% | -3351 to +2111 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6772 | 0.649 | -4.2% | -0.159 to +0.1027 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 44.08 -> 43.5 served requests per kJ, difference -0.5812 (95% interval -9.734 to +8.572).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 146 | 0 | n/a | n/a | 0 | 146 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 20.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*