# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 63.23 | 63.16 | 63.1 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.281e+04 | 9.288e+04 | 9.257e+04 |
| energy per served request (J) | 15.81 | 15.83 | 15.85 |
| power, GPU mean (W) | 275 | 274.1 | 274.5 |
| requests served | 5868 | 5867 | 5842 |
| requests not served | 1152 | 1154 | 1180 |
| response time, mean (ms) | 4.024e+04 | 4.026e+04 | 4.073e+04 |
| response time, 95th percentile (ms) | 7.505e+04 | 7.512e+04 | 7.636e+04 |
| response time, 99th percentile (ms) | 7.726e+04 | 7.726e+04 | 7.842e+04 |
| temperature, peak (C) | 59 | 59 | 59 |
| temperature, mean (C) | 57.22 | 57.16 | 56.73 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.286e+04 | 9.29e+04 | 9.253e+04 |
| power-capped share of samples | 0.9809 | 0.9758 | 0.6376 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.23 | 63.1 | -0.2% | -1.25 to +0.9938 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.281e+04 | 9.257e+04 | -0.3% | -3626 to +3147 | STEADY, under the floor |
| energy per served request (J) | 15.81 | 15.85 | +0.2% | -0.2499 to +0.3142 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 274.5 | -0.2% | -9.949 to +8.943 | STEADY, under the floor |
| requests served | 5868 | 5842 | -0.5% | -344.6 to +290.6 | STEADY, under the floor |
| requests not served | 1152 | 1180 | +2.3% | -290.6 to +344.6 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.024e+04 | 4.073e+04 | +1.2% | -6950 to +7923 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.505e+04 | 7.636e+04 | +1.7% | -1.319e+04 to +1.58e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.726e+04 | 7.842e+04 | +1.5% | -1.229e+04 to +1.46e+04 | LOSS, not beyond the noise |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.22 | 56.73 | -0.9% | -5.557 to +4.566 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.286e+04 | 9.253e+04 | -0.4% | -3071 to +2414 | STEADY, under the floor |
| power-capped share of samples | 0.9809 | 0.6376 | -35.0% | -4.496 to +3.81 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.23 | 63.16 | -0.1% | -0.9817 to +0.8462 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.281e+04 | 9.288e+04 | +0.1% | -1897 to +2049 | STEADY, under the floor |
| energy per served request (J) | 15.81 | 15.83 | +0.1% | -0.2123 to +0.2463 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 274.1 | -0.3% | -13.86 to +12.14 | STEADY, under the floor |
| requests served | 5868 | 5867 | -0.0% | -211.1 to +208.1 | STEADY, under the floor |
| requests not served | 1152 | 1154 | +0.1% | -208.1 to +211.1 | STEADY, under the floor |
| response time, mean (ms) | 4.024e+04 | 4.026e+04 | +0.0% | -6381 to +6419 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.505e+04 | 7.512e+04 | +0.1% | -1.099e+04 to +1.112e+04 | STEADY, under the floor |
| response time, 99th percentile (ms) | 7.726e+04 | 7.726e+04 | +0.0% | -8906 to +8906 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.22 | 57.16 | -0.1% | -1.687 to +1.556 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.286e+04 | 9.29e+04 | +0.0% | -1057 to +1134 | STEADY, under the floor |
| power-capped share of samples | 0.9809 | 0.9758 | -0.5% | -0.08415 to +0.07404 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.16 | 63.1 | -0.1% | -0.2682 to +0.1476 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.288e+04 | 9.257e+04 | -0.3% | -1729 to +1098 | STEADY, under the floor |
| energy per served request (J) | 15.83 | 15.85 | +0.1% | -0.03768 to +0.06796 | STEADY, under the floor |
| power, GPU mean (W) | 274.1 | 274.5 | +0.1% | -22.09 to +22.8 | STEADY, under the floor |
| requests served | 5867 | 5842 | -0.4% | -133.5 to +82.5 | STEADY, under the floor |
| requests not served | 1154 | 1180 | +2.2% | -82.5 to +133.5 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.026e+04 | 4.073e+04 | +1.2% | -569.3 to +1505 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.512e+04 | 7.636e+04 | +1.6% | -2203 to +4677 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.726e+04 | 7.842e+04 | +1.5% | -3386 to +5692 | LOSS, not beyond the noise |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.16 | 56.73 | -0.8% | -3.87 to +3.01 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.29e+04 | 9.253e+04 | -0.4% | -2013 to +1280 | STEADY, under the floor |
| power-capped share of samples | 0.9758 | 0.6376 | -34.7% | -4.57 to +3.894 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 63.23 -> 63.1 served requests per kJ, difference -0.1281 (95% interval -1.25 to +0.9938).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*