# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.62 | 47.67 | 47.56 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.21e+05 | 1.209e+05 | 1.212e+05 |
| energy per served request (J) | 21 | 20.98 | 21.03 |
| power, GPU mean (W) | 190.2 | 189.8 | 190.7 |
| requests served | 5764 | 5764 | 5764 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.62 | 96.59 | 96.62 |
| response time, 95th percentile (ms) | 267.1 | 266.8 | 267.1 |
| response time, 99th percentile (ms) | 454.7 | 454.4 | 454.6 |
| temperature, peak (C) | 57 | 57 | 57 |
| temperature, mean (C) | 45.67 | 45.64 | 45.68 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.208e+05 | 1.207e+05 | 1.205e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.62 | 47.56 | -0.1% | -1.316 to +1.191 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.21e+05 | 1.212e+05 | +0.1% | -3021 to +3354 | STEADY, under the floor |
| energy per served request (J) | 21 | 21.03 | +0.1% | -0.5242 to +0.5818 | STEADY, under the floor |
| power, GPU mean (W) | 190.2 | 190.7 | +0.3% | -5.31 to +6.434 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.62 | 96.62 | +0.0% | -0.6198 to +0.6214 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.1 | 267.1 | -0.0% | -1.485 to +1.391 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.7 | 454.6 | -0.0% | -6.296 to +6.199 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.67 | 45.68 | +0.0% | -0.2573 to +0.293 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.208e+05 | 1.205e+05 | -0.2% | -971.9 to +371.7 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.62 | 47.67 | +0.1% | -1.113 to +1.196 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.21e+05 | 1.209e+05 | -0.1% | -3022 to +2822 | STEADY, under the floor |
| energy per served request (J) | 21 | 20.98 | -0.1% | -0.5242 to +0.4896 | STEADY, under the floor |
| power, GPU mean (W) | 190.2 | 189.8 | -0.2% | -4.088 to +3.33 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.62 | 96.59 | -0.0% | -0.3626 to +0.2964 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.1 | 266.8 | -0.1% | -1.287 to +0.7591 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.7 | 454.4 | -0.1% | -4.032 to +3.381 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.67 | 45.64 | -0.0% | -0.1317 to +0.08774 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.208e+05 | 1.207e+05 | -0.1% | -1170 to +904.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.67 | 47.56 | -0.2% | -0.8619 to +0.6535 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.209e+05 | 1.212e+05 | +0.2% | -1680 to +2213 | STEADY, under the floor |
| energy per served request (J) | 20.98 | 21.03 | +0.2% | -0.2915 to +0.3839 | STEADY, under the floor |
| power, GPU mean (W) | 189.8 | 190.7 | +0.5% | -2.235 to +4.117 | STEADY, under the floor |
| requests served | 5764 | 5764 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.59 | 96.62 | +0.0% | -0.33 to +0.3978 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.8 | 267.1 | +0.1% | -0.2392 to +0.674 | STEADY, under the floor |
| response time, 99th percentile (ms) | 454.4 | 454.6 | +0.1% | -2.642 to +3.196 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 45.64 | 45.68 | +0.1% | -0.1322 to +0.2118 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.207e+05 | 1.205e+05 | -0.1% | -984.9 to +649.8 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.62 -> 47.56 served requests per kJ, difference -0.06252 (95% interval -1.316 to +1.191).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.206 | 0.297 | 0 | 1.15e+03 | 27 | True |
| omni | 2 | 30 | 0 | 0 | 0 | 0.208 | 0.279 | 0 | 1.25e+03 | 29 | True |
| omni | 3 | 28 | 0 | 0 | 0 | 0.212 | 0.291 | 0 | 1.18e+03 | 27 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 66 | +68.75 | +0 |
| compass | 43 | 998 | -3183 | -43 |
| fail_up | 1 | 7 | +65.19 | -1 |
| race | 39 | 141 | +219.3 | -15 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 86.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*