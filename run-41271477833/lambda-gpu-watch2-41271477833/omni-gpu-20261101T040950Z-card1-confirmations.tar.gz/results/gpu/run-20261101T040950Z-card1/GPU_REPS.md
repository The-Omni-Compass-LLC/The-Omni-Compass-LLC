# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.58 | 40.46 | 40.65 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.542e+05 | 1.547e+05 | 1.54e+05 |
| energy per served request (J) | 24.64 | 24.72 | 24.6 |
| power, GPU mean (W) | 242.2 | 243.2 | 242 |
| requests served | 6258 | 6258 | 6258 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 87.53 | 87.71 | 87.55 |
| response time, 95th percentile (ms) | 245.9 | 246.4 | 245.9 |
| response time, 99th percentile (ms) | 437.4 | 438.5 | 437.3 |
| temperature, peak (C) | 69 | 69 | 68.33 |
| temperature, mean (C) | 55.13 | 55.11 | 55.06 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.548e+05 | 1.547e+05 | 1.547e+05 |
| power-capped share of samples | 0.7386 | 0.7341 | 0.7404 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.58 | 40.65 | +0.2% | -1.033 to +1.164 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.542e+05 | 1.54e+05 | -0.2% | -4428 to +3927 | STEADY, under the floor |
| energy per served request (J) | 24.64 | 24.6 | -0.2% | -0.7076 to +0.6275 | STEADY, under the floor |
| power, GPU mean (W) | 242.2 | 242 | -0.1% | -7.238 to +6.855 | STEADY, under the floor |
| requests served | 6258 | 6258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.53 | 87.55 | +0.0% | -0.1854 to +0.2249 | STEADY, under the floor |
| response time, 95th percentile (ms) | 245.9 | 245.9 | -0.0% | -0.7767 to +0.6487 | STEADY, under the floor |
| response time, 99th percentile (ms) | 437.4 | 437.3 | -0.0% | -1.779 to +1.477 | STEADY, under the floor |
| temperature, peak (C) | 69 | 68.33 | -1.0% | -2.101 to +0.7677 | GAIN, not beyond the noise |
| temperature, mean (C) | 55.13 | 55.06 | -0.1% | -0.2113 to +0.0724 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.548e+05 | 1.547e+05 | -0.1% | -267.9 to +88.09 | STEADY, under the floor |
| power-capped share of samples | 0.7386 | 0.7404 | +0.2% | -0.009306 to +0.01287 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.58 | 40.46 | -0.3% | -0.8382 to +0.5984 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.542e+05 | 1.547e+05 | +0.3% | -2286 to +3192 | STEADY, under the floor |
| energy per served request (J) | 24.64 | 24.72 | +0.3% | -0.3652 to +0.5101 | STEADY, under the floor |
| power, GPU mean (W) | 242.2 | 243.2 | +0.4% | -3.583 to +5.495 | STEADY, under the floor |
| requests served | 6258 | 6258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.53 | 87.71 | +0.2% | -0.125 to +0.4861 | STEADY, under the floor |
| response time, 95th percentile (ms) | 245.9 | 246.4 | +0.2% | -0.09958 to +1.105 | STEADY, under the floor |
| response time, 99th percentile (ms) | 437.4 | 438.5 | +0.2% | +0.5095 to +1.563 | STEADY, under the floor |
| temperature, peak (C) | 69 | 69 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.13 | 55.11 | -0.0% | -0.326 to +0.2792 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.548e+05 | 1.547e+05 | -0.1% | -223.9 to -71.41 | STEADY, under the floor |
| power-capped share of samples | 0.7386 | 0.7341 | -0.6% | -0.02683 to +0.01776 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.46 | 40.65 | +0.5% | -0.5539 to +0.9244 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.547e+05 | 1.54e+05 | -0.5% | -3513 to +2105 | STEADY, under the floor |
| energy per served request (J) | 24.72 | 24.6 | -0.5% | -0.5613 to +0.3364 | STEADY, under the floor |
| power, GPU mean (W) | 243.2 | 242 | -0.5% | -5.551 to +3.256 | STEADY, under the floor |
| requests served | 6258 | 6258 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.71 | 87.55 | -0.2% | -0.5088 to +0.1872 | STEADY, under the floor |
| response time, 95th percentile (ms) | 246.4 | 245.9 | -0.2% | -0.9644 to -0.1693 | STEADY, under the floor |
| response time, 99th percentile (ms) | 438.5 | 437.3 | -0.3% | -3.318 to +0.9437 | STEADY, under the floor |
| temperature, peak (C) | 69 | 68.33 | -1.0% | -2.101 to +0.7677 | GAIN, not beyond the noise |
| temperature, mean (C) | 55.11 | 55.06 | -0.1% | -0.2075 to +0.1155 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.547e+05 | 1.547e+05 | +0.0% | -170.2 to +285.7 | STEADY, under the floor |
| power-capped share of samples | 0.7341 | 0.7404 | +0.9% | -0.004905 to +0.01754 | power given, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.58 -> 40.65 served requests per kJ, difference +0.06542 (95% interval -1.033 to +1.164).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 268 | 0 | n/a | n/a | 0 | 268 | 0 |
| omni | 2 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| omni | 3 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| watch | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*