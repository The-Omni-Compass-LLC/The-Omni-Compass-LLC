# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.76 | 47.45 | 47.57 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.224e+05 | 1.232e+05 | 1.229e+05 |
| energy per served request (J) | 20.94 | 21.07 | 21.02 |
| power, GPU mean (W) | 192.4 | 193.6 | 193 |
| requests served | 5844 | 5844 | 5844 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.37 | 96.34 | 96.29 |
| response time, 95th percentile (ms) | 273.9 | 274 | 273.7 |
| response time, 99th percentile (ms) | 450.5 | 450.6 | 450.5 |
| temperature, peak (C) | 60 | 60 | 60 |
| temperature, mean (C) | 48.02 | 48.05 | 47.99 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.229e+05 | 1.228e+05 | 1.229e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.76 | 47.57 | -0.4% | -1.647 to +1.272 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.224e+05 | 1.229e+05 | +0.4% | -3272 to +4235 | STEADY, under the floor |
| energy per served request (J) | 20.94 | 21.02 | +0.4% | -0.5598 to +0.7246 | STEADY, under the floor |
| power, GPU mean (W) | 192.4 | 193 | +0.3% | -4.569 to +5.712 | STEADY, under the floor |
| requests served | 5844 | 5844 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.37 | 96.29 | -0.1% | -0.6427 to +0.4905 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273.9 | 273.7 | -0.1% | -2.093 to +1.633 | STEADY, under the floor |
| response time, 99th percentile (ms) | 450.5 | 450.5 | +0.0% | -4.188 to +4.226 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.02 | 47.99 | -0.0% | -0.06678 to +0.02313 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.229e+05 | 1.229e+05 | +0.0% | -811.8 to +842.7 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.76 | 47.45 | -0.6% | -1.719 to +1.116 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.224e+05 | 1.232e+05 | +0.6% | -2877 to +4430 | power given, not beyond the noise |
| energy per served request (J) | 20.94 | 21.07 | +0.6% | -0.4923 to +0.758 | power given, not beyond the noise |
| power, GPU mean (W) | 192.4 | 193.6 | +0.6% | -4.526 to +6.955 | power given, not beyond the noise |
| requests served | 5844 | 5844 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.37 | 96.34 | -0.0% | -0.8941 to +0.8515 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273.9 | 274 | +0.0% | -3.019 to +3.19 | STEADY, under the floor |
| response time, 99th percentile (ms) | 450.5 | 450.6 | +0.0% | -6.423 to +6.704 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.02 | 48.05 | +0.1% | -0.1184 to +0.1829 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.229e+05 | 1.228e+05 | -0.0% | -492.6 to +413.4 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.45 | 47.57 | +0.2% | +0.07226 to +0.1557 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.232e+05 | 1.229e+05 | -0.2% | -394.8 to -194.8 | STEADY, under the floor |
| energy per served request (J) | 21.07 | 21.02 | -0.2% | -0.06756 to -0.03333 | STEADY, under the floor |
| power, GPU mean (W) | 193.6 | 193 | -0.3% | -1.252 to -0.03379 | STEADY, under the floor |
| requests served | 5844 | 5844 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.34 | 96.29 | -0.1% | -0.4489 to +0.3393 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274 | 273.7 | -0.1% | -1.724 to +1.093 | STEADY, under the floor |
| response time, 99th percentile (ms) | 450.6 | 450.5 | -0.0% | -3.12 to +2.877 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.05 | 47.99 | -0.1% | -0.2097 to +0.1016 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.228e+05 | 1.229e+05 | +0.0% | -365.8 to +475.8 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.76 -> 47.57 served requests per kJ, difference -0.1873 (95% interval -1.647 to +1.272).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 34 | 0 | 0 | 0 | 0.211 | 0.341 | 0 | 1.23e+03 | 33 | True |
| omni | 2 | 36 | 0 | 0 | 0 | 0.221 | 0.344 | 0 | 1.36e+03 | 35 | True |
| omni | 3 | 28 | 0 | 0 | 0 | 0.23 | 0.343 | 0 | 988 | 27 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | +103.5 | +0 |
| compass | 49 | 978 | +1562 | +36 |
| fail_up | 2 | 12 | -206.6 | +1 |
| race | 44 | 165 | -376 | -7 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 98.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*