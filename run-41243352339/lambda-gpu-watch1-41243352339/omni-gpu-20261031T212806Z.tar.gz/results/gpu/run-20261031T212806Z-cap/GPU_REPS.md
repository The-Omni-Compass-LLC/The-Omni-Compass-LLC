# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 37.54 | 37.43 | 37.68 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.749e+04 | 2.757e+04 | 2.739e+04 |
| energy per served request (J) | 26.64 | 26.71 | 26.54 |
| power, GPU mean (W) | 82.78 | 82.9 | 82.38 |
| requests served | 1032 | 1032 | 1032 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 218.7 | 217.2 | 216.3 |
| response time, 95th percentile (ms) | 730.2 | 725 | 710.7 |
| response time, 99th percentile (ms) | 1044 | 1032 | 1004 |
| temperature, peak (C) | 54 | 54 | 54 |
| temperature, mean (C) | 49.23 | 48.97 | 48.91 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.655e+04 | 2.654e+04 | 2.645e+04 |
| power-capped share of samples | 0.7357 | 0.7334 | 0.7163 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.54 | 37.68 | +0.4% | -0.2253 to +0.4967 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.749e+04 | 2.739e+04 | -0.4% | -360.3 to +165.4 | STEADY, under the floor |
| energy per served request (J) | 26.64 | 26.54 | -0.4% | -0.3491 to +0.1602 | STEADY, under the floor |
| power, GPU mean (W) | 82.78 | 82.38 | -0.5% | -1.209 to +0.4144 | STEADY, under the floor |
| requests served | 1032 | 1032 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 218.7 | 216.3 | -1.1% | -4.886 to +0.1572 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 730.2 | 710.7 | -2.7% | -32 to -7.032 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 1044 | 1004 | -3.8% | -76.02 to -3.926 | GAIN, clear of the noise |
| temperature, peak (C) | 54 | 54 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.23 | 48.91 | -0.6% | -0.8418 to +0.2062 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.655e+04 | 2.645e+04 | -0.4% | -259.2 to +63.47 | STEADY, under the floor |
| power-capped share of samples | 0.7357 | 0.7163 | -2.6% | -0.02357 to -0.01513 | GAIN, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.54 | 37.43 | -0.3% | -0.447 to +0.2344 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.749e+04 | 2.757e+04 | +0.3% | -171.8 to +328.4 | STEADY, under the floor |
| energy per served request (J) | 26.64 | 26.71 | +0.3% | -0.1665 to +0.3182 | STEADY, under the floor |
| power, GPU mean (W) | 82.78 | 82.9 | +0.1% | -0.5774 to +0.8247 | STEADY, under the floor |
| requests served | 1032 | 1032 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 218.7 | 217.2 | -0.7% | -3.637 to +0.7356 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 730.2 | 725 | -0.7% | -16.4 to +6.026 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1044 | 1032 | -1.2% | -26.79 to +1.132 | GAIN, not beyond the noise |
| temperature, peak (C) | 54 | 54 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 49.23 | 48.97 | -0.5% | -0.7301 to +0.2197 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.655e+04 | 2.654e+04 | -0.0% | -62.42 to +41.69 | STEADY, under the floor |
| power-capped share of samples | 0.7357 | 0.7334 | -0.3% | -0.008302 to +0.003698 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.43 | 37.68 | +0.6% | -0.3151 to +0.799 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.757e+04 | 2.739e+04 | -0.6% | -583.6 to +232.1 | GAIN, not beyond the noise |
| energy per served request (J) | 26.71 | 26.54 | -0.6% | -0.5655 to +0.2249 | GAIN, not beyond the noise |
| power, GPU mean (W) | 82.9 | 82.38 | -0.6% | -1.761 to +0.7188 | GAIN, not beyond the noise |
| requests served | 1032 | 1032 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 217.2 | 216.3 | -0.4% | -2.885 to +1.058 | STEADY, under the floor |
| response time, 95th percentile (ms) | 725 | 710.7 | -2.0% | -24.81 to -3.835 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 1032 | 1004 | -2.6% | -54.8 to +0.5125 | GAIN, not beyond the noise |
| temperature, peak (C) | 54 | 54 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.97 | 48.91 | -0.1% | -0.2689 to +0.1437 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.654e+04 | 2.645e+04 | -0.3% | -239.5 to +64.53 | STEADY, under the floor |
| power-capped share of samples | 0.7334 | 0.7163 | -2.3% | -0.02548 to -0.008615 | GAIN, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 37.54 -> 37.68 served requests per kJ, difference +0.1357 (95% interval -0.2253 to +0.4967).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| omni | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 3 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| omni | 4 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| omni | 5 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 2 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 5 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 66.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*