# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 75.47 | 75.34 | 76.85 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 3.466e+04 | 3.467e+04 | 3.455e+04 |
| energy per served request (J) | 13.25 | 13.27 | 13.01 |
| power, GPU mean (W) | 104 | 104 | 103.6 |
| requests served | 2616 | 2612 | 2656 |
| requests not served | 656.8 | 661 | 617.4 |
| response time, mean (ms) | 4.297e+04 | 4.341e+04 | 4.195e+04 |
| response time, 95th percentile (ms) | 8.742e+04 | 8.777e+04 | 8.42e+04 |
| response time, 99th percentile (ms) | 9.117e+04 | 9.163e+04 | 8.746e+04 |
| temperature, peak (C) | 60 | 60 | 60 |
| temperature, mean (C) | 56.57 | 56.79 | 56.74 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 3.47e+04 | 3.47e+04 | 3.459e+04 |
| power-capped share of samples | 0.9925 | 0.992 | 0.8811 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 75.47 | 76.85 | +1.8% | +1.017 to +1.737 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.466e+04 | 3.455e+04 | -0.3% | -126.5 to -90.46 | STEADY, under the floor |
| energy per served request (J) | 13.25 | 13.01 | -1.8% | -0.3002 to -0.1748 | GAIN, clear of the noise |
| power, GPU mean (W) | 104 | 103.6 | -0.4% | -0.4192 to -0.3181 | STEADY, under the floor |
| requests served | 2616 | 2656 | +1.5% | +27.87 to +50.93 | GAIN, clear of the noise |
| requests not served | 656.8 | 617.4 | -6.0% | -50.93 to -27.87 | GAIN, clear of the noise |
| response time, mean (ms) | 4.297e+04 | 4.195e+04 | -2.4% | -1391 to -656.4 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 8.742e+04 | 8.42e+04 | -3.7% | -4319 to -2122 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 9.117e+04 | 8.746e+04 | -4.1% | -4951 to -2469 | GAIN, clear of the noise |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.57 | 56.74 | +0.3% | -0.5261 to +0.8595 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.47e+04 | 3.459e+04 | -0.3% | -138.4 to -82.43 | STEADY, under the floor |
| power-capped share of samples | 0.9925 | 0.8811 | -11.2% | -0.2289 to +0.00601 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 75.47 | 75.34 | -0.2% | -0.3867 to +0.117 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.466e+04 | 3.467e+04 | +0.0% | -24.88 to +37.52 | STEADY, under the floor |
| energy per served request (J) | 13.25 | 13.27 | +0.2% | -0.0204 to +0.06767 | STEADY, under the floor |
| power, GPU mean (W) | 104 | 104 | +0.0% | -0.103 to +0.1203 | STEADY, under the floor |
| requests served | 2616 | 2612 | -0.2% | -12.59 to +4.193 | STEADY, under the floor |
| requests not served | 656.8 | 661 | +0.6% | -4.193 to +12.59 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.297e+04 | 4.341e+04 | +1.0% | -76.06 to +953.4 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.742e+04 | 8.777e+04 | +0.4% | -292.7 to +976.7 | STEADY, under the floor |
| response time, 99th percentile (ms) | 9.117e+04 | 9.163e+04 | +0.5% | -534.3 to +1447 | LOSS, not beyond the noise |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.57 | 56.79 | +0.4% | -0.4347 to +0.8845 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.47e+04 | 3.47e+04 | +0.0% | -11.84 to +13.2 | STEADY, under the floor |
| power-capped share of samples | 0.9925 | 0.992 | -0.0% | -0.002268 to +0.0013 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 75.34 | 76.85 | +2.0% | +1.173 to +1.851 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.467e+04 | 3.455e+04 | -0.3% | -152.3 to -77.29 | STEADY, under the floor |
| energy per served request (J) | 13.27 | 13.01 | -2.0% | -0.3197 to -0.2025 | GAIN, clear of the noise |
| power, GPU mean (W) | 104 | 103.6 | -0.4% | -0.4812 to -0.2734 | STEADY, under the floor |
| requests served | 2612 | 2656 | +1.7% | +32.48 to +54.72 | GAIN, clear of the noise |
| requests not served | 661 | 617.4 | -6.6% | -54.72 to -32.48 | GAIN, clear of the noise |
| response time, mean (ms) | 4.341e+04 | 4.195e+04 | -3.4% | -1977 to -947.7 | GAIN, clear of the noise |
| response time, 95th percentile (ms) | 8.777e+04 | 8.42e+04 | -4.1% | -4618 to -2507 | GAIN, clear of the noise |
| response time, 99th percentile (ms) | 9.163e+04 | 8.746e+04 | -4.5% | -5087 to -3246 | GAIN, clear of the noise |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.79 | 56.74 | -0.1% | -0.1366 to +0.02021 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.47e+04 | 3.459e+04 | -0.3% | -137.3 to -84.94 | STEADY, under the floor |
| power-capped share of samples | 0.992 | 0.8811 | -11.2% | -0.2276 to +0.005703 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 75.47 -> 76.85 served requests per kJ, difference +1.377 (95% interval +1.017 to +1.737).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: GAIN (within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 2 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 3 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| omni | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 1 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 2 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 3 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 4 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |
| watch | 5 | 161 | 0 | n/a | n/a | 0 | 161 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 5.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*