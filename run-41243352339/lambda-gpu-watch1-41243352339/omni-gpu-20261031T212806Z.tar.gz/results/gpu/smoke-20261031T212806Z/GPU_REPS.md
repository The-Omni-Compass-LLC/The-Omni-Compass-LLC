# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 53.56 | 53.43 | 53.44 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.216e+04 | 2.222e+04 | 2.221e+04 |
| energy per served request (J) | 18.67 | 18.72 | 18.71 |
| power, GPU mean (W) | 104.6 | 104.9 | 104.9 |
| requests served | 1187 | 1187 | 1187 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 155.2 | 157.4 | 158.1 |
| response time, 95th percentile (ms) | 542.4 | 556 | 554.3 |
| response time, 99th percentile (ms) | 783.4 | 798.2 | 799.1 |
| temperature, peak (C) | 63.33 | 64 | 64 |
| temperature, mean (C) | 56.29 | 57.3 | 57.41 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.193e+04 | 2.201e+04 | 2.202e+04 |
| power-capped share of samples | 0.7882 | 0.7898 | 0.7917 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.56 | 53.44 | -0.2% | -1.449 to +1.21 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.216e+04 | 2.221e+04 | +0.2% | -503.3 to +601.3 | STEADY, under the floor |
| energy per served request (J) | 18.67 | 18.71 | +0.2% | -0.424 to +0.5066 | STEADY, under the floor |
| power, GPU mean (W) | 104.6 | 104.9 | +0.2% | -2.281 to +2.794 | STEADY, under the floor |
| requests served | 1187 | 1187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 155.2 | 158.1 | +1.8% | -1.39 to +7.095 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 542.4 | 554.3 | +2.2% | -1.84 to +25.47 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 783.4 | 799.1 | +2.0% | +1.916 to +29.45 | LOSS, clear of the noise |
| temperature, peak (C) | 63.33 | 64 | +1.1% | -2.202 to +3.535 | power given, not beyond the noise |
| temperature, mean (C) | 56.29 | 57.41 | +2.0% | -3.501 to +5.739 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.193e+04 | 2.202e+04 | +0.4% | -224.4 to +409.5 | STEADY, under the floor |
| power-capped share of samples | 0.7882 | 0.7917 | +0.4% | -0.002448 to +0.009393 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.56 | 53.43 | -0.2% | -1.502 to +1.235 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.216e+04 | 2.222e+04 | +0.2% | -513.7 to +623.5 | STEADY, under the floor |
| energy per served request (J) | 18.67 | 18.72 | +0.2% | -0.4328 to +0.5253 | STEADY, under the floor |
| power, GPU mean (W) | 104.6 | 104.9 | +0.3% | -2.409 to +2.945 | STEADY, under the floor |
| requests served | 1187 | 1187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 155.2 | 157.4 | +1.4% | -2.132 to +6.604 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 542.4 | 556 | +2.5% | -4.657 to +31.83 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 783.4 | 798.2 | +1.9% | +4.634 to +24.97 | LOSS, clear of the noise |
| temperature, peak (C) | 63.33 | 64 | +1.1% | -2.202 to +3.535 | power given, not beyond the noise |
| temperature, mean (C) | 56.29 | 57.3 | +1.8% | -3.201 to +5.215 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.193e+04 | 2.201e+04 | +0.3% | -202.1 to +348.4 | STEADY, under the floor |
| power-capped share of samples | 0.7882 | 0.7898 | +0.2% | -0.002014 to +0.005302 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.43 | 53.44 | +0.0% | -0.05072 to +0.07882 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.222e+04 | 2.221e+04 | -0.0% | -33.08 to +21.28 | STEADY, under the floor |
| energy per served request (J) | 18.72 | 18.71 | -0.0% | -0.02787 to +0.01793 | STEADY, under the floor |
| power, GPU mean (W) | 104.9 | 104.9 | -0.0% | -0.1746 to +0.1513 | STEADY, under the floor |
| requests served | 1187 | 1187 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 157.4 | 158.1 | +0.4% | -2.47 to +3.702 | STEADY, under the floor |
| response time, 95th percentile (ms) | 556 | 554.3 | -0.3% | -31.95 to +28.41 | STEADY, under the floor |
| response time, 99th percentile (ms) | 798.2 | 799.1 | +0.1% | -11.91 to +13.68 | STEADY, under the floor |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.3 | 57.41 | +0.2% | -0.3057 to +0.5295 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.201e+04 | 2.202e+04 | +0.1% | -35.43 to +74.26 | STEADY, under the floor |
| power-capped share of samples | 0.7898 | 0.7917 | +0.2% | -0.004676 to +0.008331 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 53.56 -> 53.44 served requests per kJ, difference -0.1195 (95% interval -1.449 to +1.21).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*