# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 57.11 | 56.56 | 56.99 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.155e+04 | 2.177e+04 | 2.16e+04 |
| energy per served request (J) | 17.51 | 17.68 | 17.55 |
| power, GPU mean (W) | 101.8 | 102.8 | 102 |
| requests served | 1231 | 1231 | 1231 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 132.5 | 133.6 | 133.7 |
| response time, 95th percentile (ms) | 403.4 | 409.2 | 408.9 |
| response time, 99th percentile (ms) | 663.2 | 668.9 | 671.3 |
| temperature, peak (C) | 62.67 | 63 | 63 |
| temperature, mean (C) | 55.49 | 56.2 | 56.25 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.142e+04 | 2.148e+04 | 2.145e+04 |
| power-capped share of samples | 0.8049 | 0.8059 | 0.8057 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.11 | 56.99 | -0.2% | -1.893 to +1.656 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.155e+04 | 2.16e+04 | +0.2% | -629.2 to +722.7 | STEADY, under the floor |
| energy per served request (J) | 17.51 | 17.55 | +0.2% | -0.5111 to +0.5871 | STEADY, under the floor |
| power, GPU mean (W) | 101.8 | 102 | +0.2% | -3.137 to +3.554 | STEADY, under the floor |
| requests served | 1231 | 1231 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 132.5 | 133.7 | +0.9% | -2.707 to +5.081 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 403.4 | 408.9 | +1.4% | -15.88 to +26.82 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 663.2 | 671.3 | +1.2% | -12.07 to +28.33 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.67 | 63 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 55.49 | 56.25 | +1.4% | -2.799 to +4.322 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.142e+04 | 2.145e+04 | +0.2% | -124.4 to +195.7 | STEADY, under the floor |
| power-capped share of samples | 0.8049 | 0.8057 | +0.1% | -0.01777 to +0.01928 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.11 | 56.56 | -1.0% | -1.743 to +0.6472 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.155e+04 | 2.177e+04 | +1.0% | -250.6 to +670.7 | power given, not beyond the noise |
| energy per served request (J) | 17.51 | 17.68 | +1.0% | -0.2036 to +0.5449 | power given, not beyond the noise |
| power, GPU mean (W) | 101.8 | 102.8 | +1.0% | -1.138 to +3.16 | power given, not beyond the noise |
| requests served | 1231 | 1231 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 132.5 | 133.6 | +0.8% | -2.87 to +5.088 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 403.4 | 409.2 | +1.4% | -20.29 to +31.82 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 663.2 | 668.9 | +0.9% | -15.07 to +26.54 | LOSS, not beyond the noise |
| temperature, peak (C) | 62.67 | 63 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 55.49 | 56.2 | +1.3% | -2.795 to +4.2 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.142e+04 | 2.148e+04 | +0.3% | -98.32 to +216.5 | STEADY, under the floor |
| power-capped share of samples | 0.8049 | 0.8059 | +0.1% | -0.007535 to +0.009429 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 56.56 | 56.99 | +0.8% | -2.41 to +3.268 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.177e+04 | 2.16e+04 | -0.8% | -1249 to +922.6 | GAIN, not beyond the noise |
| energy per served request (J) | 17.68 | 17.55 | -0.8% | -1.015 to +0.7495 | GAIN, not beyond the noise |
| power, GPU mean (W) | 102.8 | 102 | -0.8% | -6.035 to +4.429 | GAIN, not beyond the noise |
| requests served | 1231 | 1231 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 133.6 | 133.7 | +0.1% | -0.1387 to +0.2949 | STEADY, under the floor |
| response time, 95th percentile (ms) | 409.2 | 408.9 | -0.1% | -9.461 to +8.874 | STEADY, under the floor |
| response time, 99th percentile (ms) | 668.9 | 671.3 | +0.4% | -1.585 to +6.375 | STEADY, under the floor |
| temperature, peak (C) | 63 | 63 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.2 | 56.25 | +0.1% | -0.1213 to +0.2396 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.148e+04 | 2.145e+04 | -0.1% | -71.88 to +24.94 | STEADY, under the floor |
| power-capped share of samples | 0.8059 | 0.8057 | -0.0% | -0.02637 to +0.02598 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 57.11 -> 56.99 served requests per kJ, difference -0.1187 (95% interval -1.893 to +1.656).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*