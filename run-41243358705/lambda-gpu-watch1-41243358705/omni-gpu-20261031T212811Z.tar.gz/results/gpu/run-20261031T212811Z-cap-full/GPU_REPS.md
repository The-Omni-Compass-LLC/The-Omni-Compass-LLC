# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 65.14 | 64.99 | 65.65 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 3.462e+04 | 3.464e+04 | 3.411e+04 |
| energy per served request (J) | 15.35 | 15.39 | 15.23 |
| power, GPU mean (W) | 104.3 | 104.4 | 102.8 |
| requests served | 2255 | 2251 | 2239 |
| requests not served | 561.8 | 565.8 | 577.6 |
| response time, mean (ms) | 4.251e+04 | 4.281e+04 | 4.343e+04 |
| response time, 95th percentile (ms) | 8.35e+04 | 8.394e+04 | 8.538e+04 |
| response time, 99th percentile (ms) | 8.872e+04 | 8.905e+04 | 9.023e+04 |
| temperature, peak (C) | 60 | 60 | 59 |
| temperature, mean (C) | 56.36 | 56.55 | 56.16 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 3.464e+04 | 3.464e+04 | 3.411e+04 |
| power-capped share of samples | 0.9989 | 0.9983 | 0.9966 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.14 | 65.65 | +0.8% | +0.3577 to +0.6727 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.462e+04 | 3.411e+04 | -1.5% | -552 to -472.8 | GAIN, clear of the noise |
| energy per served request (J) | 15.35 | 15.23 | -0.8% | -0.1574 to -0.08353 | GAIN, clear of the noise |
| power, GPU mean (W) | 104.3 | 102.8 | -1.5% | -1.638 to -1.43 | GAIN, clear of the noise |
| requests served | 2255 | 2239 | -0.7% | -22.62 to -8.978 | LOSS, clear of the noise |
| requests not served | 561.8 | 577.6 | +2.8% | +8.978 to +22.62 | LOSS, clear of the noise |
| response time, mean (ms) | 4.251e+04 | 4.343e+04 | +2.2% | +333.3 to +1517 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 8.35e+04 | 8.538e+04 | +2.2% | +1073 to +2682 | LOSS, clear of the noise |
| response time, 99th percentile (ms) | 8.872e+04 | 9.023e+04 | +1.7% | +801.3 to +2211 | LOSS, clear of the noise |
| temperature, peak (C) | 60 | 59 | -1.7% | -1 to -1 | GAIN, clear of the noise |
| temperature, mean (C) | 56.36 | 56.16 | -0.3% | -0.6387 to +0.2455 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.464e+04 | 3.411e+04 | -1.5% | -554.5 to -502.8 | GAIN, clear of the noise |
| power-capped share of samples | 0.9989 | 0.9966 | -0.2% | -0.004311 to -0.0002848 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 65.14 | 64.99 | -0.2% | -0.3366 to +0.05295 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.462e+04 | 3.464e+04 | +0.0% | -30.93 to +59 | STEADY, under the floor |
| energy per served request (J) | 15.35 | 15.39 | +0.2% | -0.01251 to +0.07958 | STEADY, under the floor |
| power, GPU mean (W) | 104.3 | 104.4 | +0.1% | -0.07163 to +0.187 | STEADY, under the floor |
| requests served | 2255 | 2251 | -0.2% | -10.33 to +2.33 | STEADY, under the floor |
| requests not served | 561.8 | 565.8 | +0.7% | -2.33 to +10.33 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.251e+04 | 4.281e+04 | +0.7% | -186.1 to +795.9 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.35e+04 | 8.394e+04 | +0.5% | -373.2 to +1259 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.872e+04 | 8.905e+04 | +0.4% | -245.4 to +906.2 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 56.36 | 56.55 | +0.3% | -0.3246 to +0.7026 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.464e+04 | 3.464e+04 | +0.0% | -8.708 to +9.322 | STEADY, under the floor |
| power-capped share of samples | 0.9989 | 0.9983 | -0.1% | -0.003607 to +0.002397 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 64.99 | 65.65 | +1.0% | +0.4431 to +0.871 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 3.464e+04 | 3.411e+04 | -1.5% | -569.4 to -483.4 | GAIN, clear of the noise |
| energy per served request (J) | 15.39 | 15.23 | -1.0% | -0.2043 to -0.1037 | GAIN, clear of the noise |
| power, GPU mean (W) | 104.4 | 102.8 | -1.5% | -1.722 to -1.461 | GAIN, clear of the noise |
| requests served | 2251 | 2239 | -0.5% | -20.19 to -3.407 | LOSS, clear of the noise |
| requests not served | 565.8 | 577.6 | +2.1% | +3.407 to +20.19 | LOSS, clear of the noise |
| response time, mean (ms) | 4.281e+04 | 4.343e+04 | +1.4% | +35.35 to +1205 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 8.394e+04 | 8.538e+04 | +1.7% | +338.9 to +2530 | LOSS, clear of the noise |
| response time, 99th percentile (ms) | 8.905e+04 | 9.023e+04 | +1.3% | +300.2 to +2052 | LOSS, clear of the noise |
| temperature, peak (C) | 60 | 59 | -1.7% | -1 to -1 | GAIN, clear of the noise |
| temperature, mean (C) | 56.55 | 56.16 | -0.7% | -0.4599 to -0.3114 | GAIN, clear of the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 3.464e+04 | 3.411e+04 | -1.5% | -547 to -510.9 | GAIN, clear of the noise |
| power-capped share of samples | 0.9983 | 0.9966 | -0.2% | -0.004981 to +0.001595 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 65.14 -> 65.65 served requests per kJ, difference +0.5152 (95% interval +0.3577 to +0.6727).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: GAIN AND LOSS (energy cut, service traded for it).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| omni | 2 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| omni | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 2 | 162 | 0 | n/a | n/a | 0 | 162 | 0 |
| watch | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 7.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*