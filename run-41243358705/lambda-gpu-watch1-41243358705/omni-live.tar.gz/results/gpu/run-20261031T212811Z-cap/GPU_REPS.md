# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 105.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
5 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.87 | 42 | 41.95 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.709e+04 | 2.7e+04 | 2.704e+04 |
| energy per served request (J) | 23.88 | 23.81 | 23.84 |
| power, GPU mean (W) | 81.62 | 81.36 | 81.47 |
| requests served | 1134 | 1134 | 1134 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 200 | 199.5 | 204.4 |
| response time, 95th percentile (ms) | 681.5 | 675.9 | 694.8 |
| response time, 99th percentile (ms) | 999.9 | 994.4 | 1027 |
| temperature, peak (C) | 54 | 54 | 53.8 |
| temperature, mean (C) | 48.87 | 48.72 | 48.65 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.622e+04 | 2.617e+04 | 2.61e+04 |
| power-capped share of samples | 0.7475 | 0.7477 | 0.7307 |

## Total: Omni governs against native, 5 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.87 | 41.95 | +0.2% | -0.397 to +0.552 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.709e+04 | 2.704e+04 | -0.2% | -355.6 to +257 | STEADY, under the floor |
| energy per served request (J) | 23.88 | 23.84 | -0.2% | -0.3136 to +0.2266 | STEADY, under the floor |
| power, GPU mean (W) | 81.62 | 81.47 | -0.2% | -1.071 to +0.7658 | STEADY, under the floor |
| requests served | 1134 | 1134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 200 | 204.4 | +2.2% | +1.574 to +7.238 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 681.5 | 694.8 | +2.0% | -1.83 to +28.42 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 999.9 | 1027 | +2.7% | +5.414 to +49.38 | LOSS, clear of the noise |
| temperature, peak (C) | 54 | 53.8 | -0.4% | -0.7552 to +0.3552 | STEADY, under the floor |
| temperature, mean (C) | 48.87 | 48.65 | -0.5% | -0.539 to +0.08453 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.622e+04 | 2.61e+04 | -0.5% | -208.9 to -28.39 | STEADY, under the floor |
| power-capped share of samples | 0.7475 | 0.7307 | -2.2% | -0.02362 to -0.009982 | GAIN, clear of the noise |

## Observation: omni watching (writes nothing) against native, 5 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.87 | 42 | +0.3% | -0.001113 to +0.2734 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.709e+04 | 2.7e+04 | -0.3% | -176.5 to +0.6713 | STEADY, under the floor |
| energy per served request (J) | 23.88 | 23.81 | -0.3% | -0.1556 to +0.000592 | STEADY, under the floor |
| power, GPU mean (W) | 81.62 | 81.36 | -0.3% | -0.537 to +0.02061 | STEADY, under the floor |
| requests served | 1134 | 1134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 200 | 199.5 | -0.2% | -2.558 to +1.628 | STEADY, under the floor |
| response time, 95th percentile (ms) | 681.5 | 675.9 | -0.8% | -17.37 to +6.252 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 999.9 | 994.4 | -0.5% | -23.36 to +12.42 | GAIN, not beyond the noise |
| temperature, peak (C) | 54 | 54 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.87 | 48.72 | -0.3% | -0.4535 to +0.1574 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.622e+04 | 2.617e+04 | -0.2% | -110.3 to +13.16 | STEADY, under the floor |
| power-capped share of samples | 0.7475 | 0.7477 | +0.0% | -0.005944 to +0.006366 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 5 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42 | 41.95 | -0.1% | -0.4478 to +0.3305 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.7e+04 | 2.704e+04 | +0.1% | -212.2 to +289.4 | STEADY, under the floor |
| energy per served request (J) | 23.81 | 23.84 | +0.1% | -0.1872 to +0.2552 | STEADY, under the floor |
| power, GPU mean (W) | 81.36 | 81.47 | +0.1% | -0.642 to +0.8534 | STEADY, under the floor |
| requests served | 1134 | 1134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 199.5 | 204.4 | +2.4% | +2.018 to +7.723 | LOSS, clear of the noise |
| response time, 95th percentile (ms) | 675.9 | 694.8 | +2.8% | +3.957 to +33.76 | LOSS, clear of the noise |
| response time, 99th percentile (ms) | 994.4 | 1027 | +3.3% | +10.94 to +54.79 | LOSS, clear of the noise |
| temperature, peak (C) | 54 | 53.8 | -0.4% | -0.7552 to +0.3552 | STEADY, under the floor |
| temperature, mean (C) | 48.72 | 48.65 | -0.2% | -0.1437 to -0.01461 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.617e+04 | 2.61e+04 | -0.3% | -143.7 to +3.585 | STEADY, under the floor |
| power-capped share of samples | 0.7477 | 0.7307 | -2.3% | -0.02117 to -0.01286 | GAIN, clear of the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.87 -> 41.95 served requests per kJ, difference +0.0775 (95% interval -0.397 to +0.552).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| omni | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 1 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 2 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 3 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 4 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |
| watch | 5 | 163 | 0 | n/a | n/a | 0 | 163 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 76.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*