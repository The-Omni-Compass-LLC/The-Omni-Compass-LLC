# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 53.88 | 53.52 | 53.39 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.171e+04 | 2.186e+04 | 2.191e+04 |
| energy per served request (J) | 18.56 | 18.68 | 18.73 |
| power, GPU mean (W) | 102.5 | 103.3 | 103.5 |
| requests served | 1170 | 1170 | 1170 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 154.3 | 155.1 | 156.4 |
| response time, 95th percentile (ms) | 524.7 | 524.1 | 538.1 |
| response time, 99th percentile (ms) | 772.1 | 768.9 | 778.5 |
| temperature, peak (C) | 60.67 | 61 | 61.33 |
| temperature, mean (C) | 53.79 | 54.52 | 54.58 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.156e+04 | 2.161e+04 | 2.161e+04 |
| power-capped share of samples | 0.7882 | 0.7882 | 0.7907 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.88 | 53.39 | -0.9% | -1.404 to +0.4263 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.171e+04 | 2.191e+04 | +0.9% | -172.4 to +569.9 | power given, not beyond the noise |
| energy per served request (J) | 18.56 | 18.73 | +0.9% | -0.1473 to +0.4871 | power given, not beyond the noise |
| power, GPU mean (W) | 102.5 | 103.5 | +0.9% | -0.7961 to +2.722 | power given, not beyond the noise |
| requests served | 1170 | 1170 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 154.3 | 156.4 | +1.4% | -10.75 to +14.92 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 524.7 | 538.1 | +2.5% | -60.21 to +86.96 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 772.1 | 778.5 | +0.8% | -50.95 to +63.8 | LOSS, not beyond the noise |
| temperature, peak (C) | 60.67 | 61.33 | +1.1% | -0.7677 to +2.101 | power given, not beyond the noise |
| temperature, mean (C) | 53.79 | 54.58 | +1.5% | -2.952 to +4.518 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.156e+04 | 2.161e+04 | +0.3% | -254.4 to +365.6 | STEADY, under the floor |
| power-capped share of samples | 0.7882 | 0.7907 | +0.3% | -0.008748 to +0.01367 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.88 | 53.52 | -0.7% | -1.081 to +0.362 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.171e+04 | 2.186e+04 | +0.7% | -148.5 to +440.9 | power given, not beyond the noise |
| energy per served request (J) | 18.56 | 18.68 | +0.7% | -0.127 to +0.3768 | power given, not beyond the noise |
| power, GPU mean (W) | 102.5 | 103.3 | +0.7% | -0.5905 to +2.028 | power given, not beyond the noise |
| requests served | 1170 | 1170 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 154.3 | 155.1 | +0.5% | -4.773 to +6.411 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 524.7 | 524.1 | -0.1% | -5.252 to +4.17 | STEADY, under the floor |
| response time, 99th percentile (ms) | 772.1 | 768.9 | -0.4% | -13.01 to +6.583 | STEADY, under the floor |
| temperature, peak (C) | 60.67 | 61 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 53.79 | 54.52 | +1.4% | -2.823 to +4.277 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.156e+04 | 2.161e+04 | +0.2% | -205.9 to +310.3 | STEADY, under the floor |
| power-capped share of samples | 0.7882 | 0.7882 | +0.0% | -0.01776 to +0.01776 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 53.52 | 53.39 | -0.2% | -1.448 to +1.189 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.186e+04 | 2.191e+04 | +0.2% | -487.6 to +592.8 | STEADY, under the floor |
| energy per served request (J) | 18.68 | 18.73 | +0.2% | -0.4168 to +0.5067 | STEADY, under the floor |
| power, GPU mean (W) | 103.3 | 103.5 | +0.2% | -2.29 to +2.778 | STEADY, under the floor |
| requests served | 1170 | 1170 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 155.1 | 156.4 | +0.8% | -5.999 to +8.53 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 524.1 | 538.1 | +2.7% | -55.23 to +83.06 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 768.9 | 778.5 | +1.3% | -48.62 to +67.9 | LOSS, not beyond the noise |
| temperature, peak (C) | 61 | 61.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 54.52 | 54.58 | +0.1% | -0.1341 to +0.2462 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.161e+04 | 2.161e+04 | +0.0% | -57.88 to +64.66 | STEADY, under the floor |
| power-capped share of samples | 0.7882 | 0.7907 | +0.3% | -0.006623 to +0.01154 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 53.88 -> 53.39 served requests per kJ, difference -0.4888 (95% interval -1.404 to +0.4263).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*