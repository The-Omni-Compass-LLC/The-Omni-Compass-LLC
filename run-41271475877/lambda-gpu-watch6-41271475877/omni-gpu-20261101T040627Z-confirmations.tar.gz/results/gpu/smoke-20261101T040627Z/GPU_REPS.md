# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 180.0 s per arm plus 30.0 s drain, 30.0 s idle before each arm.

Phase: **smoke**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 57.13 | 56.96 | 57.12 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 2.123e+04 | 2.13e+04 | 2.124e+04 |
| energy per served request (J) | 17.5 | 17.56 | 17.51 |
| power, GPU mean (W) | 100.2 | 100.6 | 100.3 |
| requests served | 1213 | 1213 | 1213 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 133.2 | 132.6 | 131.2 |
| response time, 95th percentile (ms) | 399.9 | 390.5 | 382.4 |
| response time, 99th percentile (ms) | 670.8 | 665.4 | 653.9 |
| temperature, peak (C) | 61 | 61.33 | 61.33 |
| temperature, mean (C) | 53.98 | 54.61 | 54.68 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 2.11e+04 | 2.113e+04 | 2.11e+04 |
| power-capped share of samples | 0.8015 | 0.8036 | 0.8027 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.13 | 57.12 | -0.0% | -1.352 to +1.328 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.123e+04 | 2.124e+04 | +0.0% | -496.4 to +506.2 | STEADY, under the floor |
| energy per served request (J) | 17.5 | 17.51 | +0.0% | -0.4092 to +0.4173 | STEADY, under the floor |
| power, GPU mean (W) | 100.2 | 100.3 | +0.1% | -2.138 to +2.254 | STEADY, under the floor |
| requests served | 1213 | 1213 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 133.2 | 131.2 | -1.5% | -7.511 to +3.463 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 399.9 | 382.4 | -4.4% | -61.39 to +26.41 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 670.8 | 653.9 | -2.5% | -54.28 to +20.52 | GAIN, not beyond the noise |
| temperature, peak (C) | 61 | 61.33 | +0.5% | -3.462 to +4.128 | power given, not beyond the noise |
| temperature, mean (C) | 53.98 | 54.68 | +1.3% | -2.73 to +4.131 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.11e+04 | 2.11e+04 | -0.0% | -228.3 to +227.4 | STEADY, under the floor |
| power-capped share of samples | 0.8015 | 0.8027 | +0.1% | -0.006099 to +0.008501 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.13 | 56.96 | -0.3% | -2.113 to +1.77 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.123e+04 | 2.13e+04 | +0.3% | -658.2 to +787 | STEADY, under the floor |
| energy per served request (J) | 17.5 | 17.56 | +0.3% | -0.5426 to +0.6488 | STEADY, under the floor |
| power, GPU mean (W) | 100.2 | 100.6 | +0.3% | -2.773 to +3.471 | STEADY, under the floor |
| requests served | 1213 | 1213 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 133.2 | 132.6 | -0.5% | -1.943 to +0.6779 | STEADY, under the floor |
| response time, 95th percentile (ms) | 399.9 | 390.5 | -2.4% | -33.21 to +14.3 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 670.8 | 665.4 | -0.8% | -36.87 to +26.24 | GAIN, not beyond the noise |
| temperature, peak (C) | 61 | 61.33 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 53.98 | 54.61 | +1.2% | -2.696 to +3.955 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.11e+04 | 2.113e+04 | +0.1% | -161.9 to +216.1 | STEADY, under the floor |
| power-capped share of samples | 0.8015 | 0.8036 | +0.3% | -0.003221 to +0.007394 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 56.96 | 57.12 | +0.3% | -1.148 to +1.467 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 2.13e+04 | 2.124e+04 | -0.3% | -544.7 to +425.7 | STEADY, under the floor |
| energy per served request (J) | 17.56 | 17.51 | -0.3% | -0.4491 to +0.351 | STEADY, under the floor |
| power, GPU mean (W) | 100.6 | 100.3 | -0.3% | -2.574 to +1.992 | STEADY, under the floor |
| requests served | 1213 | 1213 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 132.6 | 131.2 | -1.0% | -7.836 to +5.052 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 390.5 | 382.4 | -2.1% | -54.87 to +38.8 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 665.4 | 653.9 | -1.7% | -75.94 to +52.81 | GAIN, not beyond the noise |
| temperature, peak (C) | 61.33 | 61.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 54.61 | 54.68 | +0.1% | -0.4265 to +0.5683 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 2.113e+04 | 2.11e+04 | -0.1% | -91.57 to +36.44 | STEADY, under the floor |
| power-capped share of samples | 0.8036 | 0.8027 | -0.1% | -0.01242 to +0.01065 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 57.13 -> 57.12 served requests per kJ, difference -0.01165 (95% interval -1.352 to +1.328).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| omni | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 1 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 2 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |
| watch | 3 | 104 | 0 | n/a | n/a | 0 | 104 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*