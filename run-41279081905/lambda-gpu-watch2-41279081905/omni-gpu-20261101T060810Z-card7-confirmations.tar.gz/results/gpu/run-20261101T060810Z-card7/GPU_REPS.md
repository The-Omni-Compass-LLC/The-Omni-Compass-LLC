# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.05 | 37.88 | 38.26 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.605e+05 | 1.612e+05 | 1.596e+05 |
| energy per served request (J) | 26.28 | 26.4 | 26.14 |
| power, GPU mean (W) | 252.8 | 254 | 251.4 |
| requests served | 6106 | 6106 | 6106 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 92.35 | 92.28 | 92.42 |
| response time, 95th percentile (ms) | 279 | 278.1 | 277.7 |
| response time, 99th percentile (ms) | 470.1 | 469.5 | 471.3 |
| temperature, peak (C) | 78.67 | 79 | 79 |
| temperature, mean (C) | 65.04 | 65.03 | 65.07 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.6e+05 | 1.6e+05 | 1.599e+05 |
| power-capped share of samples | 0.7346 | 0.7375 | 0.7344 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.05 | 38.26 | +0.6% | -0.8787 to +1.299 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.605e+05 | 1.596e+05 | -0.5% | -5413 to +3664 | GAIN, not beyond the noise |
| energy per served request (J) | 26.28 | 26.14 | -0.5% | -0.8865 to +0.6001 | GAIN, not beyond the noise |
| power, GPU mean (W) | 252.8 | 251.4 | -0.5% | -8.663 to +6.012 | GAIN, not beyond the noise |
| requests served | 6106 | 6106 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.35 | 92.42 | +0.1% | -0.3358 to +0.4754 | STEADY, under the floor |
| response time, 95th percentile (ms) | 279 | 277.7 | -0.5% | -6.293 to +3.675 | STEADY, under the floor |
| response time, 99th percentile (ms) | 470.1 | 471.3 | +0.3% | +0.2497 to +2.221 | STEADY, under the floor |
| temperature, peak (C) | 78.67 | 79 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 65.04 | 65.07 | +0.0% | -0.3837 to +0.4385 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.6e+05 | 1.599e+05 | -0.1% | -431.4 to +191.3 | STEADY, under the floor |
| power-capped share of samples | 0.7346 | 0.7344 | -0.0% | -0.02054 to +0.0201 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.05 | 37.88 | -0.5% | -1.045 to +0.7 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.605e+05 | 1.612e+05 | +0.5% | -2946 to +4393 | STEADY, under the floor |
| energy per served request (J) | 26.28 | 26.4 | +0.5% | -0.4824 to +0.7194 | STEADY, under the floor |
| power, GPU mean (W) | 252.8 | 254 | +0.5% | -4.76 to +7.131 | STEADY, under the floor |
| requests served | 6106 | 6106 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.35 | 92.28 | -0.1% | -0.2769 to +0.1345 | STEADY, under the floor |
| response time, 95th percentile (ms) | 279 | 278.1 | -0.3% | -6.005 to +4.193 | STEADY, under the floor |
| response time, 99th percentile (ms) | 470.1 | 469.5 | -0.1% | -2.748 to +1.59 | STEADY, under the floor |
| temperature, peak (C) | 78.67 | 79 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 65.04 | 65.03 | -0.0% | -0.6693 to +0.6569 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.6e+05 | 1.6e+05 | +0.0% | -459.7 to +584.9 | STEADY, under the floor |
| power-capped share of samples | 0.7346 | 0.7375 | +0.4% | -0.009817 to +0.01563 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.88 | 38.26 | +1.0% | -0.613 to +1.378 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.612e+05 | 1.596e+05 | -1.0% | -5764 to +2568 | GAIN, not beyond the noise |
| energy per served request (J) | 26.4 | 26.14 | -1.0% | -0.944 to +0.4206 | GAIN, not beyond the noise |
| power, GPU mean (W) | 254 | 251.4 | -1.0% | -9.077 to +4.054 | GAIN, not beyond the noise |
| requests served | 6106 | 6106 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.28 | 92.42 | +0.2% | -0.3265 to +0.6085 | STEADY, under the floor |
| response time, 95th percentile (ms) | 278.1 | 277.7 | -0.1% | -4.088 to +3.283 | STEADY, under the floor |
| response time, 99th percentile (ms) | 469.5 | 471.3 | +0.4% | +0.6109 to +3.017 | STEADY, under the floor |
| temperature, peak (C) | 79 | 79 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 65.03 | 65.07 | +0.1% | -0.2982 to +0.3654 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.6e+05 | 1.599e+05 | -0.1% | -1008 to +642.2 | STEADY, under the floor |
| power-capped share of samples | 0.7375 | 0.7344 | -0.4% | -0.01874 to +0.01249 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.05 -> 38.26 served requests per kJ, difference +0.2101 (95% interval -0.8787 to +1.299).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 2 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| omni | 3 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |
| watch | 1 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*