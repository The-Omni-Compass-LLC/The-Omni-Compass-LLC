# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.55 | 43.6 | 43.36 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.32e+05 | 1.318e+05 | 1.325e+05 |
| energy per served request (J) | 22.96 | 22.94 | 23.06 |
| power, GPU mean (W) | 207.3 | 207.1 | 208.5 |
| requests served | 5747 | 5747 | 5747 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.25 | 96.18 | 96.06 |
| response time, 95th percentile (ms) | 264.6 | 264.5 | 263.9 |
| response time, 99th percentile (ms) | 451.4 | 451.4 | 450.1 |
| temperature, peak (C) | 74 | 74 | 74 |
| temperature, mean (C) | 57.89 | 57.92 | 57.96 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.323e+05 | 1.321e+05 | 1.324e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.55 | 43.36 | -0.4% | -1.42 to +1.048 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.32e+05 | 1.325e+05 | +0.4% | -3181 to +4324 | STEADY, under the floor |
| energy per served request (J) | 22.96 | 23.06 | +0.4% | -0.5535 to +0.7523 | STEADY, under the floor |
| power, GPU mean (W) | 207.3 | 208.5 | +0.6% | -5.078 to +7.391 | power given, not beyond the noise |
| requests served | 5747 | 5747 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.25 | 96.06 | -0.2% | -0.6039 to +0.2283 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.6 | 263.9 | -0.3% | -3.74 to +2.287 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.4 | 450.1 | -0.3% | -6.378 to +3.756 | STEADY, under the floor |
| temperature, peak (C) | 74 | 74 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.89 | 57.96 | +0.1% | -0.1775 to +0.3162 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.323e+05 | 1.324e+05 | +0.0% | -439.3 to +550.4 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.55 | 43.6 | +0.1% | -0.4646 to +0.5725 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.32e+05 | 1.318e+05 | -0.1% | -1736 to +1408 | STEADY, under the floor |
| energy per served request (J) | 22.96 | 22.94 | -0.1% | -0.302 to +0.2449 | STEADY, under the floor |
| power, GPU mean (W) | 207.3 | 207.1 | -0.1% | -5.07 to +4.579 | STEADY, under the floor |
| requests served | 5747 | 5747 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.25 | 96.18 | -0.1% | -0.181 to +0.04208 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.6 | 264.5 | -0.0% | -2.091 to +2.024 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.4 | 451.4 | -0.0% | -1.573 to +1.419 | STEADY, under the floor |
| temperature, peak (C) | 74 | 74 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.89 | 57.92 | +0.0% | -0.4958 to +0.5486 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.323e+05 | 1.321e+05 | -0.2% | -618.9 to +207.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.6 | 43.36 | -0.6% | -0.9681 to +0.4882 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.318e+05 | 1.325e+05 | +0.6% | -1484 to +2954 | power given, not beyond the noise |
| energy per served request (J) | 22.94 | 23.06 | +0.6% | -0.2582 to +0.514 | power given, not beyond the noise |
| power, GPU mean (W) | 207.1 | 208.5 | +0.7% | -0.04183 to +2.846 | power given, not beyond the noise |
| requests served | 5747 | 5747 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.18 | 96.06 | -0.1% | -0.6086 to +0.3719 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.5 | 263.9 | -0.3% | -2.919 to +1.533 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.4 | 450.1 | -0.3% | -5.994 to +3.527 | STEADY, under the floor |
| temperature, peak (C) | 74 | 74 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 57.92 | 57.96 | +0.1% | -0.2382 to +0.3241 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.321e+05 | 1.324e+05 | +0.2% | -461.1 to +983.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.55 -> 43.36 served requests per kJ, difference -0.186 (95% interval -1.42 to +1.048).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 4 | 0 | 0 | 0 | 0.252 | 0.269 | 0 | 20 | 3 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| omni | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| compass | 2 | 5 | -25.84 | -1 |
| race | 2 | 398 | -323.6 | -6 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*