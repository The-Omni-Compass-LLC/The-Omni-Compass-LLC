# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.4 | 43.67 | 43.51 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.328e+05 | 1.32e+05 | 1.325e+05 |
| energy per served request (J) | 23.04 | 22.9 | 22.98 |
| power, GPU mean (W) | 207.9 | 207.2 | 207.8 |
| requests served | 5763 | 5763 | 5763 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 97.18 | 97.33 | 97.17 |
| response time, 95th percentile (ms) | 269.2 | 270.1 | 269.2 |
| response time, 99th percentile (ms) | 458.7 | 460.1 | 458.2 |
| temperature, peak (C) | 72 | 72 | 72 |
| temperature, mean (C) | 55.63 | 55.65 | 55.67 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.33e+05 | 1.326e+05 | 1.329e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.4 | 43.51 | +0.3% | -0.5202 to +0.7463 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.328e+05 | 1.325e+05 | -0.3% | -2276 to +1587 | STEADY, under the floor |
| energy per served request (J) | 23.04 | 22.98 | -0.3% | -0.3949 to +0.2753 | STEADY, under the floor |
| power, GPU mean (W) | 207.9 | 207.8 | -0.1% | -3.504 to +3.28 | STEADY, under the floor |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 97.18 | 97.17 | -0.0% | -0.9293 to +0.9087 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.2 | 269.2 | +0.0% | -3.731 to +3.849 | STEADY, under the floor |
| response time, 99th percentile (ms) | 458.7 | 458.2 | -0.1% | -11.93 to +10.74 | STEADY, under the floor |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.63 | 55.67 | +0.1% | -0.1276 to +0.2172 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.33e+05 | 1.329e+05 | -0.1% | -175.4 to +28.04 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.4 | 43.67 | +0.6% | -0.1063 to +0.6505 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.328e+05 | 1.32e+05 | -0.6% | -1984 to +327.2 | GAIN, not beyond the noise |
| energy per served request (J) | 23.04 | 22.9 | -0.6% | -0.3443 to +0.05677 | GAIN, not beyond the noise |
| power, GPU mean (W) | 207.9 | 207.2 | -0.4% | -3.383 to +1.867 | STEADY, under the floor |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 97.18 | 97.33 | +0.2% | -0.4766 to +0.7814 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.2 | 270.1 | +0.4% | -2.124 to +4.01 | STEADY, under the floor |
| response time, 99th percentile (ms) | 458.7 | 460.1 | +0.3% | -5.51 to +8.187 | STEADY, under the floor |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.63 | 55.65 | +0.0% | -0.3956 to +0.4321 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.33e+05 | 1.326e+05 | -0.2% | -985.6 to +335.1 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.67 | 43.51 | -0.4% | -0.5368 to +0.2187 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.32e+05 | 1.325e+05 | +0.4% | -668.6 to +1637 | STEADY, under the floor |
| energy per served request (J) | 22.9 | 22.98 | +0.4% | -0.116 to +0.284 | STEADY, under the floor |
| power, GPU mean (W) | 207.2 | 207.8 | +0.3% | -2.284 to +3.576 | STEADY, under the floor |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 97.33 | 97.17 | -0.2% | -0.5935 to +0.2681 | STEADY, under the floor |
| response time, 95th percentile (ms) | 270.1 | 269.2 | -0.3% | -1.703 to -0.06584 | STEADY, under the floor |
| response time, 99th percentile (ms) | 460.1 | 458.2 | -0.4% | -7.671 to +3.798 | STEADY, under the floor |
| temperature, peak (C) | 72 | 72 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.65 | 55.67 | +0.0% | -0.2215 to +0.2746 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.326e+05 | 1.329e+05 | +0.2% | -510.5 to +1014 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.4 -> 43.51 served requests per kJ, difference +0.1131 (95% interval -0.5202 to +0.7463).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.205 | 0.299 | 0 | 162 | 31 | True |
| omni | 2 | 6 | 0 | 0 | 0 | 0.212 | 0.251 | 0 | 30 | 5 | True |
| omni | 3 | 36 | 0 | 0 | 0 | 0.204 | 0.3 | 0 | 112 | 35 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 2 | 43 | +27.67 | +0 |
| compass | 37 | 689 | +73.54 | +114 |
| fail_up | 3 | 17 | +160.5 | -13 |
| race | 32 | 479 | -684.8 | -159 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 74.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*