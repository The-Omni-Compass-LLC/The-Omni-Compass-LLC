# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.05 | 37.74 | 37.95 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.583e+05 | 1.597e+05 | 1.588e+05 |
| energy per served request (J) | 26.28 | 26.5 | 26.35 |
| power, GPU mean (W) | 248.6 | 250.9 | 249.2 |
| requests served | 6025 | 6025 | 6025 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 92.09 | 92.1 | 92.18 |
| response time, 95th percentile (ms) | 272.7 | 273.4 | 272.9 |
| response time, 99th percentile (ms) | 473.2 | 472.5 | 473.4 |
| temperature, peak (C) | 76.33 | 76 | 76.33 |
| temperature, mean (C) | 62.16 | 62.12 | 62.17 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.589e+05 | 1.589e+05 | 1.589e+05 |
| power-capped share of samples | 0.7268 | 0.7302 | 0.7277 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.05 | 37.95 | -0.3% | -0.7345 to +0.5366 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.583e+05 | 1.588e+05 | +0.3% | -2239 to +3050 | STEADY, under the floor |
| energy per served request (J) | 26.28 | 26.35 | +0.3% | -0.3716 to +0.5063 | STEADY, under the floor |
| power, GPU mean (W) | 248.6 | 249.2 | +0.2% | -2.992 to +4.094 | STEADY, under the floor |
| requests served | 6025 | 6025 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.09 | 92.18 | +0.1% | -0.5792 to +0.7589 | STEADY, under the floor |
| response time, 95th percentile (ms) | 272.7 | 272.9 | +0.1% | -3.312 to +3.83 | STEADY, under the floor |
| response time, 99th percentile (ms) | 473.2 | 473.4 | +0.0% | -5.589 to +5.854 | STEADY, under the floor |
| temperature, peak (C) | 76.33 | 76.33 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 62.16 | 62.17 | +0.0% | -0.3638 to +0.3882 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.589e+05 | 1.589e+05 | +0.0% | -675.9 to +821.3 | STEADY, under the floor |
| power-capped share of samples | 0.7268 | 0.7277 | +0.1% | -0.004812 to +0.006586 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.05 | 37.74 | -0.8% | -1.158 to +0.53 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.583e+05 | 1.597e+05 | +0.8% | -2213 to +4832 | power given, not beyond the noise |
| energy per served request (J) | 26.28 | 26.5 | +0.8% | -0.3673 to +0.802 | power given, not beyond the noise |
| power, GPU mean (W) | 248.6 | 250.9 | +0.9% | -3.185 to +7.713 | power given, not beyond the noise |
| requests served | 6025 | 6025 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.09 | 92.1 | +0.0% | -0.7847 to +0.8063 | STEADY, under the floor |
| response time, 95th percentile (ms) | 272.7 | 273.4 | +0.3% | -4.981 to +6.346 | STEADY, under the floor |
| response time, 99th percentile (ms) | 473.2 | 472.5 | -0.2% | -5.604 to +4.072 | STEADY, under the floor |
| temperature, peak (C) | 76.33 | 76 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 62.16 | 62.12 | -0.1% | -0.601 to +0.5354 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.589e+05 | 1.589e+05 | +0.0% | -175.6 to +274.8 | STEADY, under the floor |
| power-capped share of samples | 0.7268 | 0.7302 | +0.5% | -0.004539 to +0.01146 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 37.74 | 37.95 | +0.6% | -0.05129 to +0.4811 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.597e+05 | 1.588e+05 | -0.6% | -2022 to +214.8 | GAIN, not beyond the noise |
| energy per served request (J) | 26.5 | 26.35 | -0.6% | -0.3357 to +0.03565 | GAIN, not beyond the noise |
| power, GPU mean (W) | 250.9 | 249.2 | -0.7% | -3.623 to +0.1981 | GAIN, not beyond the noise |
| requests served | 6025 | 6025 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 92.1 | 92.18 | +0.1% | -0.3262 to +0.4843 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273.4 | 272.9 | -0.2% | -7.23 to +6.382 | STEADY, under the floor |
| response time, 99th percentile (ms) | 472.5 | 473.4 | +0.2% | -1.656 to +3.453 | STEADY, under the floor |
| temperature, peak (C) | 76 | 76.33 | +0.4% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 62.12 | 62.17 | +0.1% | -0.2717 to +0.3616 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.589e+05 | 1.589e+05 | +0.0% | -651.1 to +697.2 | STEADY, under the floor |
| power-capped share of samples | 0.7302 | 0.7277 | -0.4% | -0.01606 to +0.01092 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.05 -> 37.95 served requests per kJ, difference -0.09897 (95% interval -0.7345 to +0.5366).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 3 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*