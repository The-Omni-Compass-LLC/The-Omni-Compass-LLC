# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.01 | 44.95 | 45.09 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.28e+05 | 1.282e+05 | 1.278e+05 |
| energy per served request (J) | 22.22 | 22.25 | 22.18 |
| power, GPU mean (W) | 201.2 | 201.2 | 201.1 |
| requests served | 5760 | 5760 | 5760 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.55 | 96.68 | 96.59 |
| response time, 95th percentile (ms) | 267.2 | 268 | 267.4 |
| response time, 99th percentile (ms) | 451.4 | 452.7 | 451.4 |
| temperature, peak (C) | 65 | 65 | 65 |
| temperature, mean (C) | 52.47 | 52.45 | 52.43 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.281e+05 | 1.281e+05 | 1.279e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.01 | 45.09 | +0.2% | -0.5007 to +0.6429 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.28e+05 | 1.278e+05 | -0.2% | -1838 to +1431 | STEADY, under the floor |
| energy per served request (J) | 22.22 | 22.18 | -0.2% | -0.3191 to +0.2484 | STEADY, under the floor |
| power, GPU mean (W) | 201.2 | 201.1 | -0.0% | -2.894 to +2.718 | STEADY, under the floor |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.55 | 96.59 | +0.0% | -0.3764 to +0.4537 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.2 | 267.4 | +0.1% | -3.014 to +3.307 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.4 | 451.4 | +0.0% | -4.312 to +4.477 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 52.47 | 52.43 | -0.1% | -0.2283 to +0.1506 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.281e+05 | 1.279e+05 | -0.2% | -645.8 to +256.9 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.01 | 44.95 | -0.1% | -0.9638 to +0.8293 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.28e+05 | 1.282e+05 | +0.1% | -2357 to +2731 | STEADY, under the floor |
| energy per served request (J) | 22.22 | 22.25 | +0.1% | -0.4092 to +0.4742 | STEADY, under the floor |
| power, GPU mean (W) | 201.2 | 201.2 | +0.0% | -4.532 to +4.541 | STEADY, under the floor |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.55 | 96.68 | +0.1% | -0.1177 to +0.3678 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.2 | 268 | +0.3% | -1.891 to +3.395 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.4 | 452.7 | +0.3% | +0.3804 to +2.304 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 52.47 | 52.45 | -0.0% | -0.1174 to +0.0734 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.281e+05 | 1.281e+05 | -0.0% | -389.1 to +279.6 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 44.95 | 45.09 | +0.3% | -0.6682 to +0.9448 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.282e+05 | 1.278e+05 | -0.3% | -2677 to +1896 | STEADY, under the floor |
| energy per served request (J) | 22.25 | 22.18 | -0.3% | -0.4648 to +0.3292 | STEADY, under the floor |
| power, GPU mean (W) | 201.2 | 201.1 | -0.0% | -4.87 to +4.685 | STEADY, under the floor |
| requests served | 5760 | 5760 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.68 | 96.59 | -0.1% | -0.3845 to +0.2118 | STEADY, under the floor |
| response time, 95th percentile (ms) | 268 | 267.4 | -0.2% | -3.196 to +1.986 | STEADY, under the floor |
| response time, 99th percentile (ms) | 452.7 | 451.4 | -0.3% | -4.905 to +2.386 | STEADY, under the floor |
| temperature, peak (C) | 65 | 65 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 52.45 | 52.43 | -0.0% | -0.1254 to +0.09174 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.281e+05 | 1.279e+05 | -0.1% | -370.9 to +91.5 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.01 -> 45.09 served requests per kJ, difference +0.07106 (95% interval -0.5007 to +0.6429).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 26 | 0 | 0 | 0 | 0.206 | 0.259 | 0 | 350 | 25 | True |
| omni | 2 | 30 | 0 | 0 | 0 | 0.198 | 0.268 | 0 | 536 | 29 | True |
| omni | 3 | 30 | 0 | 0 | 0 | 0.204 | 0.298 | 0 | 524 | 29 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 64 | +8.656 | +0 |
| compass | 43 | 990 | -2489 | +25 |
| race | 40 | 139 | +564.5 | -70 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 86.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*