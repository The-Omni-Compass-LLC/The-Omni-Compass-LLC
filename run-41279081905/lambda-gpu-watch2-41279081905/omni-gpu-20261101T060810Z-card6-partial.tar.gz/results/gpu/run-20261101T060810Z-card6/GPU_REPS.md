# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.55 | 38.7 | 38.7 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.583e+05 | 1.577e+05 | 1.577e+05 |
| energy per served request (J) | 25.94 | 25.84 | 25.84 |
| power, GPU mean (W) | 249.5 | 248.1 | 248.5 |
| requests served | 6102 | 6102 | 6102 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 91.97 | 91.94 | 92 |
| response time, 95th percentile (ms) | 273 | 273.6 | 273.4 |
| response time, 99th percentile (ms) | 466.6 | 466.1 | 464.6 |
| temperature, peak (C) | 71.33 | 71.33 | 71.33 |
| temperature, mean (C) | 58.79 | 58.74 | 58.77 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.58e+05 | 1.582e+05 | 1.58e+05 |
| power-capped share of samples | 0.7369 | 0.7327 | 0.7368 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.55 | 38.7 | +0.4% | -1.314 to +1.62 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.583e+05 | 1.577e+05 | -0.4% | -6659 to +5399 | STEADY, under the floor |
| energy per served request (J) | 25.94 | 25.84 | -0.4% | -1.091 to +0.8847 | STEADY, under the floor |
| power, GPU mean (W) | 249.5 | 248.5 | -0.4% | -10.78 to +8.713 | STEADY, under the floor |
| requests served | 6102 | 6102 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.97 | 92 | +0.0% | -0.2982 to +0.3626 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273 | 273.4 | +0.2% | -1.821 to +2.649 | STEADY, under the floor |
| response time, 99th percentile (ms) | 466.6 | 464.6 | -0.4% | -9.361 to +5.381 | STEADY, under the floor |
| temperature, peak (C) | 71.33 | 71.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 58.79 | 58.77 | -0.0% | -0.4815 to +0.4426 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.58e+05 | 1.58e+05 | +0.0% | -659.9 to +735.9 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7368 | -0.0% | -0.001596 to +0.001461 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.55 | 38.7 | +0.4% | -0.4914 to +0.8052 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.583e+05 | 1.577e+05 | -0.4% | -3318 to +2023 | STEADY, under the floor |
| energy per served request (J) | 25.94 | 25.84 | -0.4% | -0.5437 to +0.3316 | STEADY, under the floor |
| power, GPU mean (W) | 249.5 | 248.1 | -0.6% | -4.212 to +1.307 | GAIN, not beyond the noise |
| requests served | 6102 | 6102 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.97 | 91.94 | -0.0% | -0.3208 to +0.2616 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273 | 273.6 | +0.2% | -4.576 to +5.913 | STEADY, under the floor |
| response time, 99th percentile (ms) | 466.6 | 466.1 | -0.1% | -4.972 to +3.995 | STEADY, under the floor |
| temperature, peak (C) | 71.33 | 71.33 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 58.79 | 58.74 | -0.1% | -0.2444 to +0.1422 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.58e+05 | 1.582e+05 | +0.1% | +33.9 to +312.2 | STEADY, under the floor |
| power-capped share of samples | 0.7369 | 0.7327 | -0.6% | -0.01961 to +0.01119 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.7 | 38.7 | -0.0% | -1.268 to +1.259 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.577e+05 | 1.577e+05 | +0.0% | -5130 to +5164 | STEADY, under the floor |
| energy per served request (J) | 25.84 | 25.84 | +0.0% | -0.8407 to +0.8462 | STEADY, under the floor |
| power, GPU mean (W) | 248.1 | 248.5 | +0.2% | -7.757 to +8.592 | STEADY, under the floor |
| requests served | 6102 | 6102 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.94 | 92 | +0.1% | +0.01866 to +0.105 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273.6 | 273.4 | -0.1% | -3.525 to +3.016 | STEADY, under the floor |
| response time, 99th percentile (ms) | 466.1 | 464.6 | -0.3% | -9.062 to +6.059 | STEADY, under the floor |
| temperature, peak (C) | 71.33 | 71.33 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 58.74 | 58.77 | +0.1% | -0.2483 to +0.3116 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.582e+05 | 1.58e+05 | -0.1% | -783.4 to +513.3 | STEADY, under the floor |
| power-capped share of samples | 0.7327 | 0.7368 | +0.6% | -0.01137 to +0.01965 | power given, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.55 -> 38.7 served requests per kJ, difference +0.1526 (95% interval -1.314 to +1.62).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 3 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 1 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| watch | 2 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| watch | 3 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*