# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.5 | 42.79 | 43.77 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.17e+04 | 6.273e+04 | 6.133e+04 |
| energy per served request (J) | 22.99 | 23.37 | 22.85 |
| power, GPU mean (W) | 183.4 | 187.2 | 182.6 |
| requests served | 2684 | 2684 | 2684 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 109.1 | 109.5 | 109.1 |
| response time, 95th percentile (ms) | 350.6 | 356.1 | 348.7 |
| response time, 99th percentile (ms) | 623.4 | 630.4 | 628.7 |
| temperature, peak (C) | 66 | 66.5 | 65 |
| temperature, mean (C) | 54.98 | 54.99 | 54.98 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.195e+04 | 6.191e+04 | 6.158e+04 |
| power-capped share of samples | 0.672 | 0.6853 | 0.6584 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.5 | 43.77 | +0.6% | -6.521 to +7.045 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.17e+04 | 6.133e+04 | -0.6% | -9892 to +9164 | GAIN, not beyond the noise |
| energy per served request (J) | 22.99 | 22.85 | -0.6% | -3.685 to +3.414 | GAIN, not beyond the noise |
| power, GPU mean (W) | 183.4 | 182.6 | -0.5% | -28.4 to +26.65 | STEADY, under the floor |
| requests served | 2684 | 2684 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.1 | 109.1 | -0.0% | -9.851 to +9.777 | STEADY, under the floor |
| response time, 95th percentile (ms) | 350.6 | 348.7 | -0.5% | -106.7 to +102.8 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 623.4 | 628.7 | +0.9% | +0.1577 to +10.5 | LOSS, clear of the noise |
| temperature, peak (C) | 66 | 65 | -1.5% | -1 to -1 | GAIN, clear of the noise |
| temperature, mean (C) | 54.98 | 54.98 | +0.0% | -0.8268 to +0.83 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.195e+04 | 6.158e+04 | -0.6% | -1021 to +287.3 | GAIN, not beyond the noise |
| power-capped share of samples | 0.672 | 0.6584 | -2.0% | -0.05462 to +0.02729 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.5 | 42.79 | -1.6% | -0.8397 to -0.5896 | power given, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.17e+04 | 6.273e+04 | +1.7% | +909.8 to +1151 | power given, clear of the noise |
| energy per served request (J) | 22.99 | 23.37 | +1.7% | +0.339 to +0.4288 | power given, clear of the noise |
| power, GPU mean (W) | 183.4 | 187.2 | +2.0% | -6.41 to +13.9 | power given, not beyond the noise |
| requests served | 2684 | 2684 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.1 | 109.5 | +0.3% | -7.84 to +8.603 | STEADY, under the floor |
| response time, 95th percentile (ms) | 350.6 | 356.1 | +1.6% | -16.38 to +27.38 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 623.4 | 630.4 | +1.1% | -47.71 to +61.88 | LOSS, not beyond the noise |
| temperature, peak (C) | 66 | 66.5 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 54.98 | 54.99 | +0.0% | -1.051 to +1.069 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.195e+04 | 6.191e+04 | -0.1% | -1493 to +1427 | STEADY, under the floor |
| power-capped share of samples | 0.672 | 0.6853 | +2.0% | -0.01964 to +0.04628 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.79 | 43.77 | +2.3% | -5.681 to +7.635 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.273e+04 | 6.133e+04 | -2.2% | -1.08e+04 to +8013 | GAIN, not beyond the noise |
| energy per served request (J) | 23.37 | 22.85 | -2.2% | -4.024 to +2.985 | GAIN, not beyond the noise |
| power, GPU mean (W) | 187.2 | 182.6 | -2.5% | -42.3 to +33.06 | GAIN, not beyond the noise |
| requests served | 2684 | 2684 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 109.5 | 109.1 | -0.4% | -18.45 to +17.62 | STEADY, under the floor |
| response time, 95th percentile (ms) | 356.1 | 348.7 | -2.1% | -134 to +119.2 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 630.4 | 628.7 | -0.3% | -61.72 to +58.21 | STEADY, under the floor |
| temperature, peak (C) | 66.5 | 65 | -2.3% | -7.853 to +4.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 54.99 | 54.98 | -0.0% | -1.896 to +1.881 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.191e+04 | 6.158e+04 | -0.5% | -2448 to +1780 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6853 | 0.6584 | -3.9% | -0.1009 to +0.04693 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.5 -> 43.77 served requests per kJ, difference +0.2622 (95% interval -6.521 to +7.045).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, clear of the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: NOT ATTRIBUTABLE: WATCH DIFFERS FROM NATIVE.**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 144 | 0 | n/a | n/a | 0 | 144 | 0 |
| watch | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 18.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*