# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 62.95 | 62.8 | 62.81 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.273e+04 | 9.277e+04 | 9.269e+04 |
| energy per served request (J) | 15.89 | 15.92 | 15.92 |
| power, GPU mean (W) | 275 | 275.6 | 275.3 |
| requests served | 5838 | 5826 | 5822 |
| requests not served | 1296 | 1307 | 1312 |
| response time, mean (ms) | 4.115e+04 | 4.137e+04 | 4.153e+04 |
| response time, 95th percentile (ms) | 7.929e+04 | 7.982e+04 | 8.004e+04 |
| response time, 99th percentile (ms) | 8.165e+04 | 8.218e+04 | 8.239e+04 |
| temperature, peak (C) | 72.5 | 73 | 72.5 |
| temperature, mean (C) | 68.37 | 69.2 | 69.26 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.285e+04 | 9.283e+04 | 9.276e+04 |
| power-capped share of samples | 0.9806 | 0.9827 | 0.9556 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.95 | 62.81 | -0.2% | -1.955 to +1.67 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.273e+04 | 9.269e+04 | -0.0% | -92.38 to +4.568 | STEADY, under the floor |
| energy per served request (J) | 15.89 | 15.92 | +0.2% | -0.4218 to +0.4939 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 275.3 | +0.1% | -4.751 to +5.257 | STEADY, under the floor |
| requests served | 5838 | 5822 | -0.3% | -181.2 to +149.2 | STEADY, under the floor |
| requests not served | 1296 | 1312 | +1.2% | -149.2 to +181.2 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.115e+04 | 4.153e+04 | +0.9% | -3030 to +3774 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.929e+04 | 8.004e+04 | +0.9% | -6444 to +7944 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.165e+04 | 8.239e+04 | +0.9% | -6329 to +7810 | LOSS, not beyond the noise |
| temperature, peak (C) | 72.5 | 72.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 68.37 | 69.26 | +1.3% | -10.14 to +11.93 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.285e+04 | 9.276e+04 | -0.1% | -424.6 to +237.4 | STEADY, under the floor |
| power-capped share of samples | 0.9806 | 0.9556 | -2.5% | -0.3801 to +0.3301 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.95 | 62.8 | -0.2% | -2.304 to +2.009 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.273e+04 | 9.277e+04 | +0.0% | -218.5 to +287.8 | STEADY, under the floor |
| energy per served request (J) | 15.89 | 15.92 | +0.2% | -0.5078 to +0.5822 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 275.6 | +0.2% | -6.898 to +8.076 | STEADY, under the floor |
| requests served | 5838 | 5826 | -0.2% | -195.7 to +172.7 | STEADY, under the floor |
| requests not served | 1296 | 1307 | +0.9% | -172.7 to +195.7 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.115e+04 | 4.137e+04 | +0.5% | -4011 to +4447 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.929e+04 | 7.982e+04 | +0.7% | -7731 to +8789 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.165e+04 | 8.218e+04 | +0.7% | -7934 to +8997 | LOSS, not beyond the noise |
| temperature, peak (C) | 72.5 | 73 | +0.7% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 68.37 | 69.2 | +1.2% | -9.853 to +11.51 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.285e+04 | 9.283e+04 | -0.0% | -628.4 to +581.7 | STEADY, under the floor |
| power-capped share of samples | 0.9806 | 0.9827 | +0.2% | -0.02433 to +0.02845 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 62.8 | 62.81 | +0.0% | -0.339 to +0.3483 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.277e+04 | 9.269e+04 | -0.1% | -283.2 to +126.1 | STEADY, under the floor |
| energy per served request (J) | 15.92 | 15.92 | -0.0% | -0.08833 to +0.08595 | STEADY, under the floor |
| power, GPU mean (W) | 275.6 | 275.3 | -0.1% | -2.82 to +2.148 | STEADY, under the floor |
| requests served | 5826 | 5822 | -0.1% | -23.56 to +14.56 | STEADY, under the floor |
| requests not served | 1307 | 1312 | +0.3% | -14.56 to +23.56 | STEADY, under the floor |
| response time, mean (ms) | 4.137e+04 | 4.153e+04 | +0.4% | -672.8 to +980.4 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.982e+04 | 8.004e+04 | +0.3% | -845.2 to +1287 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.218e+04 | 8.239e+04 | +0.3% | -1187 to +1605 | STEADY, under the floor |
| temperature, peak (C) | 73 | 72.5 | -0.7% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 69.2 | 69.26 | +0.1% | -0.2898 to +0.4224 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.283e+04 | 9.276e+04 | -0.1% | -1006 to +865.8 | STEADY, under the floor |
| power-capped share of samples | 0.9827 | 0.9556 | -2.8% | -0.3557 to +0.3016 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 62.95 -> 62.81 served requests per kJ, difference -0.1427 (95% interval -1.955 to +1.67).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*