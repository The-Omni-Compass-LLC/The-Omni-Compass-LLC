# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 57.48 | 57.66 | 57.58 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.259e+04 | 9.269e+04 | 9.257e+04 |
| energy per served request (J) | 17.4 | 17.34 | 17.37 |
| power, GPU mean (W) | 276.1 | 276.4 | 276.2 |
| requests served | 5322 | 5344 | 5330 |
| requests not served | 1226 | 1204 | 1218 |
| response time, mean (ms) | 4.258e+04 | 4.2e+04 | 4.241e+04 |
| response time, 95th percentile (ms) | 8.166e+04 | 8.07e+04 | 8.128e+04 |
| response time, 99th percentile (ms) | 8.569e+04 | 8.491e+04 | 8.545e+04 |
| temperature, peak (C) | 70 | 70 | 70 |
| temperature, mean (C) | 67.3 | 66.63 | 67.31 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.273e+04 | 9.269e+04 | 9.262e+04 |
| power-capped share of samples | 0.9854 | 0.9845 | 0.9832 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.48 | 57.58 | +0.2% | -0.1694 to +0.3542 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.259e+04 | 9.257e+04 | -0.0% | -1434 to +1397 | STEADY, under the floor |
| energy per served request (J) | 17.4 | 17.37 | -0.2% | -0.1073 to +0.05139 | STEADY, under the floor |
| power, GPU mean (W) | 276.1 | 276.2 | +0.0% | -1.629 to +1.811 | STEADY, under the floor |
| requests served | 5322 | 5330 | +0.1% | -49.68 to +64.68 | STEADY, under the floor |
| requests not served | 1226 | 1218 | -0.6% | -64.68 to +49.68 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.258e+04 | 4.241e+04 | -0.4% | -1119 to +785.4 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.166e+04 | 8.128e+04 | -0.5% | -2964 to +2207 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.569e+04 | 8.545e+04 | -0.3% | -1551 to +1057 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 67.3 | 67.31 | +0.0% | +0.01099 to +0.02223 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.273e+04 | 9.262e+04 | -0.1% | -1194 to +967 | STEADY, under the floor |
| power-capped share of samples | 0.9854 | 0.9832 | -0.2% | -0.02895 to +0.02465 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.48 | 57.66 | +0.3% | -2.4 to +2.747 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.259e+04 | 9.269e+04 | +0.1% | -728.6 to +916.3 | STEADY, under the floor |
| energy per served request (J) | 17.4 | 17.34 | -0.3% | -0.8257 to +0.7214 | STEADY, under the floor |
| power, GPU mean (W) | 276.1 | 276.4 | +0.1% | -3.177 to +3.705 | STEADY, under the floor |
| requests served | 5322 | 5344 | +0.4% | -264.4 to +307.4 | STEADY, under the floor |
| requests not served | 1226 | 1204 | -1.8% | -307.4 to +264.4 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.258e+04 | 4.2e+04 | -1.4% | -7939 to +6789 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.166e+04 | 8.07e+04 | -1.2% | -1.365e+04 to +1.172e+04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.569e+04 | 8.491e+04 | -0.9% | -1.154e+04 to +9975 | GAIN, not beyond the noise |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 67.3 | 66.63 | -1.0% | -9.556 to +8.222 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.273e+04 | 9.269e+04 | -0.0% | -295.6 to +209.6 | STEADY, under the floor |
| power-capped share of samples | 0.9854 | 0.9845 | -0.1% | -0.004794 to +0.002948 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 57.66 | 57.58 | -0.1% | -2.917 to +2.754 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.269e+04 | 9.257e+04 | -0.1% | -705 to +480.5 | STEADY, under the floor |
| energy per served request (J) | 17.34 | 17.37 | +0.1% | -0.8287 to +0.8771 | STEADY, under the floor |
| power, GPU mean (W) | 276.4 | 276.2 | -0.1% | -5.334 to +4.988 | STEADY, under the floor |
| requests served | 5344 | 5330 | -0.3% | -242.7 to +214.7 | STEADY, under the floor |
| requests not served | 1204 | 1218 | +1.2% | -214.7 to +242.7 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.2e+04 | 4.241e+04 | +1.0% | -6004 to +6820 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.07e+04 | 8.128e+04 | +0.7% | -9517 to +1.068e+04 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.491e+04 | 8.545e+04 | +0.6% | -8918 to +9986 | LOSS, not beyond the noise |
| temperature, peak (C) | 70 | 70 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 66.63 | 67.31 | +1.0% | -8.211 to +9.578 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.269e+04 | 9.262e+04 | -0.1% | -898.6 to +757.4 | STEADY, under the floor |
| power-capped share of samples | 0.9845 | 0.9832 | -0.1% | -0.0319 to +0.02944 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 57.48 -> 57.58 served requests per kJ, difference +0.09243 (95% interval -0.1694 to +0.3542).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*