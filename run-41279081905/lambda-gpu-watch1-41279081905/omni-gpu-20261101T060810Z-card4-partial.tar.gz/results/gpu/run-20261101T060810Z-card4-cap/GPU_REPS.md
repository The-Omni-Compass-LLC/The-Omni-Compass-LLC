# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.6 | 39.21 | 39.41 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.094e+04 | 6.157e+04 | 6.123e+04 |
| energy per served request (J) | 25.26 | 25.52 | 25.37 |
| power, GPU mean (W) | 181.8 | 182.9 | 182.7 |
| requests served | 2413 | 2413 | 2413 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 122.6 | 125.5 | 125.6 |
| response time, 95th percentile (ms) | 414.3 | 439.2 | 430.3 |
| response time, 99th percentile (ms) | 723.7 | 726.9 | 734.4 |
| temperature, peak (C) | 64 | 64.5 | 64 |
| temperature, mean (C) | 53.25 | 53.18 | 53.06 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.163e+04 | 6.166e+04 | 6.116e+04 |
| power-capped share of samples | 0.6757 | 0.6652 | 0.6373 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.6 | 39.41 | -0.5% | -4.035 to +3.656 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.094e+04 | 6.123e+04 | +0.5% | -5595 to +6164 | STEADY, under the floor |
| energy per served request (J) | 25.26 | 25.37 | +0.5% | -2.319 to +2.554 | STEADY, under the floor |
| power, GPU mean (W) | 181.8 | 182.7 | +0.5% | -18.97 to +20.67 | STEADY, under the floor |
| requests served | 2413 | 2413 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 122.6 | 125.6 | +2.4% | -25.02 to +30.99 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 414.3 | 430.3 | +3.9% | -217.2 to +249.2 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 723.7 | 734.4 | +1.5% | -71.64 to +93.12 | LOSS, not beyond the noise |
| temperature, peak (C) | 64 | 64 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 53.25 | 53.06 | -0.4% | -1.787 to +1.4 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.163e+04 | 6.116e+04 | -0.8% | -969.3 to +34.3 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6757 | 0.6373 | -5.7% | -0.1834 to +0.1066 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.6 | 39.21 | -1.0% | -3.681 to +2.889 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.094e+04 | 6.157e+04 | +1.0% | -4733 to +5990 | power given, not beyond the noise |
| energy per served request (J) | 25.26 | 25.52 | +1.0% | -1.961 to +2.483 | power given, not beyond the noise |
| power, GPU mean (W) | 181.8 | 182.9 | +0.6% | -7.085 to +9.126 | power given, not beyond the noise |
| requests served | 2413 | 2413 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 122.6 | 125.5 | +2.4% | -6.914 to +12.85 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 414.3 | 439.2 | +6.0% | -90.04 to +139.8 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 723.7 | 726.9 | +0.4% | -124.5 to +130.9 | STEADY, under the floor |
| temperature, peak (C) | 64 | 64.5 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 53.25 | 53.18 | -0.1% | -0.4904 to +0.3514 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.163e+04 | 6.166e+04 | +0.0% | -1858 to +1917 | STEADY, under the floor |
| power-capped share of samples | 0.6757 | 0.6652 | -1.6% | -0.01848 to -0.0025 | GAIN, clear of the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.21 | 39.41 | +0.5% | -6.924 to +7.337 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.157e+04 | 6.123e+04 | -0.6% | -1.159e+04 to +1.09e+04 | GAIN, not beyond the noise |
| energy per served request (J) | 25.52 | 25.37 | -0.6% | -4.801 to +4.516 | GAIN, not beyond the noise |
| power, GPU mean (W) | 182.9 | 182.7 | -0.1% | -28.1 to +27.75 | STEADY, under the floor |
| requests served | 2413 | 2413 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 125.5 | 125.6 | +0.0% | -18.11 to +18.14 | STEADY, under the floor |
| response time, 95th percentile (ms) | 439.2 | 430.3 | -2.0% | -127.2 to +109.4 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 726.9 | 734.4 | +1.0% | -37.77 to +52.88 | LOSS, not beyond the noise |
| temperature, peak (C) | 64.5 | 64 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 53.18 | 53.06 | -0.2% | -2.139 to +1.89 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.166e+04 | 6.116e+04 | -0.8% | -2886 to +1892 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6652 | 0.6373 | -4.2% | -0.1649 to +0.1091 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.6 -> 39.41 served requests per kJ, difference -0.1894 (95% interval -4.035 to +3.656).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*