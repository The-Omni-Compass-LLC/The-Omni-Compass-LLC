# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.53 | 47.37 | 47.64 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.213e+05 | 1.217e+05 | 1.21e+05 |
| energy per served request (J) | 21.04 | 21.11 | 20.99 |
| power, GPU mean (W) | 190 | 191.1 | 189.7 |
| requests served | 5766 | 5766 | 5766 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 97.19 | 96.97 | 97.04 |
| response time, 95th percentile (ms) | 270.8 | 269.8 | 270.3 |
| response time, 99th percentile (ms) | 459.2 | 457.2 | 457.9 |
| temperature, peak (C) | 59 | 59 | 59 |
| temperature, mean (C) | 47.82 | 47.84 | 47.84 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.216e+05 | 1.215e+05 | 1.215e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.53 | 47.64 | +0.2% | -0.2051 to +0.4266 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.213e+05 | 1.21e+05 | -0.2% | -1088 to +523.6 | STEADY, under the floor |
| energy per served request (J) | 21.04 | 20.99 | -0.2% | -0.1887 to +0.0908 | STEADY, under the floor |
| power, GPU mean (W) | 190 | 189.7 | -0.1% | -1.753 to +1.247 | STEADY, under the floor |
| requests served | 5766 | 5766 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 97.19 | 97.04 | -0.2% | -0.3386 to +0.02784 | STEADY, under the floor |
| response time, 95th percentile (ms) | 270.8 | 270.3 | -0.2% | -1.631 to +0.6668 | STEADY, under the floor |
| response time, 99th percentile (ms) | 459.2 | 457.9 | -0.3% | -2.451 to -0.06554 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.82 | 47.84 | +0.0% | -0.1093 to +0.1317 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.216e+05 | 1.215e+05 | -0.1% | -665.6 to +492 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.53 | 47.37 | -0.3% | -0.9042 to +0.599 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.213e+05 | 1.217e+05 | +0.3% | -1534 to +2318 | STEADY, under the floor |
| energy per served request (J) | 21.04 | 21.11 | +0.3% | -0.266 to +0.4021 | STEADY, under the floor |
| power, GPU mean (W) | 190 | 191.1 | +0.6% | -3.357 to +5.589 | power given, not beyond the noise |
| requests served | 5766 | 5766 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 97.19 | 96.97 | -0.2% | -0.6599 to +0.2183 | STEADY, under the floor |
| response time, 95th percentile (ms) | 270.8 | 269.8 | -0.4% | -2.655 to +0.6623 | STEADY, under the floor |
| response time, 99th percentile (ms) | 459.2 | 457.2 | -0.4% | -6.389 to +2.371 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.82 | 47.84 | +0.0% | -0.2721 to +0.2997 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.216e+05 | 1.215e+05 | -0.1% | -253.7 to +53.35 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.37 | 47.64 | +0.6% | -0.173 to +0.6997 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.217e+05 | 1.21e+05 | -0.6% | -1796 to +446.8 | GAIN, not beyond the noise |
| energy per served request (J) | 21.11 | 20.99 | -0.6% | -0.3115 to +0.07749 | GAIN, not beyond the noise |
| power, GPU mean (W) | 191.1 | 189.7 | -0.7% | -4.345 to +1.607 | GAIN, not beyond the noise |
| requests served | 5766 | 5766 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.97 | 97.04 | +0.1% | -0.3691 to +0.4999 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269.8 | 270.3 | +0.2% | -2.255 to +3.284 | STEADY, under the floor |
| response time, 99th percentile (ms) | 457.2 | 457.9 | +0.2% | -2.831 to +4.333 | STEADY, under the floor |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 47.84 | 47.84 | -0.0% | -0.4083 to +0.4031 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.215e+05 | 1.215e+05 | +0.0% | -484.3 to +511 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.53 -> 47.64 served requests per kJ, difference +0.1108 (95% interval -0.2051 to +0.4266).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 36 | 0 | 0 | 0 | 0.206 | 0.343 | 0 | 1.31e+03 | 35 | True |
| omni | 2 | 18 | 0 | 0 | 0 | 0.204 | 0.27 | 0 | 576 | 17 | True |
| omni | 3 | 36 | 0 | 0 | 0 | 0.217 | 0.292 | 0 | 1.23e+03 | 35 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 61 | +41.59 | +0 |
| compass | 45 | 1028 | +784.4 | +148 |
| fail_up | 2 | 7 | -51.48 | -6 |
| race | 40 | 160 | +680.8 | -165 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 90.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*