# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 43.58 | 43.52 | 43.98 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.062e+04 | 6.071e+04 | 6.007e+04 |
| energy per served request (J) | 22.94 | 22.98 | 22.74 |
| power, GPU mean (W) | 181 | 181.1 | 178.9 |
| requests served | 2642 | 2642 | 2642 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 111.8 | 112.8 | 112.4 |
| response time, 95th percentile (ms) | 355.9 | 367.2 | 357.7 |
| response time, 99th percentile (ms) | 628.5 | 650.5 | 647.9 |
| temperature, peak (C) | 57 | 57 | 57 |
| temperature, mean (C) | 48.06 | 48.05 | 47.85 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.1e+04 | 6.101e+04 | 6.062e+04 |
| power-capped share of samples | 0.6827 | 0.6779 | 0.6628 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.58 | 43.98 | +0.9% | +0.01474 to +0.7763 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.062e+04 | 6.007e+04 | -0.9% | -1090 to -0.7556 | GAIN, clear of the noise |
| energy per served request (J) | 22.94 | 22.74 | -0.9% | -0.4125 to -0.000286 | GAIN, clear of the noise |
| power, GPU mean (W) | 181 | 178.9 | -1.1% | -8.084 to +3.93 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.8 | 112.4 | +0.5% | -47.99 to +49.12 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 355.9 | 357.7 | +0.5% | -418.7 to +422.2 | STEADY, under the floor |
| response time, 99th percentile (ms) | 628.5 | 647.9 | +3.1% | -353 to +391.8 | LOSS, not beyond the noise |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.06 | 47.85 | -0.4% | -1.723 to +1.294 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.1e+04 | 6.062e+04 | -0.6% | -2966 to +2190 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6827 | 0.6628 | -2.9% | -0.09285 to +0.05301 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.58 | 43.52 | -0.2% | -0.7816 to +0.6453 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.062e+04 | 6.071e+04 | +0.2% | -904.3 to +1095 | STEADY, under the floor |
| energy per served request (J) | 22.94 | 22.98 | +0.2% | -0.3423 to +0.4144 | STEADY, under the floor |
| power, GPU mean (W) | 181 | 181.1 | +0.1% | -1.858 to +2.063 | STEADY, under the floor |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.8 | 112.8 | +0.9% | -38.24 to +40.21 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 355.9 | 367.2 | +3.2% | -267.1 to +289.6 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 628.5 | 650.5 | +3.5% | -295.6 to +339.6 | LOSS, not beyond the noise |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.06 | 48.05 | -0.0% | -0.1787 to +0.1492 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.1e+04 | 6.101e+04 | +0.0% | -954.1 to +972 | STEADY, under the floor |
| power-capped share of samples | 0.6827 | 0.6779 | -0.7% | -0.1368 to +0.1272 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 43.52 | 43.98 | +1.1% | -0.6305 to +1.558 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.071e+04 | 6.007e+04 | -1.1% | -2185 to +903.6 | GAIN, not beyond the noise |
| energy per served request (J) | 22.98 | 22.74 | -1.1% | -0.8269 to +0.342 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.1 | 178.9 | -1.2% | -10.15 to +5.788 | GAIN, not beyond the noise |
| requests served | 2642 | 2642 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 112.8 | 112.4 | -0.4% | -9.759 to +8.908 | STEADY, under the floor |
| response time, 95th percentile (ms) | 367.2 | 357.7 | -2.6% | -151.6 to +132.6 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 650.5 | 647.9 | -0.4% | -57.45 to +52.23 | STEADY, under the floor |
| temperature, peak (C) | 57 | 57 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.05 | 47.85 | -0.4% | -1.545 to +1.145 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.101e+04 | 6.062e+04 | -0.7% | -3938 to +3144 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6779 | 0.6628 | -2.2% | -0.07418 to +0.04395 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 43.58 -> 43.98 served requests per kJ, difference +0.3955 (95% interval +0.01474 to +0.7763).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: GAIN AND LOSS (energy cut, service traded for it).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 144 | 0 | n/a | n/a | 0 | 144 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 16.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*