# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.43 | 40.4 | 40.37 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.541e+05 | 1.543e+05 | 1.544e+05 |
| energy per served request (J) | 24.73 | 24.76 | 24.77 |
| power, GPU mean (W) | 241.6 | 242.3 | 241.8 |
| requests served | 6232 | 6232 | 6232 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 87.74 | 87.82 | 87.77 |
| response time, 95th percentile (ms) | 245.5 | 245.3 | 245.2 |
| response time, 99th percentile (ms) | 436.7 | 437.8 | 436.7 |
| temperature, peak (C) | 66.67 | 66.33 | 66.67 |
| temperature, mean (C) | 54.22 | 54.35 | 54.24 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.546e+05 | 1.547e+05 | 1.546e+05 |
| power-capped share of samples | 0.7416 | 0.74 | 0.7286 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.43 | 40.37 | -0.1% | -0.9641 to +0.8452 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.541e+05 | 1.544e+05 | +0.1% | -3258 to +3706 | STEADY, under the floor |
| energy per served request (J) | 24.73 | 24.77 | +0.1% | -0.5228 to +0.5946 | STEADY, under the floor |
| power, GPU mean (W) | 241.6 | 241.8 | +0.1% | -5.262 to +5.647 | STEADY, under the floor |
| requests served | 6232 | 6232 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.74 | 87.77 | +0.0% | -0.3117 to +0.3835 | STEADY, under the floor |
| response time, 95th percentile (ms) | 245.5 | 245.2 | -0.1% | -4.994 to +4.412 | STEADY, under the floor |
| response time, 99th percentile (ms) | 436.7 | 436.7 | -0.0% | -5.885 to +5.7 | STEADY, under the floor |
| temperature, peak (C) | 66.67 | 66.67 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 54.22 | 54.24 | +0.0% | -0.1531 to +0.1906 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.546e+05 | 1.546e+05 | +0.0% | -342 to +356.2 | STEADY, under the floor |
| power-capped share of samples | 0.7416 | 0.7286 | -1.8% | -0.04295 to +0.0169 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.43 | 40.4 | -0.1% | -0.6213 to +0.5532 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.541e+05 | 1.543e+05 | +0.1% | -2117 to +2391 | STEADY, under the floor |
| energy per served request (J) | 24.73 | 24.76 | +0.1% | -0.3397 to +0.3837 | STEADY, under the floor |
| power, GPU mean (W) | 241.6 | 242.3 | +0.3% | -2.936 to +4.222 | STEADY, under the floor |
| requests served | 6232 | 6232 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.74 | 87.82 | +0.1% | -0.4207 to +0.594 | STEADY, under the floor |
| response time, 95th percentile (ms) | 245.5 | 245.3 | -0.1% | -4.562 to +4.151 | STEADY, under the floor |
| response time, 99th percentile (ms) | 436.7 | 437.8 | +0.2% | -3.24 to +5.314 | STEADY, under the floor |
| temperature, peak (C) | 66.67 | 66.33 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 54.22 | 54.35 | +0.2% | -0.002784 to +0.2516 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.546e+05 | 1.547e+05 | +0.1% | -30.19 to +241.9 | STEADY, under the floor |
| power-capped share of samples | 0.7416 | 0.74 | -0.2% | -0.014 to +0.01067 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.4 | 40.37 | -0.1% | -1.494 to +1.443 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.543e+05 | 1.544e+05 | +0.1% | -5569 to +5742 | STEADY, under the floor |
| energy per served request (J) | 24.76 | 24.77 | +0.1% | -0.8937 to +0.9214 | STEADY, under the floor |
| power, GPU mean (W) | 242.3 | 241.8 | -0.2% | -9.45 to +8.549 | STEADY, under the floor |
| requests served | 6232 | 6232 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 87.82 | 87.77 | -0.1% | -0.3847 to +0.2832 | STEADY, under the floor |
| response time, 95th percentile (ms) | 245.3 | 245.2 | -0.0% | -2.703 to +2.532 | STEADY, under the floor |
| response time, 99th percentile (ms) | 437.8 | 436.7 | -0.3% | -4.526 to +2.267 | STEADY, under the floor |
| temperature, peak (C) | 66.33 | 66.67 | +0.5% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 54.35 | 54.24 | -0.2% | -0.1631 to -0.04825 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.547e+05 | 1.546e+05 | -0.1% | -564.9 to +367.3 | STEADY, under the floor |
| power-capped share of samples | 0.74 | 0.7286 | -1.5% | -0.03089 to +0.008176 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.43 -> 40.37 served requests per kJ, difference -0.05944 (95% interval -0.9641 to +0.8452).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| omni | 3 | 270 | 0 | n/a | n/a | 0 | 270 | 0 |
| watch | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 2 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |
| watch | 3 | 274 | 0 | n/a | n/a | 0 | 274 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*