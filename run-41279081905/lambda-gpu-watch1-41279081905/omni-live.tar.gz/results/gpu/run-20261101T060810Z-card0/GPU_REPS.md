# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.06 | 39.07 | 39.63 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.573e+05 | 1.572e+05 | 1.55e+05 |
| energy per served request (J) | 25.6 | 25.6 | 25.23 |
| power, GPU mean (W) | 246.7 | 246.2 | 244.1 |
| requests served | 6143 | 6143 | 6143 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 88.78 | 88.79 | 88.8 |
| response time, 95th percentile (ms) | 251.8 | 252.8 | 251.8 |
| response time, 99th percentile (ms) | 442.4 | 443 | 442.1 |
| temperature, peak (C) | 78.33 | 78 | 78 |
| temperature, mean (C) | 63.52 | 63.45 | 63.48 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.567e+05 | 1.569e+05 | 1.566e+05 |
| power-capped share of samples | 0.7333 | 0.7278 | 0.7336 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.06 | 39.63 | +1.5% | -0.03233 to +1.182 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.573e+05 | 1.55e+05 | -1.4% | -4610 to +68.23 | GAIN, not beyond the noise |
| energy per served request (J) | 25.6 | 25.23 | -1.4% | -0.7505 to +0.01111 | GAIN, not beyond the noise |
| power, GPU mean (W) | 246.7 | 244.1 | -1.1% | -7.433 to +2.243 | GAIN, not beyond the noise |
| requests served | 6143 | 6143 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.78 | 88.8 | +0.0% | -0.1355 to +0.1728 | STEADY, under the floor |
| response time, 95th percentile (ms) | 251.8 | 251.8 | -0.0% | -0.9357 to +0.8699 | STEADY, under the floor |
| response time, 99th percentile (ms) | 442.4 | 442.1 | -0.1% | -1.259 to +0.7633 | STEADY, under the floor |
| temperature, peak (C) | 78.33 | 78 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 63.52 | 63.48 | -0.1% | -0.1232 to +0.04487 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.567e+05 | 1.566e+05 | -0.1% | -292.7 to +103.2 | STEADY, under the floor |
| power-capped share of samples | 0.7333 | 0.7336 | +0.0% | -0.01034 to +0.01095 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.06 | 39.07 | +0.0% | -1.069 to +1.087 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.573e+05 | 1.572e+05 | -0.0% | -4378 to +4305 | STEADY, under the floor |
| energy per served request (J) | 25.6 | 25.6 | -0.0% | -0.7126 to +0.7009 | STEADY, under the floor |
| power, GPU mean (W) | 246.7 | 246.2 | -0.2% | -6.792 to +5.824 | STEADY, under the floor |
| requests served | 6143 | 6143 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.78 | 88.79 | +0.0% | -0.1751 to +0.2064 | STEADY, under the floor |
| response time, 95th percentile (ms) | 251.8 | 252.8 | +0.4% | +0.05176 to +2.026 | STEADY, under the floor |
| response time, 99th percentile (ms) | 442.4 | 443 | +0.2% | -1.094 to +2.426 | STEADY, under the floor |
| temperature, peak (C) | 78.33 | 78 | -0.4% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 63.52 | 63.45 | -0.1% | -0.26 to +0.1073 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.567e+05 | 1.569e+05 | +0.1% | -821.8 to +1215 | STEADY, under the floor |
| power-capped share of samples | 0.7333 | 0.7278 | -0.8% | -0.02668 to +0.01565 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.07 | 39.63 | +1.4% | -1.102 to +2.233 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.572e+05 | 1.55e+05 | -1.4% | -8845 to +4376 | GAIN, not beyond the noise |
| energy per served request (J) | 25.6 | 25.23 | -1.4% | -1.44 to +0.7123 | GAIN, not beyond the noise |
| power, GPU mean (W) | 246.2 | 244.1 | -0.9% | -12.97 to +8.752 | GAIN, not beyond the noise |
| requests served | 6143 | 6143 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.79 | 88.8 | +0.0% | -0.3174 to +0.3234 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.8 | 251.8 | -0.4% | -1.443 to -0.7007 | STEADY, under the floor |
| response time, 99th percentile (ms) | 443 | 442.1 | -0.2% | -2.241 to +0.4142 | STEADY, under the floor |
| temperature, peak (C) | 78 | 78 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 63.45 | 63.48 | +0.1% | -0.206 to +0.2804 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.569e+05 | 1.566e+05 | -0.2% | -1455 to +873 | STEADY, under the floor |
| power-capped share of samples | 0.7278 | 0.7336 | +0.8% | -0.004697 to +0.01634 | power given, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.06 -> 39.63 served requests per kJ, difference +0.5749 (95% interval -0.03233 to +1.182).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 1 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 3 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*