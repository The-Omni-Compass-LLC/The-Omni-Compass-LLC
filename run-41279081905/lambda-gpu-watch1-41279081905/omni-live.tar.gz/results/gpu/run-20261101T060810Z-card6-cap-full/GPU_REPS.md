# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 59.94 | 60.09 | 60.13 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.267e+04 | 9.273e+04 | 9.268e+04 |
| energy per served request (J) | 16.68 | 16.64 | 16.63 |
| power, GPU mean (W) | 276.4 | 276.6 | 276.5 |
| requests served | 5554 | 5572 | 5572 |
| requests not served | 1279 | 1260 | 1260 |
| response time, mean (ms) | 4.308e+04 | 4.261e+04 | 4.259e+04 |
| response time, 95th percentile (ms) | 8.159e+04 | 8.085e+04 | 8.082e+04 |
| response time, 99th percentile (ms) | 8.462e+04 | 8.405e+04 | 8.401e+04 |
| temperature, peak (C) | 65.5 | 66 | 66 |
| temperature, mean (C) | 63.07 | 63.36 | 63.42 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.276e+04 | 9.27e+04 | 9.267e+04 |
| power-capped share of samples | 0.9857 | 0.9851 | 0.9579 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.94 | 60.13 | +0.3% | -0.6812 to +1.064 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.267e+04 | 9.268e+04 | +0.0% | -171.8 to +196.8 | STEADY, under the floor |
| energy per served request (J) | 16.68 | 16.63 | -0.3% | -0.2961 to +0.1898 | STEADY, under the floor |
| power, GPU mean (W) | 276.4 | 276.5 | +0.0% | -2.059 to +2.252 | STEADY, under the floor |
| requests served | 5554 | 5572 | +0.3% | -51.38 to +88.38 | STEADY, under the floor |
| requests not served | 1279 | 1260 | -1.4% | -88.38 to +51.38 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.308e+04 | 4.259e+04 | -1.1% | -3822 to +2832 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.159e+04 | 8.082e+04 | -0.9% | -2402 to +861.3 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.462e+04 | 8.401e+04 | -0.7% | -2523 to +1308 | GAIN, not beyond the noise |
| temperature, peak (C) | 65.5 | 66 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 63.07 | 63.42 | +0.5% | -3.896 to +4.585 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.276e+04 | 9.267e+04 | -0.1% | -516 to +336 | STEADY, under the floor |
| power-capped share of samples | 0.9857 | 0.9579 | -2.8% | -0.3342 to +0.2786 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.94 | 60.09 | +0.3% | -0.2052 to +0.5233 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.267e+04 | 9.273e+04 | +0.1% | -817.1 to +942.2 | STEADY, under the floor |
| energy per served request (J) | 16.68 | 16.64 | -0.3% | -0.1463 to +0.05797 | STEADY, under the floor |
| power, GPU mean (W) | 276.4 | 276.6 | +0.1% | -5.515 to +5.824 | STEADY, under the floor |
| requests served | 5554 | 5572 | +0.3% | -0.559 to +37.56 | STEADY, under the floor |
| requests not served | 1279 | 1260 | -1.4% | -37.56 to +0.559 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.308e+04 | 4.261e+04 | -1.1% | -1109 to +166.9 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 8.159e+04 | 8.085e+04 | -0.9% | -2048 to +568.8 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 8.462e+04 | 8.405e+04 | -0.7% | -1263 to +111.1 | GAIN, not beyond the noise |
| temperature, peak (C) | 65.5 | 66 | +0.8% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 63.07 | 63.36 | +0.5% | -4.656 to +5.235 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.276e+04 | 9.27e+04 | -0.1% | -367.6 to +244.6 | STEADY, under the floor |
| power-capped share of samples | 0.9857 | 0.9851 | -0.1% | -0.008252 to +0.007016 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.09 | 60.13 | +0.1% | -0.476 to +0.5409 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.273e+04 | 9.268e+04 | -0.1% | -745.4 to +645.3 | STEADY, under the floor |
| energy per served request (J) | 16.64 | 16.63 | -0.1% | -0.1498 to +0.1318 | STEADY, under the floor |
| power, GPU mean (W) | 276.6 | 276.5 | -0.0% | -7.883 to +7.767 | STEADY, under the floor |
| requests served | 5572 | 5572 | +0.0% | -88.94 to +88.94 | STEADY, under the floor |
| requests not served | 1260 | 1260 | +0.0% | -88.94 to +88.94 | STEADY, under the floor |
| response time, mean (ms) | 4.261e+04 | 4.259e+04 | -0.1% | -2713 to +2665 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.085e+04 | 8.082e+04 | -0.0% | -2971 to +2909 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.405e+04 | 8.401e+04 | -0.0% | -2634 to +2571 | STEADY, under the floor |
| temperature, peak (C) | 66 | 66 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 63.36 | 63.42 | +0.1% | -0.6495 to +0.7602 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.27e+04 | 9.267e+04 | -0.0% | -148.5 to +91.39 | STEADY, under the floor |
| power-capped share of samples | 0.9851 | 0.9579 | -2.8% | -0.3259 to +0.2716 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 59.94 -> 60.13 served requests per kJ, difference +0.1915 (95% interval -0.6812 to +1.064).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*