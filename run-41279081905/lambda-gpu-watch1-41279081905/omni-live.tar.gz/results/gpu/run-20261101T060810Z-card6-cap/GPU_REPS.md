# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.04 | 42.05 | 41.52 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.264e+04 | 6.115e+04 | 6.192e+04 |
| energy per served request (J) | 24.36 | 23.78 | 24.08 |
| power, GPU mean (W) | 186.6 | 182.4 | 184.9 |
| requests served | 2571 | 2571 | 2571 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 119 | 118.3 | 118.5 |
| response time, 95th percentile (ms) | 395.3 | 389.2 | 391 |
| response time, 99th percentile (ms) | 675.9 | 673.4 | 664.5 |
| temperature, peak (C) | 61.5 | 61.5 | 61.5 |
| temperature, mean (C) | 51.8 | 51.79 | 51.68 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.234e+04 | 6.219e+04 | 6.179e+04 |
| power-capped share of samples | 0.6852 | 0.68 | 0.656 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.04 | 41.52 | +1.2% | -1.423 to +2.374 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.264e+04 | 6.192e+04 | -1.1% | -3599 to +2164 | GAIN, not beyond the noise |
| energy per served request (J) | 24.36 | 24.08 | -1.1% | -1.4 to +0.8415 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.6 | 184.9 | -0.9% | -2.837 to -0.505 | GAIN, clear of the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 119 | 118.5 | -0.4% | -17.23 to +16.28 | STEADY, under the floor |
| response time, 95th percentile (ms) | 395.3 | 391 | -1.1% | -126.1 to +117.5 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 675.9 | 664.5 | -1.7% | -155.9 to +133 | GAIN, not beyond the noise |
| temperature, peak (C) | 61.5 | 61.5 | +0.0% | -12.71 to +12.71 | STEADY, under the floor |
| temperature, mean (C) | 51.8 | 51.68 | -0.2% | -0.2177 to -0.01391 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.234e+04 | 6.179e+04 | -0.9% | -3535 to +2450 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6852 | 0.656 | -4.3% | -0.3166 to +0.2582 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.04 | 42.05 | +2.4% | -6.752 to +8.762 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.264e+04 | 6.115e+04 | -2.4% | -1.287e+04 to +9897 | GAIN, not beyond the noise |
| energy per served request (J) | 24.36 | 23.78 | -2.4% | -5.008 to +3.849 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186.6 | 182.4 | -2.3% | -26.35 to +17.85 | GAIN, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 119 | 118.3 | -0.6% | -13.68 to +12.33 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 395.3 | 389.2 | -1.5% | -89.24 to +77.04 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 675.9 | 673.4 | -0.4% | -96.57 to +91.41 | STEADY, under the floor |
| temperature, peak (C) | 61.5 | 61.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 51.8 | 51.79 | -0.0% | -0.977 to +0.9657 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.234e+04 | 6.219e+04 | -0.2% | -3227 to +2941 | STEADY, under the floor |
| power-capped share of samples | 0.6852 | 0.68 | -0.8% | -0.04936 to +0.03897 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.05 | 41.52 | -1.3% | -6.388 to +5.33 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.115e+04 | 6.192e+04 | +1.3% | -7733 to +9275 | power given, not beyond the noise |
| energy per served request (J) | 23.78 | 24.08 | +1.3% | -3.008 to +3.608 | power given, not beyond the noise |
| power, GPU mean (W) | 182.4 | 184.9 | +1.4% | -18.35 to +23.51 | power given, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 118.3 | 118.5 | +0.2% | -3.55 to +3.947 | STEADY, under the floor |
| response time, 95th percentile (ms) | 389.2 | 391 | +0.5% | -36.89 to +40.5 | STEADY, under the floor |
| response time, 99th percentile (ms) | 673.4 | 664.5 | -1.3% | -59.36 to +41.56 | GAIN, not beyond the noise |
| temperature, peak (C) | 61.5 | 61.5 | +0.0% | -12.71 to +12.71 | STEADY, under the floor |
| temperature, mean (C) | 51.79 | 51.68 | -0.2% | -0.9796 to +0.7592 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.219e+04 | 6.179e+04 | -0.6% | -491.1 to -308.2 | GAIN, clear of the noise |
| power-capped share of samples | 0.68 | 0.656 | -3.5% | -0.2673 to +0.2192 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.04 -> 41.52 served requests per kJ, difference +0.4755 (95% interval -1.423 to +2.374).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 28.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*