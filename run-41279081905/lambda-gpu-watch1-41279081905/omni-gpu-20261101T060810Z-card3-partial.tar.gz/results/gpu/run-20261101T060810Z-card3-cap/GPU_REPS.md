# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 42.04 | 42.76 | 42.4 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.116e+04 | 6.012e+04 | 6.063e+04 |
| energy per served request (J) | 23.79 | 23.38 | 23.58 |
| power, GPU mean (W) | 181.6 | 179 | 180.4 |
| requests served | 2571 | 2571 | 2571 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 115.3 | 114.8 | 114.6 |
| response time, 95th percentile (ms) | 378.9 | 379.9 | 370 |
| response time, 99th percentile (ms) | 670.8 | 671 | 637.4 |
| temperature, peak (C) | 59 | 60 | 59 |
| temperature, mean (C) | 48.92 | 48.87 | 48.85 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.091e+04 | 6.082e+04 | 6.049e+04 |
| power-capped share of samples | 0.6664 | 0.6735 | 0.6458 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.04 | 42.4 | +0.9% | -4.81 to +5.539 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.116e+04 | 6.063e+04 | -0.9% | -8052 to +6990 | GAIN, not beyond the noise |
| energy per served request (J) | 23.79 | 23.58 | -0.9% | -3.132 to +2.719 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.6 | 180.4 | -0.7% | -21.5 to +19.07 | GAIN, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.3 | 114.6 | -0.6% | -47.33 to +45.97 | GAIN, not beyond the noise |
| response time, 95th percentile (ms) | 378.9 | 370 | -2.3% | -318 to +300.2 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 670.8 | 637.4 | -5.0% | -411.6 to +344.8 | GAIN, not beyond the noise |
| temperature, peak (C) | 59 | 59 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.92 | 48.85 | -0.1% | -0.7794 to +0.6462 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.091e+04 | 6.049e+04 | -0.7% | -1376 to +539.1 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6664 | 0.6458 | -3.1% | -0.1127 to +0.0716 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.04 | 42.76 | +1.7% | -2.997 to +4.448 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.116e+04 | 6.012e+04 | -1.7% | -6514 to +4429 | GAIN, not beyond the noise |
| energy per served request (J) | 23.79 | 23.38 | -1.7% | -2.534 to +1.723 | GAIN, not beyond the noise |
| power, GPU mean (W) | 181.6 | 179 | -1.4% | -11.52 to +6.342 | GAIN, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 115.3 | 114.8 | -0.4% | -3.088 to +2.16 | STEADY, under the floor |
| response time, 95th percentile (ms) | 378.9 | 379.9 | +0.3% | -65.51 to +67.46 | STEADY, under the floor |
| response time, 99th percentile (ms) | 670.8 | 671 | +0.0% | -50.8 to +51.23 | STEADY, under the floor |
| temperature, peak (C) | 59 | 60 | +1.7% | -11.71 to +13.71 | power given, not beyond the noise |
| temperature, mean (C) | 48.92 | 48.87 | -0.1% | -1.44 to +1.347 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.091e+04 | 6.082e+04 | -0.1% | -564.4 to +394.1 | STEADY, under the floor |
| power-capped share of samples | 0.6664 | 0.6735 | +1.1% | -0.1246 to +0.1387 | power given, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 42.76 | 42.4 | -0.8% | -1.813 to +1.091 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.012e+04 | 6.063e+04 | +0.9% | -1538 to +2561 | power given, not beyond the noise |
| energy per served request (J) | 23.38 | 23.58 | +0.9% | -0.598 to +0.9961 | power given, not beyond the noise |
| power, GPU mean (W) | 179 | 180.4 | +0.8% | -9.982 to +12.73 | power given, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 114.8 | 114.6 | -0.2% | -49.49 to +49.05 | STEADY, under the floor |
| response time, 95th percentile (ms) | 379.9 | 370 | -2.6% | -385.4 to +365.7 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 671 | 637.4 | -5.0% | -462.8 to +395.6 | GAIN, not beyond the noise |
| temperature, peak (C) | 60 | 59 | -1.7% | -13.71 to +11.71 | GAIN, not beyond the noise |
| temperature, mean (C) | 48.87 | 48.85 | -0.0% | -0.7012 to +0.6602 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.082e+04 | 6.049e+04 | -0.5% | -811.3 to +145 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6735 | 0.6458 | -4.1% | -0.06714 to +0.01191 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 42.04 -> 42.4 served requests per kJ, difference +0.3645 (95% interval -4.81 to +5.539).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| watch | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 24.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*