# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 60.95 | 60.89 | 60.93 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.285e+04 | 9.27e+04 | 9.268e+04 |
| energy per served request (J) | 16.41 | 16.42 | 16.41 |
| power, GPU mean (W) | 274.3 | 275.1 | 274.9 |
| requests served | 5659 | 5644 | 5646 |
| requests not served | 1171 | 1186 | 1184 |
| response time, mean (ms) | 4.06e+04 | 4.09e+04 | 4.09e+04 |
| response time, 95th percentile (ms) | 7.656e+04 | 7.731e+04 | 7.722e+04 |
| response time, 99th percentile (ms) | 7.963e+04 | 8.039e+04 | 8.03e+04 |
| temperature, peak (C) | 62 | 62 | 62 |
| temperature, mean (C) | 59.57 | 60.2 | 60.24 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.284e+04 | 9.278e+04 | 9.273e+04 |
| power-capped share of samples | 0.977 | 0.9815 | 0.9219 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.95 | 60.93 | -0.0% | -2.104 to +2.068 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.285e+04 | 9.268e+04 | -0.2% | -745.8 to +391.6 | STEADY, under the floor |
| energy per served request (J) | 16.41 | 16.41 | +0.0% | -0.5568 to +0.5667 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 274.9 | +0.2% | -3.827 to +5.19 | STEADY, under the floor |
| requests served | 5659 | 5646 | -0.2% | -171.3 to +146.3 | STEADY, under the floor |
| requests not served | 1171 | 1184 | +1.1% | -146.3 to +171.3 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.06e+04 | 4.09e+04 | +0.8% | -4091 to +4708 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.656e+04 | 7.722e+04 | +0.9% | -7250 to +8570 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.963e+04 | 8.03e+04 | +0.8% | -7382 to +8722 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.57 | 60.24 | +1.1% | -5.602 to +6.936 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.284e+04 | 9.273e+04 | -0.1% | -724.4 to +501.8 | STEADY, under the floor |
| power-capped share of samples | 0.977 | 0.9219 | -5.6% | -0.5161 to +0.4058 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.95 | 60.89 | -0.1% | -1.967 to +1.858 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.285e+04 | 9.27e+04 | -0.2% | -1295 to +985.6 | STEADY, under the floor |
| energy per served request (J) | 16.41 | 16.42 | +0.1% | -0.5007 to +0.5302 | STEADY, under the floor |
| power, GPU mean (W) | 274.3 | 275.1 | +0.3% | -7.448 to +9.047 | STEADY, under the floor |
| requests served | 5659 | 5644 | -0.3% | -122.5 to +93.5 | STEADY, under the floor |
| requests not served | 1171 | 1186 | +1.2% | -93.5 to +122.5 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.06e+04 | 4.09e+04 | +0.7% | -2885 to +3488 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.656e+04 | 7.731e+04 | +1.0% | -4481 to +5984 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.963e+04 | 8.039e+04 | +1.0% | -4780 to +6297 | LOSS, not beyond the noise |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.57 | 60.2 | +1.1% | -5.084 to +6.347 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.284e+04 | 9.278e+04 | -0.1% | -446 to +330.4 | STEADY, under the floor |
| power-capped share of samples | 0.977 | 0.9815 | +0.5% | -0.03725 to +0.04615 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.89 | 60.93 | +0.1% | -0.137 to +0.2095 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.27e+04 | 9.268e+04 | -0.0% | -594 to +549.2 | STEADY, under the floor |
| energy per served request (J) | 16.42 | 16.41 | -0.1% | -0.05611 to +0.03658 | STEADY, under the floor |
| power, GPU mean (W) | 275.1 | 274.9 | -0.0% | -3.857 to +3.621 | STEADY, under the floor |
| requests served | 5644 | 5646 | +0.0% | -48.82 to +52.82 | STEADY, under the floor |
| requests not served | 1186 | 1184 | -0.2% | -52.82 to +48.82 | STEADY, under the floor |
| response time, mean (ms) | 4.09e+04 | 4.09e+04 | +0.0% | -1206 to +1221 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.731e+04 | 7.722e+04 | -0.1% | -2769 to +2586 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.039e+04 | 8.03e+04 | -0.1% | -2602 to +2425 | STEADY, under the floor |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 60.2 | 60.24 | +0.1% | -0.5181 to +0.5897 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.278e+04 | 9.273e+04 | -0.1% | -278.4 to +171.4 | STEADY, under the floor |
| power-capped share of samples | 0.9815 | 0.9219 | -6.1% | -0.5622 to +0.4431 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 60.95 -> 60.93 served requests per kJ, difference -0.01838 (95% interval -2.104 to +2.068).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*