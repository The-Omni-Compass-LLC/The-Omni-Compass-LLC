# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 63.27 | 63.2 | 63.2 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.264e+04 | 9.261e+04 | 9.257e+04 |
| energy per served request (J) | 15.8 | 15.82 | 15.82 |
| power, GPU mean (W) | 276.1 | 276.6 | 276.6 |
| requests served | 5862 | 5854 | 5850 |
| requests not served | 1230 | 1238 | 1240 |
| response time, mean (ms) | 4.056e+04 | 4.091e+04 | 4.099e+04 |
| response time, 95th percentile (ms) | 7.71e+04 | 7.752e+04 | 7.767e+04 |
| response time, 99th percentile (ms) | 7.943e+04 | 7.969e+04 | 7.984e+04 |
| temperature, peak (C) | 61 | 61 | 61 |
| temperature, mean (C) | 59.09 | 58.66 | 59.08 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.271e+04 | 9.263e+04 | 9.255e+04 |
| power-capped share of samples | 0.9848 | 0.9857 | 0.8301 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.27 | 63.2 | -0.1% | -0.483 to +0.3374 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.264e+04 | 9.257e+04 | -0.1% | -1276 to +1141 | STEADY, under the floor |
| energy per served request (J) | 15.8 | 15.82 | +0.1% | -0.08477 to +0.1212 | STEADY, under the floor |
| power, GPU mean (W) | 276.1 | 276.6 | +0.2% | -6.039 to +6.998 | STEADY, under the floor |
| requests served | 5862 | 5850 | -0.2% | -125.4 to +103.4 | STEADY, under the floor |
| requests not served | 1230 | 1240 | +0.9% | -103.4 to +125.4 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.056e+04 | 4.099e+04 | +1.1% | -4598 to +5458 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.71e+04 | 7.767e+04 | +0.7% | -5435 to +6574 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.943e+04 | 7.984e+04 | +0.5% | -4489 to +5320 | LOSS, not beyond the noise |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.09 | 59.08 | -0.0% | -1.139 to +1.124 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.271e+04 | 9.255e+04 | -0.2% | -652.9 to +332.9 | STEADY, under the floor |
| power-capped share of samples | 0.9848 | 0.8301 | -15.7% | -1.98 to +1.671 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.27 | 63.2 | -0.1% | -0.3605 to +0.2211 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.264e+04 | 9.261e+04 | -0.0% | -603.2 to +554.3 | STEADY, under the floor |
| energy per served request (J) | 15.8 | 15.82 | +0.1% | -0.05564 to +0.09052 | STEADY, under the floor |
| power, GPU mean (W) | 276.1 | 276.6 | +0.2% | +0.12 to +0.9673 | STEADY, under the floor |
| requests served | 5862 | 5854 | -0.1% | -71.53 to +55.53 | STEADY, under the floor |
| requests not served | 1230 | 1238 | +0.7% | -55.53 to +71.53 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.056e+04 | 4.091e+04 | +0.8% | -3387 to +4070 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 7.71e+04 | 7.752e+04 | +0.5% | -2613 to +3439 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 7.943e+04 | 7.969e+04 | +0.3% | -2097 to +2632 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.09 | 58.66 | -0.7% | -6.827 to +5.968 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.271e+04 | 9.263e+04 | -0.1% | -756.4 to +592.1 | STEADY, under the floor |
| power-capped share of samples | 0.9848 | 0.9857 | +0.1% | -0.01076 to +0.01251 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 63.2 | 63.2 | -0.0% | -0.1225 to +0.1163 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.261e+04 | 9.257e+04 | -0.0% | -672.9 to +586.9 | STEADY, under the floor |
| energy per served request (J) | 15.82 | 15.82 | +0.0% | -0.02913 to +0.03069 | STEADY, under the floor |
| power, GPU mean (W) | 276.6 | 276.6 | -0.0% | -7.006 to +6.878 | STEADY, under the floor |
| requests served | 5854 | 5850 | -0.1% | -53.82 to +47.82 | STEADY, under the floor |
| requests not served | 1238 | 1240 | +0.2% | -47.82 to +53.82 | STEADY, under the floor |
| response time, mean (ms) | 4.091e+04 | 4.099e+04 | +0.2% | -1211 to +1388 | STEADY, under the floor |
| response time, 95th percentile (ms) | 7.752e+04 | 7.767e+04 | +0.2% | -2823 to +3135 | STEADY, under the floor |
| response time, 99th percentile (ms) | 7.969e+04 | 7.984e+04 | +0.2% | -2392 to +2688 | STEADY, under the floor |
| temperature, peak (C) | 61 | 61 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 58.66 | 59.08 | +0.7% | -4.844 to +5.688 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.263e+04 | 9.255e+04 | -0.1% | -259.2 to +103.5 | STEADY, under the floor |
| power-capped share of samples | 0.9857 | 0.8301 | -15.8% | -1.993 to +1.681 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 63.27 -> 63.2 served requests per kJ, difference -0.0728 (95% interval -0.483 to +0.3374).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*