# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 59.96 | 60.05 | 60.2 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.289e+04 | 9.277e+04 | 9.275e+04 |
| energy per served request (J) | 16.68 | 16.65 | 16.61 |
| power, GPU mean (W) | 274.1 | 275 | 275 |
| requests served | 5570 | 5570 | 5584 |
| requests not served | 1273 | 1272 | 1259 |
| response time, mean (ms) | 4.241e+04 | 4.247e+04 | 4.229e+04 |
| response time, 95th percentile (ms) | 8.119e+04 | 8.12e+04 | 8.081e+04 |
| response time, 99th percentile (ms) | 8.444e+04 | 8.445e+04 | 8.397e+04 |
| temperature, peak (C) | 62 | 62 | 61.5 |
| temperature, mean (C) | 59.34 | 59.38 | 59.06 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.291e+04 | 9.281e+04 | 9.278e+04 |
| power-capped share of samples | 0.9761 | 0.9809 | 0.9672 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.96 | 60.2 | +0.4% | -1.484 to +1.962 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.289e+04 | 9.275e+04 | -0.1% | -439.5 to +167 | STEADY, under the floor |
| energy per served request (J) | 16.68 | 16.61 | -0.4% | -0.5407 to +0.4085 | STEADY, under the floor |
| power, GPU mean (W) | 274.1 | 275 | +0.3% | +0.8274 to +0.9395 | STEADY, under the floor |
| requests served | 5570 | 5584 | +0.3% | -163.9 to +191.9 | STEADY, under the floor |
| requests not served | 1273 | 1259 | -1.1% | -191.9 to +163.9 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.241e+04 | 4.229e+04 | -0.3% | -1870 to +1636 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.119e+04 | 8.081e+04 | -0.5% | -4917 to +4161 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.444e+04 | 8.397e+04 | -0.6% | -6178 to +5239 | GAIN, not beyond the noise |
| temperature, peak (C) | 62 | 61.5 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 59.34 | 59.06 | -0.5% | -4.38 to +3.818 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.291e+04 | 9.278e+04 | -0.1% | -291.3 to +28.77 | STEADY, under the floor |
| power-capped share of samples | 0.9761 | 0.9672 | -0.9% | -0.1749 to +0.1571 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.96 | 60.05 | +0.1% | -0.905 to +1.068 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.289e+04 | 9.277e+04 | -0.1% | -1326 to +1090 | STEADY, under the floor |
| energy per served request (J) | 16.68 | 16.65 | -0.1% | -0.2965 to +0.2512 | STEADY, under the floor |
| power, GPU mean (W) | 274.1 | 275 | +0.3% | -1.914 to +3.756 | STEADY, under the floor |
| requests served | 5570 | 5570 | +0.0% | -18.56 to +19.56 | STEADY, under the floor |
| requests not served | 1273 | 1272 | -0.0% | -19.56 to +18.56 | STEADY, under the floor |
| response time, mean (ms) | 4.241e+04 | 4.247e+04 | +0.1% | -868.2 to +989.2 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.119e+04 | 8.12e+04 | +0.0% | -1110 to +1119 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.444e+04 | 8.445e+04 | +0.0% | -1121 to +1128 | STEADY, under the floor |
| temperature, peak (C) | 62 | 62 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 59.34 | 59.38 | +0.1% | -0.2254 to +0.3224 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.291e+04 | 9.281e+04 | -0.1% | -645.5 to +430 | STEADY, under the floor |
| power-capped share of samples | 0.9761 | 0.9809 | +0.5% | -0.01802 to +0.02753 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 60.05 | 60.2 | +0.3% | -2.552 to +2.867 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.277e+04 | 9.275e+04 | -0.0% | -923.5 to +886.5 | STEADY, under the floor |
| energy per served request (J) | 16.65 | 16.61 | -0.3% | -0.7919 to +0.705 | STEADY, under the floor |
| power, GPU mean (W) | 275 | 275 | -0.0% | -2.929 to +2.854 | STEADY, under the floor |
| requests served | 5570 | 5584 | +0.2% | -183.4 to +210.4 | STEADY, under the floor |
| requests not served | 1272 | 1259 | -1.1% | -210.4 to +183.4 | GAIN, not beyond the noise |
| response time, mean (ms) | 4.247e+04 | 4.229e+04 | -0.4% | -2859 to +2504 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.12e+04 | 8.081e+04 | -0.5% | -6036 to +5271 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.445e+04 | 8.397e+04 | -0.6% | -7306 to +6360 | GAIN, not beyond the noise |
| temperature, peak (C) | 62 | 61.5 | -0.8% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 59.38 | 59.06 | -0.6% | -4.703 to +4.044 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.281e+04 | 9.278e+04 | -0.0% | -401.2 to +354.3 | STEADY, under the floor |
| power-capped share of samples | 0.9809 | 0.9672 | -1.4% | -0.1569 to +0.1295 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 59.96 -> 60.2 served requests per kJ, difference +0.2391 (95% interval -1.484 to +1.962).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time held (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 6.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*