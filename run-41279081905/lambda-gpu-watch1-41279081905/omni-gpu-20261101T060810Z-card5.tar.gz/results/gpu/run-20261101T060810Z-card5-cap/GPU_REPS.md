# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 41.5 | 41.7 | 41.23 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.168e+04 | 6.14e+04 | 6.21e+04 |
| energy per served request (J) | 24.1 | 23.98 | 24.26 |
| power, GPU mean (W) | 182.1 | 181.9 | 183.6 |
| requests served | 2560 | 2560 | 2560 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 111.8 | 111.6 | 114.2 |
| response time, 95th percentile (ms) | 351.6 | 351.4 | 368.9 |
| response time, 99th percentile (ms) | 615.7 | 611.2 | 642.3 |
| temperature, peak (C) | 58 | 59 | 58.5 |
| temperature, mean (C) | 47.69 | 47.79 | 47.63 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.196e+04 | 6.175e+04 | 6.17e+04 |
| power-capped share of samples | 0.6663 | 0.6671 | 0.6469 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.5 | 41.23 | -0.7% | -1.379 to +0.8208 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.168e+04 | 6.21e+04 | +0.7% | -1161 to +1993 | power given, not beyond the noise |
| energy per served request (J) | 24.1 | 24.26 | +0.7% | -0.4533 to +0.7786 | power given, not beyond the noise |
| power, GPU mean (W) | 182.1 | 183.6 | +0.9% | -1.863 to +4.964 | power given, not beyond the noise |
| requests served | 2560 | 2560 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.8 | 114.2 | +2.2% | -29.22 to +34.04 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 351.6 | 368.9 | +4.9% | -250.5 to +285.3 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 615.7 | 642.3 | +4.3% | -347.4 to +400.6 | LOSS, not beyond the noise |
| temperature, peak (C) | 58 | 58.5 | +0.9% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 47.69 | 47.63 | -0.1% | -1.222 to +1.119 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.196e+04 | 6.17e+04 | -0.4% | -3305 to +2779 | STEADY, under the floor |
| power-capped share of samples | 0.6663 | 0.6469 | -2.9% | -0.05978 to +0.02116 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.5 | 41.7 | +0.5% | +0.01724 to +0.3696 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.168e+04 | 6.14e+04 | -0.5% | -490.5 to -81.18 | STEADY, under the floor |
| energy per served request (J) | 24.1 | 23.98 | -0.5% | -0.1916 to -0.03171 | STEADY, under the floor |
| power, GPU mean (W) | 182.1 | 181.9 | -0.1% | -2.637 to +2.179 | STEADY, under the floor |
| requests served | 2560 | 2560 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.8 | 111.6 | -0.2% | -3.186 to +2.693 | STEADY, under the floor |
| response time, 95th percentile (ms) | 351.6 | 351.4 | -0.0% | -22.93 to +22.6 | STEADY, under the floor |
| response time, 99th percentile (ms) | 615.7 | 611.2 | -0.7% | -67.46 to +58.54 | GAIN, not beyond the noise |
| temperature, peak (C) | 58 | 59 | +1.7% | -11.71 to +13.71 | power given, not beyond the noise |
| temperature, mean (C) | 47.69 | 47.79 | +0.2% | -0.2116 to +0.428 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.196e+04 | 6.175e+04 | -0.3% | -1591 to +1174 | STEADY, under the floor |
| power-capped share of samples | 0.6663 | 0.6671 | +0.1% | -0.0667 to +0.06835 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 41.7 | 41.23 | -1.1% | -1.749 to +0.8035 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.14e+04 | 6.21e+04 | +1.1% | -1079 to +2484 | power given, not beyond the noise |
| energy per served request (J) | 23.98 | 24.26 | +1.1% | -0.4216 to +0.9702 | power given, not beyond the noise |
| power, GPU mean (W) | 181.9 | 183.6 | +1.0% | -4.042 to +7.601 | power given, not beyond the noise |
| requests served | 2560 | 2560 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 111.6 | 114.2 | +2.4% | -26.03 to +31.35 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 351.4 | 368.9 | +5.0% | -227.6 to +262.7 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 611.2 | 642.3 | +5.1% | -280 to +342 | LOSS, not beyond the noise |
| temperature, peak (C) | 59 | 58.5 | -0.8% | -19.56 to +18.56 | GAIN, not beyond the noise |
| temperature, mean (C) | 47.79 | 47.63 | -0.3% | -1.65 to +1.331 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.175e+04 | 6.17e+04 | -0.1% | -1714 to +1605 | STEADY, under the floor |
| power-capped share of samples | 0.6671 | 0.6469 | -3.0% | -0.04718 to +0.006918 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 41.5 -> 41.23 served requests per kJ, difference -0.2794 (95% interval -1.379 to +0.8208).
Guardrails: requests served held (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): power given, not beyond the noise.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| omni | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 18.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*