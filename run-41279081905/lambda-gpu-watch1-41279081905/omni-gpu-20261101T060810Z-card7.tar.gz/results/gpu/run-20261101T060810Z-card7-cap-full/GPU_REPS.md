# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 59.06 | 59.03 | 59.07 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 9.29e+04 | 9.282e+04 | 9.269e+04 |
| energy per served request (J) | 16.93 | 16.94 | 16.93 |
| power, GPU mean (W) | 274.4 | 275.2 | 275.6 |
| requests served | 5486 | 5479 | 5476 |
| requests not served | 1350 | 1357 | 1360 |
| response time, mean (ms) | 4.392e+04 | 4.418e+04 | 4.431e+04 |
| response time, 95th percentile (ms) | 8.429e+04 | 8.464e+04 | 8.483e+04 |
| response time, 99th percentile (ms) | 8.775e+04 | 8.811e+04 | 8.826e+04 |
| temperature, peak (C) | 74 | 73.5 | 74 |
| temperature, mean (C) | 70.1 | 69.4 | 70.18 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 9.292e+04 | 9.282e+04 | 9.282e+04 |
| power-capped share of samples | 0.9773 | 0.9806 | 0.983 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.06 | 59.07 | +0.0% | -0.9188 to +0.9444 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.29e+04 | 9.269e+04 | -0.2% | -1759 to +1346 | STEADY, under the floor |
| energy per served request (J) | 16.93 | 16.93 | -0.0% | -0.2705 to +0.2633 | STEADY, under the floor |
| power, GPU mean (W) | 274.4 | 275.6 | +0.4% | -5.636 to +7.929 | STEADY, under the floor |
| requests served | 5486 | 5476 | -0.2% | -188.9 to +166.9 | STEADY, under the floor |
| requests not served | 1350 | 1360 | +0.8% | -166.9 to +188.9 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.392e+04 | 4.431e+04 | +0.9% | -5385 to +6166 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.429e+04 | 8.483e+04 | +0.6% | -7951 to +9028 | LOSS, not beyond the noise |
| response time, 99th percentile (ms) | 8.775e+04 | 8.826e+04 | +0.6% | -7882 to +8892 | LOSS, not beyond the noise |
| temperature, peak (C) | 74 | 74 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 70.1 | 70.18 | +0.1% | -1.094 to +1.256 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.292e+04 | 9.282e+04 | -0.1% | -134.9 to -56 | STEADY, under the floor |
| power-capped share of samples | 0.9773 | 0.983 | +0.6% | -0.03625 to +0.04752 | power given, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.06 | 59.03 | -0.1% | -1.889 to +1.822 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.29e+04 | 9.282e+04 | -0.1% | -732 to +583.4 | STEADY, under the floor |
| energy per served request (J) | 16.93 | 16.94 | +0.1% | -0.5226 to +0.5418 | STEADY, under the floor |
| power, GPU mean (W) | 274.4 | 275.2 | +0.3% | +0.1253 to +1.509 | STEADY, under the floor |
| requests served | 5486 | 5479 | -0.1% | -140.9 to +125.9 | STEADY, under the floor |
| requests not served | 1350 | 1357 | +0.6% | -125.9 to +140.9 | LOSS, not beyond the noise |
| response time, mean (ms) | 4.392e+04 | 4.418e+04 | +0.6% | -4059 to +4583 | LOSS, not beyond the noise |
| response time, 95th percentile (ms) | 8.429e+04 | 8.464e+04 | +0.4% | -5370 to +6076 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.775e+04 | 8.811e+04 | +0.4% | -5779 to +6485 | STEADY, under the floor |
| temperature, peak (C) | 74 | 73.5 | -0.7% | -6.853 to +5.853 | GAIN, not beyond the noise |
| temperature, mean (C) | 70.1 | 69.4 | -1.0% | -10.68 to +9.28 | GAIN, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.292e+04 | 9.282e+04 | -0.1% | -271.8 to +80.63 | STEADY, under the floor |
| power-capped share of samples | 0.9773 | 0.9806 | +0.3% | -0.01574 to +0.02223 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 59.03 | 59.07 | +0.1% | -2.74 to +2.833 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 9.282e+04 | 9.269e+04 | -0.1% | -1027 to +762.5 | STEADY, under the floor |
| energy per served request (J) | 16.94 | 16.93 | -0.1% | -0.8123 to +0.7858 | STEADY, under the floor |
| power, GPU mean (W) | 275.2 | 275.6 | +0.1% | -5.761 to +6.42 | STEADY, under the floor |
| requests served | 5479 | 5476 | -0.1% | -314.8 to +307.8 | STEADY, under the floor |
| requests not served | 1357 | 1360 | +0.3% | -307.8 to +314.8 | STEADY, under the floor |
| response time, mean (ms) | 4.418e+04 | 4.431e+04 | +0.3% | -9969 to +1.023e+04 | STEADY, under the floor |
| response time, 95th percentile (ms) | 8.464e+04 | 8.483e+04 | +0.2% | -1.403e+04 to +1.44e+04 | STEADY, under the floor |
| response time, 99th percentile (ms) | 8.811e+04 | 8.826e+04 | +0.2% | -1.437e+04 to +1.467e+04 | STEADY, under the floor |
| temperature, peak (C) | 73.5 | 74 | +0.7% | -5.853 to +6.853 | power given, not beyond the noise |
| temperature, mean (C) | 69.4 | 70.18 | +1.1% | -10.37 to +11.94 | power given, not beyond the noise |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 9.282e+04 | 9.282e+04 | +0.0% | -136.6 to +136.9 | STEADY, under the floor |
| power-capped share of samples | 0.9806 | 0.983 | +0.2% | -0.02052 to +0.02529 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 59.06 -> 59.07 served requests per kJ, difference +0.01276 (95% interval -0.9188 to +0.9444).
Guardrails: requests served FAILED (not below -1%), 95th-percentile response time FAILED (not above +10%), requests not served FAILED (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (not established: inside the noise, a guardrail crossed on the mean).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| omni | 2 | 149 | 0 | n/a | n/a | 0 | 149 | 0 |
| watch | 1 | 150 | 0 | n/a | n/a | 0 | 150 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 4.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*