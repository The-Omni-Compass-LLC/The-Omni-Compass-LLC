# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 280.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
2 repetitions, order rotated, 300.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 40.88 | 40.52 | 41.33 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.289e+04 | 6.344e+04 | 6.221e+04 |
| energy per served request (J) | 24.46 | 24.68 | 24.2 |
| power, GPU mean (W) | 186 | 187.7 | 185.6 |
| requests served | 2571 | 2571 | 2571 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 119.8 | 120.1 | 120 |
| response time, 95th percentile (ms) | 405.2 | 405.6 | 400.6 |
| response time, 99th percentile (ms) | 681.4 | 683.7 | 679.3 |
| temperature, peak (C) | 66.5 | 66.5 | 66.5 |
| temperature, mean (C) | 55.77 | 55.74 | 55.67 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.28e+04 | 6.257e+04 | 6.199e+04 |
| power-capped share of samples | 0.6785 | 0.6717 | 0.6459 |

## Total: Omni governs against native, 2 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.88 | 41.33 | +1.1% | -2.628 to +3.517 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.289e+04 | 6.221e+04 | -1.1% | -5409 to +4052 | GAIN, not beyond the noise |
| energy per served request (J) | 24.46 | 24.2 | -1.1% | -2.104 to +1.576 | GAIN, not beyond the noise |
| power, GPU mean (W) | 186 | 185.6 | -0.2% | -22.4 to +21.59 | STEADY, under the floor |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 119.8 | 120 | +0.2% | -5.401 to +5.802 | STEADY, under the floor |
| response time, 95th percentile (ms) | 405.2 | 400.6 | -1.1% | -48.74 to +39.55 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 681.4 | 679.3 | -0.3% | -87.07 to +82.76 | STEADY, under the floor |
| temperature, peak (C) | 66.5 | 66.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.77 | 55.67 | -0.2% | -0.6012 to +0.3945 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.28e+04 | 6.199e+04 | -1.3% | -2587 to +963.6 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6785 | 0.6459 | -4.8% | -0.116 to +0.05083 | GAIN, not beyond the noise |

## Observation: omni watching (writes nothing) against native, 2 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.88 | 40.52 | -0.9% | -3.728 to +3.012 | power given, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.289e+04 | 6.344e+04 | +0.9% | -4636 to +5742 | power given, not beyond the noise |
| energy per served request (J) | 24.46 | 24.68 | +0.9% | -1.803 to +2.233 | power given, not beyond the noise |
| power, GPU mean (W) | 186 | 187.7 | +0.9% | -16.68 to +20.14 | power given, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 119.8 | 120.1 | +0.3% | -2.152 to +2.783 | STEADY, under the floor |
| response time, 95th percentile (ms) | 405.2 | 405.6 | +0.1% | -7.438 to +8.212 | STEADY, under the floor |
| response time, 99th percentile (ms) | 681.4 | 683.7 | +0.3% | -35.09 to +39.57 | STEADY, under the floor |
| temperature, peak (C) | 66.5 | 66.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.77 | 55.74 | -0.1% | -1.552 to +1.488 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.28e+04 | 6.257e+04 | -0.4% | -579.3 to +124.5 | STEADY, under the floor |
| power-capped share of samples | 0.6785 | 0.6717 | -1.0% | -0.08877 to +0.07509 | GAIN, not beyond the noise |

## Authority: Omni governs against Omni watching, 2 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 40.52 | 41.33 | +2.0% | +0.5047 to +1.1 | GAIN, clear of the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.344e+04 | 6.221e+04 | -1.9% | -1690 to -773.7 | GAIN, clear of the noise |
| energy per served request (J) | 24.68 | 24.2 | -1.9% | -0.6574 to -0.3009 | GAIN, clear of the noise |
| power, GPU mean (W) | 187.7 | 185.6 | -1.1% | -5.716 to +1.447 | GAIN, not beyond the noise |
| requests served | 2571 | 2571 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 120.1 | 120 | -0.1% | -3.25 to +3.019 | STEADY, under the floor |
| response time, 95th percentile (ms) | 405.6 | 400.6 | -1.2% | -41.3 to +31.34 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 683.7 | 679.3 | -0.6% | -51.98 to +43.19 | GAIN, not beyond the noise |
| temperature, peak (C) | 66.5 | 66.5 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.74 | 55.67 | -0.1% | -1.094 to +0.9513 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.257e+04 | 6.199e+04 | -0.9% | -2711 to +1543 | GAIN, not beyond the noise |
| power-capped share of samples | 0.6717 | 0.6459 | -3.8% | -0.1911 to +0.1396 | GAIN, not beyond the noise |

## Verdict on the preregistered question

Work per energy under Omni against native: 40.88 -> 41.33 served requests per kJ, difference +0.4444 (95% interval -2.628 to +3.517).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: power given, not beyond the noise. Authority (omni against watch): GAIN, clear of the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 145 | 0 | n/a | n/a | 0 | 145 | 0 |
| omni | 2 | 147 | 0 | n/a | n/a | 0 | 147 | 0 |
| watch | 1 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |
| watch | 2 | 148 | 0 | n/a | n/a | 0 | 148 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 26.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*