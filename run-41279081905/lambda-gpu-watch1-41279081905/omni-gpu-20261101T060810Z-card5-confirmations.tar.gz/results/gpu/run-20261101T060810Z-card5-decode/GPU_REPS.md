# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.74 | 45.53 | 45.62 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.26e+05 | 1.266e+05 | 1.263e+05 |
| energy per served request (J) | 21.86 | 21.96 | 21.92 |
| power, GPU mean (W) | 197.2 | 199 | 198.4 |
| requests served | 5763 | 5763 | 5763 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.79 | 96.61 | 96.72 |
| response time, 95th percentile (ms) | 267.8 | 266.8 | 267.2 |
| response time, 99th percentile (ms) | 455.4 | 453.4 | 454.6 |
| temperature, peak (C) | 60 | 60.33 | 60 |
| temperature, mean (C) | 48.12 | 48.15 | 48.2 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.262e+05 | 1.26e+05 | 1.261e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.74 | 45.62 | -0.3% | -1.328 to +1.095 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.26e+05 | 1.263e+05 | +0.3% | -3030 to +3674 | STEADY, under the floor |
| energy per served request (J) | 21.86 | 21.92 | +0.3% | -0.5257 to +0.6376 | STEADY, under the floor |
| power, GPU mean (W) | 197.2 | 198.4 | +0.6% | -2.116 to +4.584 | power given, not beyond the noise |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.79 | 96.72 | -0.1% | -0.7367 to +0.5959 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.8 | 267.2 | -0.2% | -3.293 to +2.172 | STEADY, under the floor |
| response time, 99th percentile (ms) | 455.4 | 454.6 | -0.2% | -6.556 to +4.924 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 48.12 | 48.2 | +0.2% | -0.2327 to +0.3796 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.262e+05 | 1.261e+05 | -0.1% | -1152 to +934.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.74 | 45.53 | -0.5% | -0.3021 to -0.111 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.26e+05 | 1.266e+05 | +0.5% | +294.3 to +850.4 | STEADY, under the floor |
| energy per served request (J) | 21.86 | 21.96 | +0.5% | +0.05106 to +0.1476 | STEADY, under the floor |
| power, GPU mean (W) | 197.2 | 199 | +0.9% | +0.2418 to +3.292 | power given, clear of the noise |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.79 | 96.61 | -0.2% | -0.7208 to +0.3583 | STEADY, under the floor |
| response time, 95th percentile (ms) | 267.8 | 266.8 | -0.4% | -4.099 to +2.148 | STEADY, under the floor |
| response time, 99th percentile (ms) | 455.4 | 453.4 | -0.5% | -8.277 to +4.167 | STEADY, under the floor |
| temperature, peak (C) | 60 | 60.33 | +0.6% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 48.12 | 48.15 | +0.1% | -0.0001108 to +0.05204 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.262e+05 | 1.26e+05 | -0.1% | -460.3 to +131.1 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.53 | 45.62 | +0.2% | -1.217 to +1.397 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.266e+05 | 1.263e+05 | -0.2% | -3880 to +3380 | STEADY, under the floor |
| energy per served request (J) | 21.96 | 21.92 | -0.2% | -0.6732 to +0.5865 | STEADY, under the floor |
| power, GPU mean (W) | 199 | 198.4 | -0.3% | -5.374 to +4.309 | STEADY, under the floor |
| requests served | 5763 | 5763 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.61 | 96.72 | +0.1% | -0.1538 to +0.3754 | STEADY, under the floor |
| response time, 95th percentile (ms) | 266.8 | 267.2 | +0.2% | -0.5297 to +1.359 | STEADY, under the floor |
| response time, 99th percentile (ms) | 453.4 | 454.6 | +0.3% | -2.187 to +4.665 | STEADY, under the floor |
| temperature, peak (C) | 60.33 | 60 | -0.6% | -1.768 to +1.101 | GAIN, not beyond the noise |
| temperature, mean (C) | 48.15 | 48.2 | +0.1% | -0.2576 to +0.3526 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.26e+05 | 1.261e+05 | +0.0% | -1130 to +1241 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.74 -> 45.62 served requests per kJ, difference -0.1164 (95% interval -1.328 to +1.095).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.203 | 0.259 | 0 | 710 | 31 | True |
| omni | 2 | 38 | 0 | 0 | 0 | 0.204 | 0.322 | 0 | 856 | 37 | True |
| omni | 3 | 22 | 0 | 0 | 0 | 0.198 | 0.24 | 0 | 572 | 21 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 278 | 0 | n/a | n/a | 0 | 278 | 0 |
| omni | 2 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 283 | 0 | n/a | n/a | 0 | 283 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 65 | -14.19 | +0 |
| compass | 46 | 990 | -3906 | -83 |
| fail_up | 4 | 19 | -281.7 | +3 |
| race | 39 | 142 | -49.14 | -43 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 92.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*