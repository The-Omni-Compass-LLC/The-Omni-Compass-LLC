# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 38.69 | 38.96 | 38.97 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.586e+05 | 1.574e+05 | 1.574e+05 |
| energy per served request (J) | 25.85 | 25.67 | 25.66 |
| power, GPU mean (W) | 249.4 | 247.8 | 247.8 |
| requests served | 6134 | 6134 | 6134 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 88.63 | 88.61 | 88.63 |
| response time, 95th percentile (ms) | 252.4 | 252.5 | 252.7 |
| response time, 99th percentile (ms) | 442.7 | 442.9 | 442.7 |
| temperature, peak (C) | 67.67 | 68 | 67.33 |
| temperature, mean (C) | 54.91 | 54.95 | 54.91 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.575e+05 | 1.575e+05 | 1.573e+05 |
| power-capped share of samples | 0.737 | 0.7374 | 0.7368 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.69 | 38.97 | +0.7% | -1.23 to +1.8 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.586e+05 | 1.574e+05 | -0.7% | -7277 to +4978 | GAIN, not beyond the noise |
| energy per served request (J) | 25.85 | 25.66 | -0.7% | -1.186 to +0.8115 | GAIN, not beyond the noise |
| power, GPU mean (W) | 249.4 | 247.8 | -0.6% | -11.58 to +8.487 | GAIN, not beyond the noise |
| requests served | 6134 | 6134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.63 | 88.63 | +0.0% | -0.4314 to +0.4321 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.4 | 252.7 | +0.1% | -0.8373 to +1.343 | STEADY, under the floor |
| response time, 99th percentile (ms) | 442.7 | 442.7 | -0.0% | -3.936 to +3.845 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 67.33 | -0.5% | -1.768 to +1.101 | STEADY, under the floor |
| temperature, mean (C) | 54.91 | 54.91 | -0.0% | -0.08671 to +0.08434 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.575e+05 | 1.573e+05 | -0.2% | -653.7 to +165.1 | STEADY, under the floor |
| power-capped share of samples | 0.737 | 0.7368 | -0.0% | -0.002555 to +0.002254 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.69 | 38.96 | +0.7% | -1.101 to +1.656 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.586e+05 | 1.574e+05 | -0.7% | -6728 to +4481 | GAIN, not beyond the noise |
| energy per served request (J) | 25.85 | 25.67 | -0.7% | -1.097 to +0.7305 | GAIN, not beyond the noise |
| power, GPU mean (W) | 249.4 | 247.8 | -0.6% | -9.77 to +6.699 | GAIN, not beyond the noise |
| requests served | 6134 | 6134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.63 | 88.61 | -0.0% | -0.1808 to +0.1563 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.4 | 252.5 | +0.0% | -1.275 to +1.467 | STEADY, under the floor |
| response time, 99th percentile (ms) | 442.7 | 442.9 | +0.0% | -0.8756 to +1.212 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 68 | +0.5% | -2.535 to +3.202 | STEADY, under the floor |
| temperature, mean (C) | 54.91 | 54.95 | +0.1% | -0.3562 to +0.4354 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.575e+05 | 1.575e+05 | +0.0% | -505.5 to +570.3 | STEADY, under the floor |
| power-capped share of samples | 0.737 | 0.7374 | +0.1% | -0.005621 to +0.006407 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 38.96 | 38.97 | +0.0% | -1.095 to +1.11 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.574e+05 | 1.574e+05 | -0.0% | -4442 to +4390 | STEADY, under the floor |
| energy per served request (J) | 25.67 | 25.66 | -0.0% | -0.7241 to +0.7156 | STEADY, under the floor |
| power, GPU mean (W) | 247.8 | 247.8 | -0.0% | -7.266 to +7.245 | STEADY, under the floor |
| requests served | 6134 | 6134 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 88.61 | 88.63 | +0.0% | -0.2506 to +0.2758 | STEADY, under the floor |
| response time, 95th percentile (ms) | 252.5 | 252.7 | +0.1% | -0.2446 to +0.5574 | STEADY, under the floor |
| response time, 99th percentile (ms) | 442.9 | 442.7 | -0.0% | -3.766 to +3.339 | STEADY, under the floor |
| temperature, peak (C) | 68 | 67.33 | -1.0% | -2.101 to +0.7677 | GAIN, not beyond the noise |
| temperature, mean (C) | 54.95 | 54.91 | -0.1% | -0.4825 to +0.4009 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.575e+05 | 1.573e+05 | -0.2% | -577.6 to +24.15 | STEADY, under the floor |
| power-capped share of samples | 0.7374 | 0.7368 | -0.1% | -0.008522 to +0.007436 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 38.69 -> 38.97 served requests per kJ, difference +0.2849 (95% interval -1.23 to +1.8).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 2 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| omni | 3 | 273 | 0 | n/a | n/a | 0 | 273 | 0 |
| watch | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| watch | 2 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| watch | 3 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*