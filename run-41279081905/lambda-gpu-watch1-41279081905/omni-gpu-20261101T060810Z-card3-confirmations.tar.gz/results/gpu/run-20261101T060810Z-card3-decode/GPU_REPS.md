# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 47.59 | 47.73 | 47.51 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.225e+05 | 1.222e+05 | 1.227e+05 |
| energy per served request (J) | 21.01 | 20.95 | 21.05 |
| power, GPU mean (W) | 191.8 | 191.6 | 193.1 |
| requests served | 5830 | 5830 | 5830 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.28 | 96.19 | 96.25 |
| response time, 95th percentile (ms) | 274 | 273.6 | 273.8 |
| response time, 99th percentile (ms) | 448.7 | 448.2 | 448.1 |
| temperature, peak (C) | 59.67 | 59.67 | 60 |
| temperature, mean (C) | 48.64 | 48.59 | 48.68 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.223e+05 | 1.221e+05 | 1.222e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.59 | 47.51 | -0.2% | -1.104 to +0.946 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.225e+05 | 1.227e+05 | +0.2% | -2436 to +2855 | STEADY, under the floor |
| energy per served request (J) | 21.01 | 21.05 | +0.2% | -0.4179 to +0.4897 | STEADY, under the floor |
| power, GPU mean (W) | 191.8 | 193.1 | +0.6% | -2.748 to +5.23 | power given, not beyond the noise |
| requests served | 5830 | 5830 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.28 | 96.25 | -0.0% | -0.533 to +0.4818 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274 | 273.8 | -0.1% | -1.77 to +1.187 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.7 | 448.1 | -0.1% | -5.093 to +3.878 | STEADY, under the floor |
| temperature, peak (C) | 59.67 | 60 | +0.6% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 48.64 | 48.68 | +0.1% | -0.2755 to +0.3681 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.223e+05 | 1.222e+05 | -0.1% | -580.8 to +258.8 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.59 | 47.73 | +0.3% | -0.9309 to +1.206 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.225e+05 | 1.222e+05 | -0.3% | -3107 to +2396 | STEADY, under the floor |
| energy per served request (J) | 21.01 | 20.95 | -0.3% | -0.533 to +0.411 | STEADY, under the floor |
| power, GPU mean (W) | 191.8 | 191.6 | -0.1% | -2.835 to +2.304 | STEADY, under the floor |
| requests served | 5830 | 5830 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.28 | 96.19 | -0.1% | -0.4433 to +0.2593 | STEADY, under the floor |
| response time, 95th percentile (ms) | 274 | 273.6 | -0.2% | -1.291 to +0.4225 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.7 | 448.2 | -0.1% | -5.593 to +4.464 | STEADY, under the floor |
| temperature, peak (C) | 59.67 | 59.67 | +0.0% | -2.484 to +2.484 | STEADY, under the floor |
| temperature, mean (C) | 48.64 | 48.59 | -0.1% | -0.3604 to +0.2716 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.223e+05 | 1.221e+05 | -0.2% | -949 to +484.2 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 47.73 | 47.51 | -0.5% | -1.927 to +1.494 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.222e+05 | 1.227e+05 | +0.5% | -3826 to +4956 | STEADY, under the floor |
| energy per served request (J) | 20.95 | 21.05 | +0.5% | -0.6563 to +0.8502 | STEADY, under the floor |
| power, GPU mean (W) | 191.6 | 193.1 | +0.8% | -4.589 to +7.601 | power given, not beyond the noise |
| requests served | 5830 | 5830 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.19 | 96.25 | +0.1% | -0.7399 to +0.8727 | STEADY, under the floor |
| response time, 95th percentile (ms) | 273.6 | 273.8 | +0.1% | -2.175 to +2.46 | STEADY, under the floor |
| response time, 99th percentile (ms) | 448.2 | 448.1 | -0.0% | -8.204 to +8.118 | STEADY, under the floor |
| temperature, peak (C) | 59.67 | 60 | +0.6% | -1.101 to +1.768 | power given, not beyond the noise |
| temperature, mean (C) | 48.59 | 48.68 | +0.2% | +0.07141 to +0.1099 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.221e+05 | 1.222e+05 | +0.1% | -654.8 to +797.5 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 47.59 -> 47.51 served requests per kJ, difference -0.07911 (95% interval -1.104 to +0.946).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 28 | 0 | 0 | 0 | 0.203 | 0.248 | 0 | 984 | 27 | True |
| omni | 2 | 30 | 0 | 0 | 0 | 0.214 | 0.273 | 0 | 978 | 29 | True |
| omni | 3 | 30 | 0 | 0 | 0 | 0.198 | 0.264 | 0 | 930 | 29 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| watch | 1 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 63 | -3.668 | +0 |
| compass | 44 | 996 | -3453 | -23 |
| fail_up | 1 | 7 | +11.42 | +5 |
| race | 40 | 145 | +1291 | -123 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 88.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*