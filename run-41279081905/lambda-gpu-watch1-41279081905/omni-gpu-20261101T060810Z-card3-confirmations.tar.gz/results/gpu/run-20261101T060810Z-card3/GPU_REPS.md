# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 39.47 | 39.68 | 39.67 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.546e+05 | 1.538e+05 | 1.539e+05 |
| energy per served request (J) | 25.34 | 25.21 | 25.21 |
| power, GPU mean (W) | 243.1 | 241.2 | 242.1 |
| requests served | 6103 | 6103 | 6103 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 91.17 | 91.2 | 91.16 |
| response time, 95th percentile (ms) | 269 | 268.8 | 269.5 |
| response time, 99th percentile (ms) | 458.7 | 459.7 | 458.5 |
| temperature, peak (C) | 67.67 | 68 | 68 |
| temperature, mean (C) | 55.22 | 55.19 | 55.2 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.543e+05 | 1.541e+05 | 1.543e+05 |
| power-capped share of samples | 0.7343 | 0.7326 | 0.7346 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.47 | 39.67 | +0.5% | -1.406 to +1.818 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.546e+05 | 1.539e+05 | -0.5% | -7053 to +5493 | GAIN, not beyond the noise |
| energy per served request (J) | 25.34 | 25.21 | -0.5% | -1.156 to +0.9 | GAIN, not beyond the noise |
| power, GPU mean (W) | 243.1 | 242.1 | -0.4% | -9.466 to +7.462 | STEADY, under the floor |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.17 | 91.16 | -0.0% | -0.08639 to +0.05801 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269 | 269.5 | +0.2% | -1.932 to +2.92 | STEADY, under the floor |
| response time, 99th percentile (ms) | 458.7 | 458.5 | -0.1% | -1.833 to +1.266 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 68 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 55.22 | 55.2 | -0.0% | -0.1945 to +0.1584 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.543e+05 | 1.543e+05 | +0.0% | -457.5 to +502 | STEADY, under the floor |
| power-capped share of samples | 0.7343 | 0.7346 | +0.0% | -0.03761 to +0.0381 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.47 | 39.68 | +0.5% | -1.58 to +1.995 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.546e+05 | 1.538e+05 | -0.5% | -7798 to +6187 | GAIN, not beyond the noise |
| energy per served request (J) | 25.34 | 25.21 | -0.5% | -1.278 to +1.014 | GAIN, not beyond the noise |
| power, GPU mean (W) | 243.1 | 241.2 | -0.8% | -10.84 to +7.032 | GAIN, not beyond the noise |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.17 | 91.2 | +0.0% | -0.1543 to +0.215 | STEADY, under the floor |
| response time, 95th percentile (ms) | 269 | 268.8 | -0.0% | -1.192 to +0.9253 | STEADY, under the floor |
| response time, 99th percentile (ms) | 458.7 | 459.7 | +0.2% | -0.9018 to +2.814 | STEADY, under the floor |
| temperature, peak (C) | 67.67 | 68 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 55.22 | 55.19 | -0.1% | -0.1485 to +0.08035 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.543e+05 | 1.541e+05 | -0.2% | -833.6 to +367.2 | STEADY, under the floor |
| power-capped share of samples | 0.7343 | 0.7326 | -0.2% | -0.01654 to +0.01311 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 39.68 | 39.67 | -0.0% | -2.635 to +2.632 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.538e+05 | 1.539e+05 | +0.0% | -1.017e+04 to +1.022e+04 | STEADY, under the floor |
| energy per served request (J) | 25.21 | 25.21 | +0.0% | -1.666 to +1.674 | STEADY, under the floor |
| power, GPU mean (W) | 241.2 | 242.1 | +0.4% | -13.55 to +15.36 | STEADY, under the floor |
| requests served | 6103 | 6103 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 91.2 | 91.16 | -0.0% | -0.2912 to +0.2021 | STEADY, under the floor |
| response time, 95th percentile (ms) | 268.8 | 269.5 | +0.2% | -0.9648 to +2.22 | STEADY, under the floor |
| response time, 99th percentile (ms) | 459.7 | 458.5 | -0.3% | -3.481 to +1.002 | STEADY, under the floor |
| temperature, peak (C) | 68 | 68 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.19 | 55.2 | +0.0% | -0.2164 to +0.2484 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.541e+05 | 1.543e+05 | +0.2% | +132.7 to +378.1 | STEADY, under the floor |
| power-capped share of samples | 0.7326 | 0.7346 | +0.3% | -0.02233 to +0.02624 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 39.47 -> 39.67 served requests per kJ, difference +0.2058 (95% interval -1.406 to +1.818).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: GAIN, not beyond the noise. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 275 | 0 | n/a | n/a | 0 | 275 | 0 |
| omni | 2 | 276 | 0 | n/a | n/a | 0 | 276 | 0 |
| omni | 3 | 277 | 0 | n/a | n/a | 0 | 277 | 0 |
| watch | 1 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |
| watch | 2 | 272 | 0 | n/a | n/a | 0 | 272 | 0 |
| watch | 3 | 271 | 0 | n/a | n/a | 0 | 271 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*