# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A100-SXM4-80GB, driver 570.148.08, persistence mode Enabled, start power limit 400.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
3 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit dca8d09bbaa4; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 45.42 | 45.5 | 46.12 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 1.266e+05 | 1.264e+05 | 1.247e+05 |
| energy per served request (J) | 22.02 | 21.98 | 21.68 |
| power, GPU mean (W) | 199 | 198.6 | 196.2 |
| requests served | 5752 | 5752 | 5752 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 96.19 | 96.15 | 96.14 |
| response time, 95th percentile (ms) | 264.3 | 264.4 | 263.8 |
| response time, 99th percentile (ms) | 451.9 | 451.1 | 451.1 |
| temperature, peak (C) | 70 | 70.33 | 70.33 |
| temperature, mean (C) | 55.79 | 55.76 | 55.8 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 1.257e+05 | 1.256e+05 | 1.255e+05 |
| power-capped share of samples | 0 | 0 | 0 |

## Total: Omni governs against native, 3 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.42 | 46.12 | +1.5% | -0.273 to +1.677 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.266e+05 | 1.247e+05 | -1.5% | -4578 to +732.6 | GAIN, not beyond the noise |
| energy per served request (J) | 22.02 | 21.68 | -1.5% | -0.7958 to +0.1274 | GAIN, not beyond the noise |
| power, GPU mean (W) | 199 | 196.2 | -1.4% | -6.534 to +1.04 | GAIN, not beyond the noise |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.19 | 96.14 | -0.0% | -0.6168 to +0.5314 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.3 | 263.8 | -0.2% | -3.144 to +2.259 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.9 | 451.1 | -0.2% | -6.703 to +5.149 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70.33 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 55.79 | 55.8 | +0.0% | -0.2447 to +0.25 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.257e+05 | 1.255e+05 | -0.1% | -455.4 to +102.6 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Observation: omni watching (writes nothing) against native, 3 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.42 | 45.5 | +0.2% | -1.474 to +1.633 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.266e+05 | 1.264e+05 | -0.2% | -4534 to +4128 | STEADY, under the floor |
| energy per served request (J) | 22.02 | 21.98 | -0.2% | -0.7883 to +0.7177 | STEADY, under the floor |
| power, GPU mean (W) | 199 | 198.6 | -0.2% | -5.943 to +5.278 | STEADY, under the floor |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.19 | 96.15 | -0.0% | -0.6072 to +0.5314 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.3 | 264.4 | +0.1% | -3.432 to +3.781 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.9 | 451.1 | -0.2% | -6.178 to +4.632 | STEADY, under the floor |
| temperature, peak (C) | 70 | 70.33 | +0.5% | -1.101 to +1.768 | STEADY, under the floor |
| temperature, mean (C) | 55.79 | 55.76 | -0.1% | -0.4265 to +0.3588 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.257e+05 | 1.256e+05 | -0.1% | -460.5 to +277.7 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Authority: Omni governs against Omni watching, 3 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 45.5 | 46.12 | +1.4% | -1.845 to +3.09 | GAIN, not beyond the noise |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 1.264e+05 | 1.247e+05 | -1.4% | -8536 to +5097 | GAIN, not beyond the noise |
| energy per served request (J) | 21.98 | 21.68 | -1.4% | -1.484 to +0.8862 | GAIN, not beyond the noise |
| power, GPU mean (W) | 198.6 | 196.2 | -1.2% | -11.56 to +6.73 | GAIN, not beyond the noise |
| requests served | 5752 | 5752 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 96.15 | 96.14 | -0.0% | -0.2015 to +0.1919 | STEADY, under the floor |
| response time, 95th percentile (ms) | 264.4 | 263.8 | -0.2% | -1.559 to +0.3251 | STEADY, under the floor |
| response time, 99th percentile (ms) | 451.1 | 451.1 | -0.0% | -0.8402 to +0.8313 | STEADY, under the floor |
| temperature, peak (C) | 70.33 | 70.33 | +0.0% | +0 to +0 | STEADY, the same |
| temperature, mean (C) | 55.76 | 55.8 | +0.1% | -0.1638 to +0.2367 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 1.256e+05 | 1.255e+05 | -0.1% | -351 to +181.1 | STEADY, under the floor |
| power-capped share of samples | 0 | 0 | +0 | +0 to +0 | STEADY, the same |

## Verdict on the preregistered question

Work per energy under Omni against native: 45.42 -> 46.12 served requests per kJ, difference +0.702 (95% interval -0.273 to +1.677).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): GAIN, not beyond the noise.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 32 | 0 | 0 | 0 | 0.206 | 0.293 | 0 | 992 | 31 | True |
| omni | 2 | 32 | 0 | 0 | 0 | 0.203 | 0.315 | 0 | 658 | 31 | True |
| omni | 3 | 30 | 0 | 0 | 0 | 0.203 | 0.307 | 0 | 716 | 29 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 2 | 279 | 0 | n/a | n/a | 0 | 279 | 0 |
| omni | 3 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 1 | 282 | 0 | n/a | n/a | 0 | 282 | 0 |
| watch | 2 | 280 | 0 | n/a | n/a | 0 | 280 | 0 |
| watch | 3 | 281 | 0 | n/a | n/a | 0 | 281 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## Credit per write (against native at the same moments of the same request stream)

Each write owns the interval until the next write. Joules and requests finished in it, Omni governing minus native; the intervals tile the arm, so the credits add up. The decider is the rule that set the written limit (engine, a floor, the busy gate, a reflex, heat, the speed lock).

| Decided by | Writes | Seconds owned | GPU joules vs native | Requests finished vs native |
|---|---:|---:|---:|---:|
| blind_fail_up | 3 | 66 | +16.4 | +0 |
| compass | 47 | 1015 | -75.98 | +40 |
| fail_up | 2 | 14 | +17.51 | -12 |
| race | 42 | 138 | -421.6 | -72 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 94.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*