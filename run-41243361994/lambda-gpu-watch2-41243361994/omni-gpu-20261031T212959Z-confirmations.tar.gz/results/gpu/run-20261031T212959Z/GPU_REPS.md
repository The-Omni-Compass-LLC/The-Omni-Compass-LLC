# GPU bench: native vs Omni-Compass, metered by the device

> © 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. `SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0` All patents, copyrights and trademarks filed in the USA. www.omni-compass.com

GPU NVIDIA A10, driver 570.148.08, persistence mode Enabled, start power limit 150.00 W, workload tools/gpu_workload.py (seeded fp16 matmul request stream).
10 repetitions, order rotated, 600.0 s per arm plus 30.0 s drain, 60.0 s idle before each arm.

Phase: **confirm**. Omni frozen at commit 3b53d68fa69f; file hashes in FREEZE.json, rechecked at the end.

## Every column, mean over repetitions

| Gauge | native | omni, watching (writes nothing) | omni |
|---|---:|---:|---:|
| work per energy (served requests per kJ) | 54.98 | 55.03 | 55.13 |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU (J) | 6.898e+04 | 6.891e+04 | 6.878e+04 |
| energy per served request (J) | 18.19 | 18.17 | 18.14 |
| power, GPU mean (W) | 109.2 | 109.1 | 108.9 |
| requests served | 3792 | 3792 | 3792 |
| requests not served | 0 | 0 | 0 |
| response time, mean (ms) | 152.7 | 152.5 | 152.1 |
| response time, 95th percentile (ms) | 475.2 | 474.2 | 470.9 |
| response time, 99th percentile (ms) | 1037 | 1041 | 1035 |
| temperature, peak (C) | 70.3 | 70.6 | 70.4 |
| temperature, mean (C) | 59.87 | 59.84 | 59.75 |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| energy, GPU device counter (J) | 6.82e+04 | 6.817e+04 | 6.813e+04 |
| power-capped share of samples | 0.867 | 0.8662 | 0.8658 |

## Total: Omni governs against native, 10 paired repetitions

| Gauge | native | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 54.98 | 55.13 | +0.3% | +0.05711 to +0.2545 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.898e+04 | 6.878e+04 | -0.3% | -318.5 to -71.49 | STEADY, under the floor |
| energy per served request (J) | 18.19 | 18.14 | -0.3% | -0.084 to -0.01885 | STEADY, under the floor |
| power, GPU mean (W) | 109.2 | 108.9 | -0.3% | -0.5013 to -0.1117 | STEADY, under the floor |
| requests served | 3792 | 3792 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 152.7 | 152.1 | -0.4% | -1.713 to +0.4482 | STEADY, under the floor |
| response time, 95th percentile (ms) | 475.2 | 470.9 | -0.9% | -10.96 to +2.428 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1037 | 1035 | -0.2% | -14.71 to +10.66 | STEADY, under the floor |
| temperature, peak (C) | 70.3 | 70.4 | +0.1% | -0.5263 to +0.7263 | STEADY, under the floor |
| temperature, mean (C) | 59.87 | 59.75 | -0.2% | -0.3006 to +0.05902 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.82e+04 | 6.813e+04 | -0.1% | -136.4 to +5.763 | STEADY, under the floor |
| power-capped share of samples | 0.867 | 0.8658 | -0.1% | -0.003338 to +0.0008739 | STEADY, under the floor |

## Observation: omni watching (writes nothing) against native, 10 paired repetitions

| Gauge | native | omni, watching (writes nothing) | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 54.98 | 55.03 | +0.1% | -0.07562 to +0.1848 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.898e+04 | 6.891e+04 | -0.1% | -231.7 to +94.55 | STEADY, under the floor |
| energy per served request (J) | 18.19 | 18.17 | -0.1% | -0.06109 to +0.02493 | STEADY, under the floor |
| power, GPU mean (W) | 109.2 | 109.1 | -0.1% | -0.3553 to +0.1473 | STEADY, under the floor |
| requests served | 3792 | 3792 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 152.7 | 152.5 | -0.2% | -1.037 to +0.5758 | STEADY, under the floor |
| response time, 95th percentile (ms) | 475.2 | 474.2 | -0.2% | -6.824 to +4.87 | STEADY, under the floor |
| response time, 99th percentile (ms) | 1037 | 1041 | +0.4% | -1.869 to +10.01 | STEADY, under the floor |
| temperature, peak (C) | 70.3 | 70.6 | +0.4% | -0.04553 to +0.6455 | STEADY, under the floor |
| temperature, mean (C) | 59.87 | 59.84 | -0.0% | -0.07788 to +0.02127 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.82e+04 | 6.817e+04 | -0.0% | -58.44 to +8.682 | STEADY, under the floor |
| power-capped share of samples | 0.867 | 0.8662 | -0.1% | -0.003423 to +0.001801 | STEADY, under the floor |

## Authority: Omni governs against Omni watching, 10 paired repetitions

| Gauge | omni, watching (writes nothing) | omni | Change | 95% interval of the difference | Verdict |
|---|---:|---:|---:|---:|---|
| **work per energy (served requests per kJ) (primary)** | 55.03 | 55.13 | +0.2% | -0.02946 to +0.2319 | STEADY, under the floor |
| work per wall energy (served requests per kJ, whole machine) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, whole machine at the wall (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU (J) | 6.891e+04 | 6.878e+04 | -0.2% | -289.5 to +36.61 | STEADY, under the floor |
| energy per served request (J) | 18.17 | 18.14 | -0.2% | -0.07635 to +0.009654 | STEADY, under the floor |
| power, GPU mean (W) | 109.1 | 108.9 | -0.2% | -0.4557 to +0.05082 | STEADY, under the floor |
| requests served | 3792 | 3792 | +0.0% | +0 to +0 | STEADY, the same |
| requests not served | 0 | 0 | +0 | +0 to +0 | STEADY, the same |
| response time, mean (ms) | 152.5 | 152.1 | -0.3% | -1.439 to +0.6358 | STEADY, under the floor |
| response time, 95th percentile (ms) | 474.2 | 470.9 | -0.7% | -11.34 to +4.76 | GAIN, not beyond the noise |
| response time, 99th percentile (ms) | 1041 | 1035 | -0.6% | -16.86 to +4.659 | GAIN, not beyond the noise |
| temperature, peak (C) | 70.6 | 70.4 | -0.3% | -0.9388 to +0.5388 | STEADY, under the floor |
| temperature, mean (C) | 59.84 | 59.75 | -0.2% | -0.3049 to +0.1199 | STEADY, under the floor |
| energy, CPU package (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, DRAM (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, platform psys (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, rest of the machine (J) | UNAVAILABLE | UNAVAILABLE | | | no meter |
| energy, GPU device counter (J) | 6.817e+04 | 6.813e+04 | -0.1% | -125.5 to +44.59 | STEADY, under the floor |
| power-capped share of samples | 0.8662 | 0.8658 | -0.0% | -0.003174 to +0.002332 | STEADY, under the floor |

## Verdict on the preregistered question

Work per energy under Omni against native: 54.98 -> 55.13 served requests per kJ, difference +0.1558 (95% interval +0.05711 to +0.2545).
Guardrails: requests served held (not below -1%), 95th-percentile response time held (not above +10%), requests not served held (not above +1% of native served).
Observation (watch against native) on the same outcome: STEADY, under the floor. Authority (omni against watch): STEADY, under the floor.
**Result, by rule: STEADY (inside the noise, within the guardrails).**

## Actuator fidelity (receipt B: requested against read back from the device)

| Arm | Rep | Writes | Refused | mean abs(read back − requested) W | max W | delay median s | delay max s | enforced under requested | total variation W | reversals | restored |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| omni | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| omni | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 1 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 2 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 3 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 4 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 5 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 6 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 7 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 8 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 9 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |
| watch | 10 | 0 | 0 | n/a | n/a | n/a | n/a | 0 | 0 | 0 | True |

## Control effort (receipt A)

| Arm | Rep | Decisions | J_u = sum abs(u) dt | mean abs(u) | max abs(u) | saturations | shield interventions | holds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| omni | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 5 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| omni | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| omni | 10 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 1 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 2 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 3 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 4 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 5 | 308 | 0 | n/a | n/a | 0 | 308 | 0 |
| watch | 6 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 7 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 8 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 9 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |
| watch | 10 | 309 | 0 | n/a | n/a | 0 | 309 | 0 |

## Representation fidelity (the engine's projection against the telemetry at the next decision)

R_int: weighted root-mean-square of h(z next) − F_h(h(z), u) over E, U, I_U, S, B (weights 1). Directional accuracy: the share of movements the projection called in the right direction, movements under 0.01 excluded.

| Arm | Rep | Pairs | R_int | directional accuracy | valid directions | by predicted size |
|---|---|---:|---:|---:|---:|---|
| omni | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| omni | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 1 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 2 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 3 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 4 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 5 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 6 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 7 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 8 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 9 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |
| watch | 10 | 0 | n/a | n/a | 0 | 0.01-0.03: n/a of 0, 0.03-0.1: n/a of 0, >=0.1: n/a of 0 |

## The control

- Writes executed (power limit and clock ceiling): native 0, omni, watching (writes nothing) 0, omni 0.
- Every arm ended at the start limit.
- Energy is the device's own power.draw integrated over time; no number here is modelled.

---

*© 2026 The Omni-Compass LLC. All rights reserved. **Evaluation and Simulation use only.** Any commercial use, commercialization, monetization, production use, redistribution or hosted service of any part of Omni-Compass requires a signed, paid Omni-Compass Enterprise License from The Omni-Compass LLC. Every copy, export, report and printout carries this notice with `LICENSE`, `NOTICE` and `DISCLOSURES.md`. All patents, copyrights and trademarks filed in the USA. www.omni-compass.com*